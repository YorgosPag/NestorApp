/**
 * Hook για να διαβάζει τις ρυθμίσεις προσχεδίασης γραμμής
 * χωρίς να χρειάζεται React context στο PhaseManager
 */

import { toolStyleStore } from '../stores/ToolStyleStore';
import type { LineType } from '../settings-core/types';
import { getDashArray } from '../settings-core/defaults';

// Αφαιρώ το direct import της συνάρτησης για να αποφύγω circular dependency
// θα την κάλεσω μέσω require εντός της συνάρτησης
// import { useUnifiedLineDraft } from '../ui/hooks/useUnifiedSpecificSettings';

export interface LinePreviewStyle {
  enabled: boolean;          // ΝΕΟ! Ενεργοποίηση/απενεργοποίηση γραμμών
  strokeColor: string;
  lineWidth: number;
  lineDash: number[];
  opacity: number;
  lineType: LineType;
}


// Global function που μπορεί να κληθεί από οπουδήποτε (ΓΕΝΙΚΕΣ ΡΥΘΜΙΣΕΙΣ)
export function getLinePreviewStyle(): LinePreviewStyle {
  const toolStyle = toolStyleStore.get();

  // Get line type from ToolStyleStore (updated by LinePreviewSettingsContext)
  const lineType = toolStyle.lineType || 'dashed';
  const lineDash = getDashArray(lineType, toolStyle.dashScale || 1);

  const result = {
    enabled: toolStyle.enabled !== undefined ? toolStyle.enabled : true, // Default: enabled
    strokeColor: toolStyle.strokeColor, // Παίρνει απευθείας από γενικές ρυθμίσεις (DxfSettingsProvider)
    lineWidth: toolStyle.lineWidth,     // Παίρνει απευθείας από γενικές ρυθμίσεις (DxfSettingsProvider)
    lineDash,
    opacity: toolStyle.opacity,         // Παίρνει απευθείας από γενικές ρυθμίσεις (DxfSettingsProvider)
    lineType,
  };

  return result;
}

// Global state store για draft settings (εκτός React context)
let draftSettingsStore: {
  overrideGlobalSettings: boolean;
  settings: Partial<LinePreviewStyle>;
} | null = null;

// Συνάρτηση για να ενημερώσει το store από το React context
export function updateDraftSettingsStore(settings: { overrideGlobalSettings: boolean; settings: Partial<LinePreviewStyle> }) {
  draftSettingsStore = settings;
}

// ✅ ΝΕΑ ΣΥΝΑΡΤΗΣΗ: Ελέγχει το checkbox και επιστρέφει τις σωστές ρυθμίσεις
export function getLinePreviewStyleWithOverride(): LinePreviewStyle {
  // 🔍 DEBUG: Έλεγχος κατάστασης store
  // Αν έχω ειδικές ρυθμίσεις και το checkbox είναι checked
  if (draftSettingsStore?.overrideGlobalSettings && draftSettingsStore.settings) {
    const specificSettings = draftSettingsStore.settings;
    const lineType = specificSettings.lineType || 'dashed';
    const lineDash = getDashArray(lineType, toolStyle.dashScale || 1);
    return {
      enabled: specificSettings.enabled !== undefined ? specificSettings.enabled : true,
      strokeColor: specificSettings.color || '#FF0000', // ✅ AutoCAD standard: Red for preview
      lineWidth: specificSettings.lineWidth || 1,        // ✅ AutoCAD standard: 1 pixel default
      lineDash,
      opacity: specificSettings.opacity || 1.0,
      lineType,
    };
  }

  // Fallback στις γενικές ρυθμίσεις
  return getLinePreviewStyle();
}

// Function για να εφαρμόσει το στυλ σε canvas context
export function applyLinePreviewStyle(ctx: CanvasRenderingContext2D): void {
  const style = getLinePreviewStyleWithOverride();

  ctx.strokeStyle = style.strokeColor;
  ctx.lineWidth = style.lineWidth;
  ctx.setLineDash(style.lineDash);
  ctx.globalAlpha = style.opacity;
}