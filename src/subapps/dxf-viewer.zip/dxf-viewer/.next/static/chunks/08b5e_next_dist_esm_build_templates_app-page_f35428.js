(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/08b5e_next_dist_esm_build_templates_app-page_f35428.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/08b5e_next_dist_esm_build_templates_app-page_f35428.js",
  "chunks": [
    "static/chunks/08b5e_next_dist_compiled_react_a1d82d._.js",
    "static/chunks/08b5e_next_dist_compiled_react-dom_cjs_react-dom_development_c9a189.js",
    "static/chunks/08b5e_next_dist_compiled_react-dom_87a050._.js",
    "static/chunks/08b5e_next_dist_compiled_e13b54._.js",
    "static/chunks/08b5e_next_dist_client_8bb71d._.js",
    "static/chunks/08b5e_next_dist_091837._.js",
    "static/chunks/08b5e_@swc_helpers_cjs_00636a._.js",
    "static/chunks/[turbopack]_dev_client_hmr-client_ts_4da20b._.js"
  ],
  "source": "entry"
});
