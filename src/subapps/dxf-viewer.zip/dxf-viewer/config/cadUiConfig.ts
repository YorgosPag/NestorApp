/**
 * CAD UI Configuration - DEPRECATED
 * Now re-exported from unified color system
 */

// Re-export from unified color system  
export { CAD_UI_COLORS as CAD_UI } from './color-config';
