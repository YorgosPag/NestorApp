'use client';

import React, { createContext, useContext, useRef, useState, type ReactNode } from 'react';
import type { ViewTransform } from '../rendering/types/Types';
import { ZoomManager } from '../systems/zoom/ZoomManager';
import type { ZoomConfig } from '../systems/zoom/zoom-types';

interface CanvasContextType {
  dxfRef: React.RefObject<any>;
  overlayRef: React.RefObject<any>;
  transform: ViewTransform;
  setTransform: (transform: ViewTransform) => void;
  // 🏢 ENTERPRISE: Centralized zoom system
  zoomManager: ZoomManager | null;
  setZoomManager: (manager: ZoomManager) => void;
}

const CanvasContext = createContext<CanvasContextType | null>(null);

export const useCanvasContext = () => {
  const context = useContext(CanvasContext);
  if (!context) {
    // Return null instead of throwing error to allow fallback behavior
    return null;
  }
  return context;
};

interface CanvasProviderProps {
  children: ReactNode;
}

export const CanvasProvider: React.FC<CanvasProviderProps> = ({ children }) => {
  const dxfRef = useRef<any>(null);
  const overlayRef = useRef<any>(null);

  // 🎯 INITIAL TRANSFORM: World (0,0) at bottom-left ruler corner
  // This will be updated when viewport is known, but provides sensible defaults
  const [transform, setTransform] = useState<ViewTransform>({
    scale: 1,
    offsetX: 0,   // Will be set to RULER_WIDTH (30) when viewport available
    offsetY: 0    // Will be set to viewport.height - RULER_HEIGHT when available
  });

  // 🏢 ENTERPRISE: Centralized zoom system
  const [zoomManager, setZoomManager] = useState<ZoomManager | null>(null);

  return (
    <CanvasContext.Provider value={{
      dxfRef,
      overlayRef,
      transform,
      setTransform,
      zoomManager,
      setZoomManager
    }}>
      {children}
    </CanvasContext.Provider>
  );
};