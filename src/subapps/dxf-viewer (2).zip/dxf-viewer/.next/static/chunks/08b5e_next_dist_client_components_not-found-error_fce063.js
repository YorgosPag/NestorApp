(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/08b5e_next_dist_client_components_not-found-error_fce063.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/08b5e_next_dist_client_components_not-found-error_fce063.js",
  "chunks": [
    "static/chunks/08b5e_next_dist_0219ee._.js"
  ],
  "source": "dynamic"
});
