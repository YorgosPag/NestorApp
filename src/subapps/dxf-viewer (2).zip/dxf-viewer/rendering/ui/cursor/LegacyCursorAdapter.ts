/**
 * LEGACY CURSOR ADAPTER - Backwards compatibility
 * ✅ ΦΑΣΗ 6: Adapter pattern για smooth transition από old CursorRenderer
 */

import type { Point2D, Viewport } from '../../types/Types';
import type { UICursorSettings } from './CursorTypes';
import type { CursorSettings as SystemCursorSettings } from '../../../systems/cursor/config';
import { CursorRenderer } from './CursorRenderer';
import { createUIRenderContext, DEFAULT_UI_TRANSFORM } from '../core/UIRenderContext';

/**
 * 🔺 LEGACY ADAPTER
 * Προσαρμογέας που εξομοιώνει την παλιά CursorRenderer interface
 * Αυτό επιτρέπει στο LayerRenderer να συνεχίσει να δουλεύει
 * χωρίς αλλαγές while internally χρησιμοποιώντας το νέο unified system
 */
export class LegacyCursorAdapter {
  private coreRenderer: CursorRenderer;
  private ctx: CanvasRenderingContext2D;

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
    this.coreRenderer = new CursorRenderer();
  }

  /**
   * Legacy render method - maintains exact same interface
   * ✅ ADAPTED για CursorSettings από systems/cursor/config.ts (nested structure)
   */
  render(
    position: Point2D,
    viewport: Viewport,
    settings: SystemCursorSettings
  ): void {
    // Convert legacy nested SystemCursorSettings to flat UICursorSettings
    const flatSettings: UICursorSettings = {
      enabled: settings.cursor.enabled,
      visible: true,
      opacity: settings.cursor.opacity,
      color: settings.cursor.color,
      size: settings.cursor.size,
      lineWidth: settings.cursor.line_width,
      shape: this.mapShape(settings.cursor.shape),
      style: this.mapLineStyle(settings.cursor.line_style),
      showFill: false, // Legacy cursor doesn't support fill
      fillColor: '#ffffff',
      fillOpacity: 0.1,
      zIndex: 900
    };

    // Convert legacy call to new UIRenderer interface
    const uiContext = createUIRenderContext(
      this.ctx,
      viewport,
      DEFAULT_UI_TRANSFORM
    );

    // Add position to context
    (uiContext as any).mousePosition = position;

    this.coreRenderer.render(uiContext, viewport, flatSettings);
  }

  /**
   * Map legacy shape types to new CursorShape enum
   */
  private mapShape(legacyShape: 'circle' | 'square'): 'circle' | 'square' | 'diamond' | 'cross' {
    switch (legacyShape) {
      case 'circle': return 'circle';
      case 'square': return 'square';
      default: return 'square';
    }
  }

  /**
   * Map legacy line style to new CursorLineStyle enum
   */
  private mapLineStyle(legacyStyle: 'solid' | 'dashed' | 'dotted' | 'dash-dot'): 'solid' | 'dashed' | 'dotted' | 'dash-dot' {
    return legacyStyle; // Same types, direct mapping
  }

  /**
   * Cleanup method for consistency
   */
  cleanup(): void {
    this.coreRenderer.cleanup();
  }
}