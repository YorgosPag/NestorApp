/**
 * 🎯 SPATIAL UTILITIES
 * Centralized utility functions για spatial operations
 * Χρησιμοποιείται από όλα τα spatial index implementations
 */

import type { Point2D } from '../../rendering/types/Types';
import type { SpatialBounds } from './ISpatialIndex';

/**
 * 🔧 BOUNDS OPERATIONS
 * Core functions για spatial bounds calculations
 */
export class SpatialUtils {

  /**
   * Create bounds from array of points
   */
  static boundsFromPoints(points: Point2D[]): SpatialBounds {
    if (points.length === 0) {
      return { minX: 0, minY: 0, maxX: 0, maxY: 0 };
    }

    let minX = points[0].x;
    let minY = points[0].y;
    let maxX = points[0].x;
    let maxY = points[0].y;

    for (const point of points) {
      minX = Math.min(minX, point.x);
      minY = Math.min(minY, point.y);
      maxX = Math.max(maxX, point.x);
      maxY = Math.max(maxY, point.y);
    }

    return { minX, minY, maxX, maxY };
  }

  /**
   * Test if two bounds intersect
   */
  static boundsIntersect(a: SpatialBounds, b: SpatialBounds): boolean {
    return !(
      a.maxX < b.minX ||
      a.minX > b.maxX ||
      a.maxY < b.minY ||
      a.minY > b.maxY
    );
  }

  /**
   * Test if bounds A contains bounds B completely
   */
  static boundsContains(container: SpatialBounds, contained: SpatialBounds): boolean {
    return (
      container.minX <= contained.minX &&
      container.minY <= contained.minY &&
      container.maxX >= contained.maxX &&
      container.maxY >= contained.maxY
    );
  }

  /**
   * Test if point is inside bounds
   */
  static pointInBounds(point: Point2D, bounds: SpatialBounds): boolean {
    return (
      point.x >= bounds.minX &&
      point.x <= bounds.maxX &&
      point.y >= bounds.minY &&
      point.y <= bounds.maxY
    );
  }

  /**
   * Calculate distance from point to bounds
   * Returns 0 if point is inside bounds
   */
  static distanceToPoint(point: Point2D, bounds: SpatialBounds): number {
    const dx = Math.max(0, Math.max(bounds.minX - point.x, point.x - bounds.maxX));
    const dy = Math.max(0, Math.max(bounds.minY - point.y, point.y - bounds.maxY));
    return Math.sqrt(dx * dx + dy * dy);
  }

  /**
   * Expand bounds by margin in all directions
   */
  static expandBounds(bounds: SpatialBounds, margin: number): SpatialBounds {
    return {
      minX: bounds.minX - margin,
      minY: bounds.minY - margin,
      maxX: bounds.maxX + margin,
      maxY: bounds.maxY + margin
    };
  }

  /**
   * Calculate center point of bounds
   */
  static boundsCenter(bounds: SpatialBounds): Point2D {
    return {
      x: (bounds.minX + bounds.maxX) / 2,
      y: (bounds.minY + bounds.maxY) / 2
    };
  }

  /**
   * Calculate area of bounds
   */
  static boundsArea(bounds: SpatialBounds): number {
    return (bounds.maxX - bounds.minX) * (bounds.maxY - bounds.minY);
  }

  /**
   * Union of two bounds (smallest bounds that contains both)
   */
  static boundsUnion(a: SpatialBounds, b: SpatialBounds): SpatialBounds {
    return {
      minX: Math.min(a.minX, b.minX),
      minY: Math.min(a.minY, b.minY),
      maxX: Math.max(a.maxX, b.maxX),
      maxY: Math.max(a.maxY, b.maxY)
    };
  }

  /**
   * 🎯 CAD-SPECIFIC UTILITIES
   */

  /**
   * Check if bounds are suitable for QuadTree (large area, many items)
   */
  static isQuadTreeSuitable(bounds: SpatialBounds, itemCount: number): boolean {
    const area = this.boundsArea(bounds);
    const density = itemCount / area;

    // QuadTree is better for:
    // - Large areas with moderate density
    // - Complex hit testing scenarios
    return area > 10000 && density < 0.1;
  }

  /**
   * Check if bounds are suitable for Grid (small area, dense items)
   */
  static isGridSuitable(bounds: SpatialBounds, itemCount: number): boolean {
    const area = this.boundsArea(bounds);
    const density = itemCount / area;

    // Grid is better for:
    // - Smaller areas with higher density
    // - Fast snapping operations
    return area <= 10000 || density >= 0.1;
  }

  /**
   * Calculate optimal grid size for given bounds and item count
   */
  static calculateOptimalGridSize(bounds: SpatialBounds, itemCount: number): number {
    const area = this.boundsArea(bounds);
    const averageItemArea = area / Math.max(itemCount, 1);
    const cellSize = Math.sqrt(averageItemArea);

    // Ensure reasonable bounds
    return Math.max(10, Math.min(500, cellSize));
  }

  /**
   * 🔍 VALIDATION UTILITIES
   */

  /**
   * Validate bounds are not degenerate
   */
  static isValidBounds(bounds: SpatialBounds): boolean {
    return (
      bounds.minX <= bounds.maxX &&
      bounds.minY <= bounds.maxY &&
      Number.isFinite(bounds.minX) &&
      Number.isFinite(bounds.minY) &&
      Number.isFinite(bounds.maxX) &&
      Number.isFinite(bounds.maxY)
    );
  }

  /**
   * Sanitize bounds to ensure they are valid
   */
  static sanitizeBounds(bounds: SpatialBounds): SpatialBounds {
    const sanitized = {
      minX: Number.isFinite(bounds.minX) ? bounds.minX : 0,
      minY: Number.isFinite(bounds.minY) ? bounds.minY : 0,
      maxX: Number.isFinite(bounds.maxX) ? bounds.maxX : 0,
      maxY: Number.isFinite(bounds.maxY) ? bounds.maxY : 0
    };

    // Ensure min <= max
    if (sanitized.minX > sanitized.maxX) {
      [sanitized.minX, sanitized.maxX] = [sanitized.maxX, sanitized.minX];
    }
    if (sanitized.minY > sanitized.maxY) {
      [sanitized.minY, sanitized.maxY] = [sanitized.maxY, sanitized.minY];
    }

    return sanitized;
  }
}