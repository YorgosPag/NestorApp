/**
 * COLOR CONFIGURATION
 * Central configuration for all colors used across the DXF viewer
 * Eliminates hardcoded color values and ensures consistency
 */

// Core UI Colors
export const UI_COLORS = {
  // Basic colors
  WHITE: '#FFFFFF',
  BLACK: '#000000',
  TRANSPARENT: 'transparent',
  
  // Entity colors
  DEFAULT_ENTITY: '#FFFFFF',
  SELECTED_ENTITY: '#00A2FF',
  HOVERED_ENTITY: '#FFD400',
  HIGHLIGHTED_ENTITY: '#FF3B30',
  
  // Drawing colors
  DRAWING_LINE: '#FFFFFF',
  DRAWING_PREVIEW: '#00ff80',
  DRAWING_TEMP: '#ffaa00',
  
  // Measurement colors
  MEASUREMENT_TEXT: '#00ff00',
  MEASUREMENT_LINE: '#00ff00',
  MEASUREMENT_POINTS: '#ffff00',
  DISTANCE_TEXT: '#00ff00',
  
  // Grip colors
  GRIP_DEFAULT: '#00ff80',
  GRIP_HOVER: '#FFD400',
  GRIP_SELECTED: '#00A2FF',
  GRIP_OUTLINE: '#000000',
  
  // Snap indicator colors
  SNAP_MIDPOINT: '#FFD400',
  SNAP_ENDPOINT: '#00E5FF',
  SNAP_INTERSECTION: '#FF6B35',
  SNAP_PERPENDICULAR: '#9B59B6',
  SNAP_CENTER: '#E67E22',
  SNAP_DEFAULT: '#FFD700',
  
  // Thermal/Phase colors
  THERMAL_COLD: '#00A2FF',
  THERMAL_WARM: '#FFD400',
  THERMAL_HOT: '#FF3B30',
  THERMAL_CONTOUR: '#000000',
  
  // Selection colors
  SELECTION_HIGHLIGHT: '#888888',
  SELECTION_MARQUEE: '#3b82f6',
  SELECTION_LASSO: '#3b82f6',
  
  // UI Element colors
  BUTTON_PRIMARY: '#3b82f6',
  BUTTON_PRIMARY_HOVER: '#2563eb',
  BUTTON_SECONDARY: '#6b7280',
  BUTTON_SECONDARY_HOVER: '#4b5563',
  
  // Status colors
  SUCCESS: '#10b981',
  WARNING: '#f59e0b',
  ERROR: '#ef4444',
  INFO: '#3b82f6',
} as const;

// Opacity variations
export const OPACITY = {
  FULL: 1.0,
  HIGH: 0.9,
  MEDIUM: 0.7,
  LOW: 0.5,
  VERY_LOW: 0.3,
  FAINT: 0.1,
} as const;

// Color utility functions
export const withOpacity = (color: string, opacity: number): string => {
  // Handle hex colors
  if (color.startsWith('#')) {
    const hex = color.slice(1);
    const alpha = Math.round(opacity * 255).toString(16).padStart(2, '0');
    return `${color}${alpha}`;
  }
  
  // Handle rgb colors
  if (color.startsWith('rgb(')) {
    return color.replace('rgb(', 'rgba(').replace(')', `, ${opacity})`);
  }
  
  // Handle rgba colors
  if (color.startsWith('rgba(')) {
    return color.replace(/,\s*[\d.]+\)$/, `, ${opacity})`);
  }
  
  return color;
};

export const getContrastColor = (backgroundColor: string): string => {
  // Simple contrast calculation - can be enhanced
  const isLight = backgroundColor === UI_COLORS.WHITE || 
                  backgroundColor.includes('fff') ||
                  backgroundColor.includes('FFF');
  return isLight ? UI_COLORS.BLACK : UI_COLORS.WHITE;
};

// Predefined color schemes
export const COLOR_SCHEMES = {
  DEFAULT: {
    background: UI_COLORS.BLACK,
    foreground: UI_COLORS.WHITE,
    accent: UI_COLORS.BUTTON_PRIMARY,
  },
  
  CAD_CLASSIC: {
    background: UI_COLORS.BLACK,
    foreground: UI_COLORS.WHITE,
    accent: UI_COLORS.SNAP_DEFAULT,
  },
  
  HIGH_CONTRAST: {
    background: UI_COLORS.BLACK,
    foreground: UI_COLORS.WHITE,
    accent: UI_COLORS.WARNING,
  }
} as const;

// Legacy color mappings for backward compatibility
export const LEGACY_COLORS = {
  // Common legacy names
  GREEN: UI_COLORS.MEASUREMENT_TEXT,
  YELLOW: UI_COLORS.SNAP_MIDPOINT,
  BLUE: UI_COLORS.SELECTED_ENTITY,
  WHITE: UI_COLORS.WHITE,
  BLACK: UI_COLORS.BLACK,
  ORANGE: UI_COLORS.DRAWING_TEMP,
} as const;