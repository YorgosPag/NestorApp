
'use client';

import React from 'react';
import { Button } from "../../../../components/ui/button";
import { Badge } from '../../../../components/ui/badge';
import { RotateCcw, Minimize } from "lucide-react";
import type { DXFViewerLayoutProps } from '../../integration/types';
import { ToolbarSection } from './ToolbarSection';
import { CanvasSection } from './CanvasSection';

/**
 * Renders the DXF viewer in a fullscreen, immersive layout.
 */
export const FullscreenView: React.FC<DXFViewerLayoutProps> = (props) => (
  <div className="fixed inset-0 z-50 bg-gray-900 flex flex-col">
    <ToolbarSection {...props} />
    <div className="flex justify-between items-center p-2 bg-gray-800 border-b border-gray-600">
      <div className="flex gap-2 items-center">
        <Button
          variant="outline"
          size="sm"
          className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600"
          onClick={() => props.handleAction('setViewMode', 'normal')}
        >
          <Minimize className="w-4 h-4 mr-2" />
          Exit Fullscreen
        </Button>
        <Button 
          variant="outline" 
          size="sm" 
          className="bg-gray-700 hover:bg-gray-600 text-white border-gray-600"
          onClick={() => props.handleAction('clear')}
        >
          <RotateCcw className="w-4 h-4 mr-2" />
          Clear
        </Button>
      </div>
      
      <div className="flex gap-2 items-center">
        {props.currentScene && (
          <Badge variant="secondary" className="bg-green-600 text-white">
            ✅ DXF Active ({props.currentScene.entities.length} entities)
          </Badge>
        )}
        
        {props.selectedEntityIds.length > 0 && (
          <Badge variant="secondary" className="bg-blue-600 text-white">
            🎯 Selected: {props.selectedEntityIds.length}
          </Badge>
        )}
        
      </div>
    </div>
    
    <div className="flex-1 flex overflow-hidden">
       <CanvasSection {...props} />
    </div>
  </div>
);
