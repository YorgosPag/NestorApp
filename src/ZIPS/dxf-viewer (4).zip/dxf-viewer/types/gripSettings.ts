/**
 * AutoCAD-style Grip Settings
 * Βασισμένο στις AutoCAD system variables: GRIPSIZE, PICKBOX, APERTURE
 */

export interface GripSettings {
  // === AutoCAD Variables ===
  gripSize: number;         // GRIPSIZE: 1-255 DIPs, default 5
  pickBoxSize: number;      // PICKBOX: 0-50 DIPs, default 3  
  apertureSize: number;     // APERTURE: 1-50 px, default 10
  showAperture: boolean;    // APBOX: show/hide osnap aperture
  
  // === Grip Colors (AutoCAD style) ===
  colors: {
    cold: string;           // GRIPCOLOR: unselected (default blue)
    warm: string;           // GRIPHOVER: hover (default orange)
    hot: string;            // GRIPHOT: selected (default red)
    contour: string;        // GRIPCONTOUR: border (default black)
  };
  
  // === Advanced Settings ===
  showGrips: boolean;       // Show/hide grips on selected entities
  multiGripEdit: boolean;   // Allow multi-grip operations
  snapToGrips: boolean;     // Enable snap to grips
  showGripTips: boolean;    // Show grip tooltips
  dpiScale: number;         // DPI scaling factor
}

export interface GripState {
  type: 'cold' | 'warm' | 'hot';
  entityId: string;
  gripIndex: number;
  position: { x: number; y: number };
  gripType: 'vertex' | 'edge' | 'center' | 'corner';
}

// === DEFAULT AUTOCAD-STYLE SETTINGS ===
const defaultGripSettings = {
  gripSize: 10,      // μεγαλύτερο by default
  pickBoxSize: 3,           // AutoCAD PICKBOX default
  apertureSize: 20,  // ~2x για εύκολο hit
  showAperture: true,       // AutoCAD APBOX default
  
  colors: { 
    cold:'#00A2FF', 
    warm:'#FFD400', 
    hot:'#FF3B30',
    contour: '#000000'      // Black border
  },
};

export const DEFAULT_GRIP_SETTINGS: GripSettings = {
  ...defaultGripSettings,
  
  showGrips: true,          // Show grips by default
  multiGripEdit: true,
  snapToGrips: true,
  showGripTips: false,      // Disabled by default για performance
  dpiScale: 1.0
};

// === VALIDATION ===
export const GRIP_LIMITS = {
  gripSize: { min: 1, max: 255 },
  pickBoxSize: { min: 0, max: 50 },
  apertureSize: { min: 1, max: 50 }
} as const;

export function validateGripSettings(settings: Partial<GripSettings>): GripSettings {
  const result = { ...DEFAULT_GRIP_SETTINGS, ...settings };
  
  // Clamp values to AutoCAD ranges
  result.gripSize = Math.max(GRIP_LIMITS.gripSize.min, 
    Math.min(GRIP_LIMITS.gripSize.max, result.gripSize));
  result.pickBoxSize = Math.max(GRIP_LIMITS.pickBoxSize.min, 
    Math.min(GRIP_LIMITS.pickBoxSize.max, result.pickBoxSize));
  result.apertureSize = Math.max(GRIP_LIMITS.apertureSize.min, 
    Math.min(GRIP_LIMITS.apertureSize.max, result.apertureSize));
    
  return result;
}
