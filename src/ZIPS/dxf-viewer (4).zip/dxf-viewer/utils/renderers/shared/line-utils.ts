/**
 * Shared utilities for line-based renderers (LineRenderer, PolylineRenderer)
 * Eliminates duplication in line/edge rendering logic
 */

import type { Point2D } from '../../../systems/coordinates/config';
import type { GripInfo } from '../BaseEntityRenderer';
import { pointToLineDistance } from '../../geometry-utils';
import { calculateDistance } from './geometry-rendering-utils';

/**
 * Creates edge midpoint grips for line-based entities
 */
export function createEdgeGrips(
  entityId: string,
  vertices: Point2D[],
  closed: boolean = false,
  baseIndex: number = 0
): GripInfo[] {
  const grips: GripInfo[] = [];
  
  // Edge midpoint grips for regular segments
  for (let i = 0; i < vertices.length - 1; i++) {
    const midpoint: Point2D = {
      x: (vertices[i].x + vertices[i + 1].x) / 2,
      y: (vertices[i].y + vertices[i + 1].y) / 2
    };
    
    grips.push({
      entityId,
      gripType: 'edge',
      gripIndex: baseIndex + i,
      position: midpoint,
      state: 'cold'
    });
  }
  
  // Add closing edge grip for closed polylines
  if (closed && vertices.length > 2) {
    const midpoint: Point2D = {
      x: (vertices[vertices.length - 1].x + vertices[0].x) / 2,
      y: (vertices[vertices.length - 1].y + vertices[0].y) / 2
    };
    
    grips.push({
      entityId,
      gripType: 'edge', 
      gripIndex: baseIndex + vertices.length - 1,
      position: midpoint,
      state: 'cold'
    });
  }
  
  return grips;
}

/**
 * Hit test for line segments - works for both single lines and polylines
 */
export function hitTestLineSegments(
  testPoint: Point2D,
  vertices: Point2D[],
  tolerance: number,
  closed: boolean = false,
  worldToScreen: (point: Point2D) => Point2D
): boolean {
  const screenPoint = worldToScreen(testPoint);
  const screenVertices = vertices.map(v => worldToScreen(v));
  
  // Check each segment
  for (let i = 0; i < screenVertices.length - 1; i++) {
    const distance = pointToLineDistance(
      screenPoint,
      screenVertices[i],
      screenVertices[i + 1]
    );
    
    if (distance <= tolerance) return true;
  }
  
  // Check closing segment if closed
  if (closed && screenVertices.length > 2) {
    const distance = pointToLineDistance(
      screenPoint,
      screenVertices[screenVertices.length - 1],
      screenVertices[0]
    );
    
    if (distance <= tolerance) return true;
  }
  
  return false;
}

/**
 * Calculate perimeter for polylines and closed shapes
 */
export function calculatePerimeter(vertices: Point2D[], closed: boolean = false): number {
  let perimeter = 0;
  
  for (let i = 0; i < vertices.length - 1; i++) {
    perimeter += calculateDistance(vertices[i], vertices[i + 1]);
  }
  
  if (closed && vertices.length > 2) {
    perimeter += calculateDistance(vertices[vertices.length - 1], vertices[0]);
  }
  
  return perimeter;
}

/**
 * Calculate split line gap points for text positioning
 */
export function calculateSplitLineGap(
  screenStart: Point2D,
  screenEnd: Point2D,
  gapSize: number = 30
): { gapStart: Point2D; gapEnd: Point2D; midpoint: Point2D; unitVector: Point2D } {
  const dx = screenEnd.x - screenStart.x;
  const dy = screenEnd.y - screenStart.y;
  const length = Math.sqrt(dx * dx + dy * dy);
  
  if (length === 0) {
    return {
      gapStart: screenStart,
      gapEnd: screenEnd,
      midpoint: screenStart,
      unitVector: { x: 0, y: 0 }
    };
  }
  
  // Unit vectors
  const unitX = dx / length;
  const unitY = dy / length;
  
  // Calculate midpoint
  const midX = (screenStart.x + screenEnd.x) / 2;
  const midY = (screenStart.y + screenEnd.y) / 2;
  
  // Calculate gap points (half gap on each side of center)
  const gapHalf = gapSize / 2;
  const gapStart = {
    x: midX - unitX * gapHalf,
    y: midY - unitY * gapHalf
  };
  const gapEnd = {
    x: midX + unitX * gapHalf,
    y: midY + unitY * gapHalf
  };
  
  return {
    gapStart,
    gapEnd,
    midpoint: { x: midX, y: midY },
    unitVector: { x: unitX, y: unitY }
  };
}

/**
 * Render split line with gap (used by both LineRenderer and PolylineRenderer)
 */
export function renderSplitLine(
  ctx: CanvasRenderingContext2D,
  screenStart: Point2D,
  screenEnd: Point2D,
  gapSize: number = 30
): { midpoint: Point2D } {
  const { gapStart, gapEnd, midpoint } = calculateSplitLineGap(screenStart, screenEnd, gapSize);
  
  // Draw first segment
  ctx.beginPath();
  ctx.moveTo(screenStart.x, screenStart.y);
  ctx.lineTo(gapStart.x, gapStart.y);
  ctx.stroke();
  
  // Draw second segment
  ctx.beginPath();
  ctx.moveTo(gapEnd.x, gapEnd.y);
  ctx.lineTo(screenEnd.x, screenEnd.y);
  ctx.stroke();
  
  return { midpoint };
}