/**
 * LayerItem Component
 * Displays a single layer with its entities and controls
 */

import React from 'react';
import { Eye, EyeOff, Trash2, Edit2, ChevronRight, ChevronDown } from 'lucide-react';
import { EntityCard } from './components/EntityCard';
import type { SceneModel } from '../../../types/scene';

interface LayerItemProps {
  layerName: string;
  scene: SceneModel;
  
  // State
  editingLayer: string | null;
  editingName: string;
  colorPickerLayer: string | null;
  expandedLayers: Set<string>;
  selectedLayersForMerge: Set<string>;
  
  // State setters
  setColorPickerLayer: (layer: string | null) => void;
  setEditingLayer: (layer: string | null) => void;
  setEditingName: (name: string) => void;
  setExpandedLayers: (layers: Set<string>) => void;
  
  // Callbacks
  handleLayerMultiSelectForMerge: (layerName: string, ctrlPressed: boolean) => void;
  getFilteredEntities: (layerName: string) => any[];
  
  // Event handlers
  onEntitySelectionChange?: (entityIds: string[]) => void;
  onLayerToggle?: (layerName: string, visible: boolean) => void;
  onLayerDelete?: (layerName: string) => void;
  onLayerRename?: (oldName: string, newName: string) => void;
  
  // Entity-related props
  selectedEntityIds: string[];
  editingEntity: string | null;
  colorPickerEntity: string | null;
  focusedEntityId: string | null;
  selectedEntitiesForMerge: Set<string>;
  editingEntityName: string;
  
  // Entity callbacks
  handleEntityClick: (entity: any, ctrlPressed: boolean) => void;
  handleEntityMultiSelectForMerge: (entityId: string, ctrlPressed: boolean) => void;
  handleEntityKeyDown: (e: React.KeyboardEvent) => void;
  setFocusedEntityId: (id: string | null) => void;
  setColorPickerEntity: (id: string | null) => void;
  setEditingEntity: (id: string | null) => void;
  setEditingEntityName: (name: string) => void;
  
  // Entity event handlers
  onEntityToggle?: (entityId: string, visible: boolean) => void;
  onEntityDelete?: (entityId: string) => void;
  onEntityColorChange?: (entityId: string, color: string) => void;
  onEntityRename?: (entityId: string, newName: string) => void;
}

export function LayerItem({
  layerName,
  scene,
  
  editingLayer,
  editingName,
  colorPickerLayer,
  expandedLayers,
  selectedLayersForMerge,
  
  setColorPickerLayer,
  setEditingLayer,
  setEditingName,
  setExpandedLayers,
  
  handleLayerMultiSelectForMerge,
  getFilteredEntities,
  
  onEntitySelectionChange,
  onLayerToggle,
  onLayerDelete,
  onLayerRename,
  
  // Entity props
  selectedEntityIds,
  editingEntity,
  colorPickerEntity,
  focusedEntityId,
  selectedEntitiesForMerge,
  editingEntityName,
  
  handleEntityClick,
  handleEntityMultiSelectForMerge,
  handleEntityKeyDown,
  setFocusedEntityId,
  setColorPickerEntity,
  setEditingEntity,
  setEditingEntityName,
  
  onEntityToggle,
  onEntityDelete,
  onEntityColorChange,
  onEntityRename
}: LayerItemProps) {
  
  const layer = scene.layers[layerName];
  const isEditing = editingLayer === layerName;
  const showColorPicker = colorPickerLayer === layerName;
  
  // Get filtered entities in this layer
  const layerEntities = getFilteredEntities(layerName);
  const entityCount = layerEntities.length;
  
  // Helper για consistent keys (ίδιο με το FloatingPanelContainer)
  const layerKey = `layer:${encodeURIComponent(layerName)}`;
  const isLayerExpanded = expandedLayers.has(layerKey);
  
  if (process.env.NODE_ENV === 'development' && entityCount > 0) {
    console.debug('[LayerItem] layerName:', layerName, 'key:', layerKey, 'expanded:', isLayerExpanded, 'entityCount:', entityCount);
  }

  const handleLayerClick = (e: React.MouseEvent) => {
    if (!isEditing) {
      e.stopPropagation();
      const ctrlPressed = e.ctrlKey || e.metaKey;
      if (ctrlPressed) {
        handleLayerMultiSelectForMerge(layerName, true);
      } else {
        const entityIds = layerEntities.map(entity => entity.id);
        onEntitySelectionChange?.(entityIds);
      }
    }
  };

  const handleExpandToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    const newExpanded = new Set(expandedLayers);
    if (expandedLayers.has(layerKey)) {
      newExpanded.delete(layerKey);
    } else {
      newExpanded.add(layerKey);
    }
    setExpandedLayers(newExpanded);
  };

  const handleColorPickerToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    setColorPickerLayer(showColorPicker ? null : layerName);
  };

  const handleNameDoubleClick = () => {
    setEditingLayer(layerName);
    setEditingName(layerName);
  };

  const handleNameKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      if (editingName.trim() && editingName !== layerName) {
        onLayerRename?.(layerName, editingName.trim());
      }
      setEditingLayer(null);
      setEditingName('');
    } else if (e.key === 'Escape') {
      setEditingLayer(null);
      setEditingName('');
    }
  };

  const handleNameBlur = () => {
    if (editingName.trim() && editingName !== layerName) {
      onLayerRename?.(layerName, editingName.trim());
    }
    setEditingLayer(null);
    setEditingName('');
  };

  const handleVisibilityToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    onLayerToggle?.(layerName, !layer.visible);
  };

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingLayer(layerName);
    setEditingName(layerName);
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    onLayerDelete?.(layerName);
  };

  return (
    <>
      <div 
        className={`flex items-center justify-between p-2 rounded cursor-pointer transition-all border-l-2 border-gray-600 ${
          layer.visible ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-900 opacity-60'
        } ${selectedLayersForMerge.has(layerName) ? 'ring-2 ring-blue-400 bg-blue-900 bg-opacity-30' : ''}`}
        onClick={handleLayerClick}
      >
        <div className="flex items-center gap-2 flex-1 min-w-0">
          {/* Expand/Collapse Arrow for entities */}
          {entityCount > 0 && (
            <button
              onClick={handleExpandToggle}
              className="p-1 text-gray-400 hover:text-white"
              title={isLayerExpanded ? "Σύμπτυξη στοιχείων" : "Ανάπτυξη στοιχείων"}
            >
              {isLayerExpanded ? (
                <ChevronDown className="w-3 h-3" />
              ) : (
                <ChevronRight className="w-3 h-3" />
              )}
            </button>
          )}
          
          {/* Color Picker */}
          <div className="relative">
            <button
              onClick={handleColorPickerToggle}
              className="w-3 h-3 rounded border border-gray-500 hover:ring-1 hover:ring-blue-400"
              style={{ backgroundColor: layer.color }}
              title="Αλλαγή χρώματος"
            />
          </div>

          {/* Layer Name */}
          {isEditing ? (
            <input
              type="text"
              value={editingName}
              onChange={(e) => setEditingName(e.target.value)}
              onKeyDown={handleNameKeyDown}
              onBlur={handleNameBlur}
              className="bg-gray-700 text-white text-sm px-1 rounded border border-blue-400 focus:outline-none focus:ring-1 focus:ring-blue-400"
              autoFocus
            />
          ) : (
            <span 
              className="text-sm text-white truncate cursor-pointer"
              title={layerName}
              onDoubleClick={handleNameDoubleClick}
            >
              {layerName}
            </span>
          )}
        </div>
        
        <div className="flex items-center gap-2">
          {/* Entity Count */}
          <span className="text-xs text-gray-400">{entityCount}</span>
          
          {/* Visibility Toggle */}
          <button
            onClick={handleVisibilityToggle}
            className="p-1 text-gray-400 hover:text-white"
            title={layer.visible ? "Απόκρυψη" : "Εμφάνιση"}
          >
            {layer.visible ? <Eye className="w-3 h-3" /> : <EyeOff className="w-3 h-3" />}
          </button>
          
          {/* Edit Button */}
          <button
            onClick={handleEditClick}
            className="p-1 text-gray-400 hover:text-white"
            title="Μετονομασία layer"
          >
            <Edit2 className="w-3 h-3" />
          </button>
          
          {/* Delete Button */}
          <button
            onClick={handleDeleteClick}
            className="p-1 text-red-600 hover:text-red-500"
            title="Διαγραφή"
          >
            <Trash2 className="w-3 h-3" />
          </button>
        </div>
      </div>

      {/* Individual Entities (when layer is expanded) */}
      {isLayerExpanded && layerEntities.map((entity) => (
        <EntityCard
          key={entity.id}
          entity={entity}
          layer={layer}
          isSelected={selectedEntityIds.includes(entity.id)}
          isEntityEditing={editingEntity === entity.id}
          showEntityColorPicker={colorPickerEntity === entity.id}
          isFocused={focusedEntityId === entity.id}
          selectedEntitiesForMerge={selectedEntitiesForMerge}
          editingEntityName={editingEntityName}
          onEntityClick={handleEntityClick}
          onEntityMultiSelectForMerge={handleEntityMultiSelectForMerge}
          onEntityKeyDown={handleEntityKeyDown}
          onSetFocusedEntityId={setFocusedEntityId}
          onSetColorPickerEntity={setColorPickerEntity}
          onSetEditingEntity={setEditingEntity}
          onSetEditingEntityName={setEditingEntityName}
          onEntityToggle={onEntityToggle}
          onEntityDelete={onEntityDelete}
          onEntityColorChange={onEntityColorChange}
          onEntityRename={onEntityRename}
          layerEntities={layerEntities}
        />
      ))}
    </>
  );
}