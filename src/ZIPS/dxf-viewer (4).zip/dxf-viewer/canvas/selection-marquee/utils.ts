import type { Point2D } from '../../types/scene';
import type { RectGeometry, SelectionColors, MarqueeKind } from './types';

/**
 * Calculate rectangle geometry from start and end points
 */
export function calculateRectGeometry(start: Point2D, end: Point2D): RectGeometry {
  return {
    x: Math.min(start.x, end.x),
    y: Math.min(start.y, end.y),
    width: Math.abs(end.x - start.x),
    height: Math.abs(end.y - start.y)
  };
}

/**
 * Get AutoCAD-style colors for selection
 */
export function getSelectionColors(kind: MarqueeKind): SelectionColors {
  // AutoCAD colors: Blue for Window, Green for Crossing
  const borderColor = kind === 'window' ? '#0080FF' : '#00FF80';
  const fillColor = kind === 'window' ? '#0080FF20' : '#00FF8020';
  
  return { borderColor, fillColor };
}

/**
 * Calculate if polygon is counter-clockwise (Window) or clockwise (Crossing)
 */
export function isCounterClockwise(points: Point2D[]): boolean {
  if (points.length < 3) return true;
  
  let area = 0;
  for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
    area += (points[j].x + points[i].x) * (points[j].y - points[i].y);
  }
  
  return area < 0; // Negative area = CCW
}

/**
 * Generate SVG path data from points
 */
export function generateSVGPath(points: Point2D[]): string {
  return points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
}

/**
 * Filter out invalid/null points
 */
export function filterValidPoints(points: Point2D[]): Point2D[] {
  return points.filter(Boolean);
}