import { UnifiedEntitySelection } from '../../utils/unified-entity-selection';
import type { Point2D, ViewTransform } from '../../config/unified-grid-configuration';
import type { SceneModel } from '../../types/scene';

export function findEntityAtPoint(
  pt: Point2D,
  scene: SceneModel,
  layers: SceneModel['layers'],
  transform: ViewTransform,
  rect: DOMRect,
  tolerancePx = 8
) {
  return UnifiedEntitySelection.findEntityAtPoint(pt, scene.entities, layers, transform, rect, tolerancePx);
}