'use client';

import React, { useMemo } from 'react';
import {
  getGridSettings,
  subscribeToGridSettings,
  worldToScreen,
  type ViewTransform,
  type GridSettings,
  type Point2D,
  type CanvasRect
} from '../systems/coordinates/config';
import {
  calculateGridSpacing,
  getVisibleGridBounds
} from '../systems/coordinates/utils';

interface GridOverlayProps {
  transform: ViewTransform;
  visible?: boolean;
  className?: string;
}

export const GridOverlay: React.FC<GridOverlayProps> = ({
  transform,
  visible = true,
  className = ''
}) => {
  const [gridSettings, setGridSettings] = React.useState<GridSettings>(getGridSettings());

  React.useEffect(() => {
    const unsubscribe = subscribeToGridSettings(setGridSettings);
    return unsubscribe;
  }, []);

  const canvasRect = useMemo(() => ({ width: 2000, height: 2000 }), []);

  const gridData = useMemo(() => {
    if (!visible || !gridSettings.visual.enabled) {
      return null;
    }

    if (!Number.isFinite(transform.scale) || transform.scale <= 0 || !Number.isFinite(transform.offsetX) || !Number.isFinite(transform.offsetY)) {
      console.warn('⚠️ Invalid transform, skipping grid render');
      return null;
    }

    const adaptiveGridStep = calculateGridSpacing(transform.scale, gridSettings.visual.step, gridSettings);
    const gridBounds = getVisibleGridBounds(transform, canvasRect, adaptiveGridStep);
    
    const lines: Array<{start: Point2D; end: Point2D; isMajor: boolean}> = [];

    // Vertical lines
    for (let x = gridBounds.min.x; x <= gridBounds.max.x; x += adaptiveGridStep) {
      const isMajor = Math.abs(x % (adaptiveGridStep * gridSettings.visual.subDivisions)) < 0.01;
      const start = worldToScreen({ x, y: gridBounds.min.y }, transform, canvasRect);
      const end = worldToScreen({ x, y: gridBounds.max.y }, transform, canvasRect);
      lines.push({ start, end, isMajor });
    }

    // Horizontal lines
    for (let y = gridBounds.min.y; y <= gridBounds.max.y; y += adaptiveGridStep) {
      const isMajor = Math.abs(y % (adaptiveGridStep * gridSettings.visual.subDivisions)) < 0.01;
      const start = worldToScreen({ x: gridBounds.min.x, y }, transform, canvasRect);
      const end = worldToScreen({ x: gridBounds.max.x, y }, transform, canvasRect);
      lines.push({ start, end, isMajor });
    }

    return { lines };
  }, [transform, canvasRect, visible, gridSettings]);

  if (!gridData) return null;

  const majorColor = gridSettings.visual.color;
  const minorColor = gridSettings.visual.color;
  const majorOpacity = gridSettings.visual.opacity;
  const minorOpacity = gridSettings.visual.opacity * 0.5;

  return (
    <div 
      className={`absolute inset-0 pointer-events-none ${className}`}
      style={{ zIndex: 1 }}
    >
      <svg
        width={canvasRect.width}
        height={canvasRect.height}
        className="absolute inset-0"
        style={{ overflow: 'visible' }}
      >
        {gridData.lines.map((line, index) => (
          <line
            key={index}
            x1={line.start.x}
            y1={line.start.y}
            x2={line.end.x}
            y2={line.end.y}
            stroke={line.isMajor ? majorColor : minorColor}
            strokeWidth={line.isMajor ? 1 : 0.5}
            strokeOpacity={line.isMajor ? majorOpacity : minorOpacity}
            vectorEffect="non-scaling-stroke"
          />
        ))}
        <OriginIndicator transform={transform} canvasRect={canvasRect} color={majorColor} opacity={majorOpacity} />
      </svg>
    </div>
  );
};

const OriginIndicator: React.FC<{
  transform: ViewTransform;
  canvasRect: CanvasRect;
  color: string;
  opacity: number;
}> = ({ transform, canvasRect, color, opacity }) => {
  const origin = worldToScreen({ x: 0, y: 0 }, transform, canvasRect);
  
  if (origin.x < 0 || origin.x > canvasRect.width || origin.y < 0 || origin.y > canvasRect.height) {
    return null;
  }

  const size = 10;
  
  return (
    <g>
      <line x1={origin.x - size} y1={origin.y} x2={origin.x + size} y2={origin.y} stroke={color} strokeWidth={2} strokeOpacity={opacity} vectorEffect="non-scaling-stroke" />
      <line x1={origin.x} y1={origin.y - size} x2={origin.x} y2={origin.y + size} stroke={color} strokeWidth={2} strokeOpacity={opacity} vectorEffect="non-scaling-stroke" />
      <circle cx={origin.x} cy={origin.y} r={3} fill="none" stroke={color} strokeWidth={1} strokeOpacity={opacity} vectorEffect="non-scaling-stroke" />
    </g>
  );
};

export default GridOverlay;