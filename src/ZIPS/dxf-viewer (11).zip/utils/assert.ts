// src/subapps/dxf-viewer/utils/assert.ts
// Note: assert function removed as unused (ts-prune detected)