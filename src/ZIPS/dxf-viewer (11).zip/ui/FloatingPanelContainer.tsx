'use client';

import React, { useState, useImperativeHandle, forwardRef, useRef } from 'react';
import { useTranslationLazy } from '../../../i18n/hooks/useTranslationLazy';
import { PanelTabs } from './components/PanelTabs';
import { LevelPanel } from './components/LevelPanel';
import { AdminLayerManager } from './components/AdminLayerManager';
import { GripSettingsPanel } from './components/GripSettingsPanel';
import { PropertiesPanel } from './panels/PropertiesPanel';
import { useOverlayManager } from '../state/overlay-manager';
import { useGripContext } from '../providers/GripProvider';
import { StorageStatus } from '../components/StorageStatus';
import { HierarchyDebugPanel } from '../components/HierarchyDebugPanel';
// REMOVED: LayerManagementPanel - replaced with unified overlay system
import { AutoSaveStatus } from './components/AutoSaveStatus';
import type { SceneModel } from '../types/scene';
import type { ToolType } from '../ui/toolbar/types';
import { useLevels } from '../systems/levels';

type PanelType = 'properties' | 'overlay' | 'levels' | 'grips' | 'hierarchy' | 'layers';
export type SideTab = 'levels' | 'properties' | 'hierarchy' | 'overlay' | 'grips' | 'layers';

export type FloatingPanelHandle = {
  showTab: (t: SideTab) => void;
  expandForSelection: (ids: string[], scene?: SceneModel | null) => void;
  scrollFirstSelectedIntoView: () => void;
};

interface FloatingPanelContainerProps {
  sceneModel: SceneModel | null;
  selectedEntityIds: string[];
  onEntitySelect: (ids: string[]) => void;
  zoomLevel: number;
  currentTool: ToolType;
}

export const FloatingPanelContainer = forwardRef<FloatingPanelHandle, FloatingPanelContainerProps>(function FloatingPanelContainer({
  sceneModel: scene,
  selectedEntityIds,
  onEntitySelect,
  zoomLevel,
  currentTool
}, ref) {
  console.log('🎯 FloatingPanelContainer scene debug:', { 
    currentTool, 
    hasScene: !!scene, 
    sceneLayersCount: scene?.layers ? Object.keys(scene.layers).length : 0,
    sceneEntitiesCount: scene?.entities?.length || 0
  });
  const { t, ready, isLoading } = useTranslationLazy('dxf-viewer');
  const [activePanel, setActivePanel] = useState<PanelType>('properties');
  const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set());

  const overlayManager = useOverlayManager();
  const selectedRegions = overlayManager?.selectedRegionIds || [];
  const visibleRegions = overlayManager?.visibleRegions || [];

  const { currentLevelId, setLevelScene, getLevelScene } = useLevels();
  const { gripSettings, updateGripSettings } = useGripContext();

  // Imperative handle for parent control
  useImperativeHandle(ref, () => ({
    showTab: (t: SideTab) => {
      // Map SideTab to PanelType 
      const panelMap: Record<SideTab, PanelType> = {
        'levels': 'levels',
        'properties': 'properties',
        'hierarchy': 'hierarchy',
        'overlay': 'overlay',
        'grips': 'grips',
        'layers': 'layers'
      };
      setActivePanel(panelMap[t]);
    },
    expandForSelection: (ids, scene) => {
      if (!scene || !ids?.length) return;
      const next = new Set(expandedKeys);

      // Helper για ΣΤΑΘΕΡΑ keys (ίδια και στο Properties)
      const layerKey = (name: string) => `layer:${encodeURIComponent(name)}`;
      const subLayerKey = (layer: string, sub: string) => 
        `sublayer:${encodeURIComponent(layer)}:${encodeURIComponent(sub)}`;
      const colorKey = (hex: string) => `layer:${encodeURIComponent(`Color ${hex}`)}`;

      // ❶ Βρες τα groups που περιέχουν τις οντότητες
      ids.forEach(id => {
        const ent = scene.entities.find(e => e.id === id);
        if (!ent) return;
        
        // Κλειδί 1ου επιπέδου: Color Group (όχι layer name)
        const layer = scene.layers[ent.layer];
        if (layer) {
          const color = layer.color || '#ffffff';
          const colorName = `Color ${color}`;
          next.add(layerKey(colorName)); // Αυτό ταιριάζει με το ColorGroupList
        }
        
        // Κλειδί 2ου επιπέδου: το Layer μέσα στο Color Group
        next.add(layerKey(ent.layer));
        
        // Αν έχεις 3ο επίπεδο/υπο-layers:
        const sub = (ent as any).subLayer ?? (ent as any).groupKey;
        if (sub) next.add(subLayerKey(ent.layer, sub));
      });

      console.debug('[FPC] expandForSelection ids=', ids, 'expandedKeys=', Array.from(next));
      setExpandedKeys(next);

      // ❷ Scroll στο πρώτο selected στοιχείο μέσα στη λίστα Properties
      requestAnimationFrame(() => {
        const first = ids[0];
        const el = document.querySelector(`[data-entity-id="${first}"]`) as HTMLElement | null;
        console.debug('[FPC] scrollIntoView element found:', !!el, 'for id:', first);
        el?.scrollIntoView({ block: 'nearest' });
      });
    },
    scrollFirstSelectedIntoView: () => {
      const el = document.querySelector('[data-entity-selected="true"]') as HTMLElement | null;
      el?.scrollIntoView({ block: 'nearest' });
    }
  }), [expandedKeys, setActivePanel]);

  // Don't render panels until translations are ready
  if (isLoading) {
    return (
      <div className="fixed right-4 top-4 bg-gray-900/90 backdrop-blur-sm rounded-lg border border-gray-700 shadow-xl w-80">
        <div className="p-4 text-center text-gray-400">
          Loading translations...
        </div>
      </div>
    );
  }

  // Throttled logging for dev - reduce spam
  if (process.env.NODE_ENV === 'development') {
    const now = Date.now();
    (window as any)._glog ??= { t: 0 };
    if (now - (window as any)._glog.t > 1000) {
      console.log('🎯 [FloatingPanelContainer] GripContext OK');
      (window as any)._glog.t = now;
    }
  }

  const getDisabledPanels = (): Partial<Record<PanelType, boolean>> => {
    return {
      properties: !scene && selectedEntityIds.length === 0 && selectedRegions.length === 0,
      grips: false, // Grips panel always available
    };
  };

  const disabledPanels = getDisabledPanels();

  const handleTabClick = (panel: PanelType) => {
    if (disabledPanels[panel]) return;
    setActivePanel(panel);
  };

  const renderPanelContent = () => {
    console.log('🎯 FloatingPanelContainer renderPanelContent:', { activePanel, currentTool });
    switch (activePanel) {
      case 'properties':
        return (
          <PropertiesPanel
            scene={scene}
            selectedEntityIds={selectedEntityIds}
            selectedRegions={selectedRegions}
            zoomLevel={zoomLevel}
            currentLevelId={currentLevelId}
            onEntitySelect={onEntitySelect}
            setLevelScene={setLevelScene}
            expandedKeys={expandedKeys}
            onExpandChange={setExpandedKeys}
          />
        );

      case 'overlay':
        return (
          <div className="space-y-4">
            <AdminLayerManager className="bg-gray-800 rounded-lg p-4" />
          </div>
        );

      case 'levels':
        console.log('🎯 FloatingPanel rendering LevelPanel with currentTool:', currentTool);
        return (
          <div>
            <LevelPanel 
              currentTool={currentTool}
              onToolChange={(tool) => {
                // We need to communicate with parent to change the tool
                // This will be handled by the parent DxfViewerApp
                console.log('🎯 FloatingPanel: LevelPanel requests tool change to:', tool, 'currentTool was:', currentTool);
                window.dispatchEvent(new CustomEvent('level-panel:tool-change', { detail: tool }));
              }}
            />
          </div>
        );

      case 'grips':
        return (
          <div>
            <GripSettingsPanel
              settings={gripSettings}
              onSettingsChange={updateGripSettings}
            />
          </div>
        );

      case 'hierarchy':
        return (
          <div>
            <HierarchyDebugPanel />
          </div>
        );

      case 'layers':
        // REMOVED: LayerManagementPanel - now uses unified overlay system
        return null;

      default:
        return (
          <div className="text-gray-400 text-center py-8">
            <p>Επιλέξτε ένα panel από τις καρτέλες</p>
          </div>
        );
    }
  };

  return (
    <div className="w-full h-full bg-gray-900 rounded-lg">
      <div className="bg-gray-800 rounded-t-lg border-b border-gray-500">
        <PanelTabs
          activePanel={activePanel}
          onTabClick={handleTabClick}
          disabledPanels={disabledPanels}
          isCollapsed={false}
        />
      </div>

      <div className="flex-1 overflow-y-auto bg-gray-900 text-gray-100 px-2 py-3" style={{ maxHeight: 'calc(100vh - 240px)' }}>
        {renderPanelContent()}
      </div>

      <div className="border-t border-gray-500 px-4 py-3 bg-gray-800 rounded-b-lg space-y-2">
        <AutoSaveStatus />
        <div className="flex justify-between items-center text-xs text-gray-400">
          <span>
            {activePanel === 'properties' && 
              t('panels.properties.description', { 
                selectedCount: selectedEntityIds.length,
                layerCount: scene ? Object.keys(scene.layers).length : 0
              })
            }
            {activePanel === 'overlay' && 
              t('panels.overlay.description', { 
                regionCount: visibleRegions.length 
              })
            }
            {activePanel === 'levels' &&
              t('panels.levels.description')
            }
            {activePanel === 'grips' &&
              t('panels.grips.description')
            }
            {activePanel === 'hierarchy' &&
              t('panels.hierarchy.description')
            }
            {activePanel === 'layers' &&
              t('panels.layers.description')
            }
          </span>
          <span>Zoom: {Math.round(zoomLevel * 100)}%</span>
        </div>
        
        {/* Storage Status */}
        <StorageStatus showDetails={true} className="bg-gray-800 border-gray-600" />
      </div>
    </div>
  );
});