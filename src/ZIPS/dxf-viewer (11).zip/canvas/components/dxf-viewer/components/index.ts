// ============================================================================
// DXF VIEWER PRESENTATIONAL COMPONENTS
// ============================================================================
// Note: Exports removed as they were unused (detected by ts-prune)