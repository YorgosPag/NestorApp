import { MARGINS, type ViewTransform } from '../../config/unified-grid-configuration';

export function drawRulers(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement,
  currentTransform: ViewTransform
) {
  const rect = canvas.getBoundingClientRect();
  const { left, bottom } = MARGINS;
  
  ctx.fillStyle = '#2a2a2a';
  ctx.fillRect(left, rect.height - bottom, rect.width - left, bottom);
  ctx.fillRect(0, 0, left, rect.height - bottom);
  ctx.fillRect(0, rect.height - bottom, left, bottom);
  
  ctx.strokeStyle = '#666';
  ctx.fillStyle = '#ccc';
  ctx.font = '10px monospace';
  ctx.lineWidth = 1;
  
  const stepPx = 50;
  
  for (let x = left; x < rect.width; x += stepPx) {
    const screenOffsetX = x - left;
    const worldX = screenOffsetX / currentTransform.scale - currentTransform.offsetX;
    
    ctx.beginPath();
    ctx.moveTo(x, rect.height - bottom);
    ctx.lineTo(x, rect.height - bottom + 8);
    ctx.stroke();
    
    const displayX = Math.round(worldX);
    ctx.fillText(displayX.toString(), x - 10, rect.height - bottom + 20);
  }
  
  for (let y = 0; y < rect.height - bottom; y += stepPx) {
    const screenOffsetY = (rect.height - bottom) - y;
    const worldY = screenOffsetY / currentTransform.scale - currentTransform.offsetY;
    
    ctx.beginPath();
    ctx.moveTo(left - 8, y);
    ctx.lineTo(left, y);
    ctx.stroke();
    
    const displayY = Math.round(worldY);
    ctx.save();
    ctx.translate(12, y + 5);
    ctx.rotate(-Math.PI / 2);
    ctx.fillText(displayY.toString(), 0, 0);
    ctx.restore();
  }
}

export function drawGrid(
  ctx: CanvasRenderingContext2D,
  canvas: HTMLCanvasElement
) {
  const rect = canvas.getBoundingClientRect();
  const gridSize = 20;
  const { left, bottom } = MARGINS;
  
  ctx.strokeStyle = '#333333';
  ctx.lineWidth = 0.5;
  
  for (let x = left; x < rect.width; x += gridSize) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, rect.height - bottom);
    ctx.stroke();
  }
  
  for (let y = 0; y < rect.height - bottom; y += gridSize) {
    ctx.beginPath();
    ctx.moveTo(left, y);
    ctx.lineTo(rect.width, y);
    ctx.stroke();
  }
}