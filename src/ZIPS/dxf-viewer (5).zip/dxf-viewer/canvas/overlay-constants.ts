// overlay-constants.ts
import type { PropertyStatus } from '../../../constants/statuses';

// Canvas-compatible status colors (CSS variables don't work in canvas)
export const CANVAS_STATUS_COLORS: Record<PropertyStatus, string> = {
  'for-sale':   '#22c55e', // Green
  'for-rent':   '#3b82f6', // Blue
  'reserved':   '#f59e0b', // Orange
  'sold':       '#ef4444', // Red
  'landowner':  '#8b5cf6', // Purple
};

// Helper σε περίπτωση που έρθει άγνωστο status
export function colorForStatus(status?: string): string {
  const fallback = CANVAS_STATUS_COLORS['for-sale'];
  if (!status) return fallback;
  return (CANVAS_STATUS_COLORS as any)[status] || fallback;
}