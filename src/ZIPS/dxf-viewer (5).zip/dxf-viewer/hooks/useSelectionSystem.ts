/**
 * USE SELECTION SYSTEM - LEGACY COMPATIBILITY
 * @deprecated This file provides backward compatibility for existing imports.
 * New code should use ../systems/selection/useSelection
 * This file will be removed in v2.0.0
 */

import { useSelection } from '../systems/selection/SelectionSystem';
import type { RegionStatus, UnitType } from '../types/overlay';

// Re-export types for compatibility
export interface SelectionState {
  selectedRegionIds: string[];
  editingRegionId: string | null;
  draggedVertexIndex: number | null;
  showHandles: boolean;
  showLabels: boolean;
  ghostPreview: boolean;
}

export interface FilterState {
  visibleStatuses: Set<RegionStatus>;
  visibleUnitTypes: Set<UnitType>;
}

export interface SelectionActions {
  selectRegions: (regionIds: string[]) => void;
  selectRegion: (regionId: string) => void;
  clearSelection: () => void;
  addToSelection: (regionId: string) => void;
  removeFromSelection: (regionId: string) => void;
  toggleSelection: (regionId: string) => void;
  setEditingRegion: (regionId: string | null) => void;
  setDraggedVertex: (index: number | null) => void;
  isSelected: (regionId: string) => boolean;
  getSelectionCount: () => number;
}

export interface FilterActions {
  setStatusFilter: (statuses: RegionStatus[]) => void;
  setUnitTypeFilter: (unitTypes: UnitType[]) => void;
  toggleStatusFilter: (status: RegionStatus) => void;
  toggleUnitTypeFilter: (unitType: UnitType) => void;
  clearAllFilters: () => void;
  isStatusVisible: (status: RegionStatus) => boolean;
  isUnitTypeVisible: (unitType: UnitType) => boolean;
}

export interface ViewActions {
  setShowHandles: (show: boolean) => void;
  setShowLabels: (show: boolean) => void;
  setGhostPreview: (show: boolean) => void;
  toggleHandles: () => void;
  toggleLabels: () => void;
  toggleGhostPreview: () => void;
}

// Proxy function that redirects to the new system
export function useSelectionSystem(): SelectionState & SelectionActions & FilterState & FilterActions & ViewActions {
  return useSelection() as any;
}