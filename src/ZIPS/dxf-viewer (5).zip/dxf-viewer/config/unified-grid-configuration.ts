/**
 * ΕΝΟΠΟΙΗΜΕΝΟ GRID CONFIGURATION SYSTEM - LEGACY COMPATIBILITY
 * @deprecated This file provides backward compatibility for existing imports.
 * New code should import from '../systems/coordinates/config'
 * This file will be removed in v2.0.0
 */

// Re-export everything from the new coordinate system
export * from '../systems/coordinates/config';
export * from '../systems/coordinates/utils';

// Legacy compatibility - map old names to new ones
import {
  COORDINATE_LAYOUT
} from '../systems/coordinates/config';

// Export old constant name for compatibility  
export const GRID_LAYOUT = COORDINATE_LAYOUT;