import React from 'react';
import { SceneInfoSection } from '../components/SceneInfoSection';
import { LayersSection } from '../components/LayersSection';
import { SceneModel } from '../../types/scene';
import { LayerOperationsService } from '../../services/LayerOperationsService';
import { EntityMergeService } from '../../services/EntityMergeService';
import { useConfirmationToast } from '../components/layers/hooks/useConfirmationToast';
import { publishHighlight } from '../../events/selection-bus';
import { handleLayerServiceResult } from '../utils/selection-update-utils';

interface PropertiesPanelProps {
  scene: SceneModel | null;
  selectedEntityIds: string[];
  selectedRegions: string[];
  zoomLevel: number;
  currentLevelId: string | null;
  onEntitySelect: (ids: string[]) => void;
  setLevelScene: (levelId: string, scene: SceneModel) => void;
  expandedKeys: Set<string>;
  onExpandChange: (next: Set<string>) => void;
}

export function PropertiesPanel({
  scene,
  selectedEntityIds,
  selectedRegions,
  zoomLevel,
  currentLevelId,
  onEntitySelect,
  setLevelScene,
  expandedKeys,
  onExpandChange
}: PropertiesPanelProps) {
  console.log('🎯 PropertiesPanel render:', { 
    hasScene: !!scene, 
    sceneLayersCount: scene?.layers ? Object.keys(scene.layers).length : 0,
    selectedEntityIdsLength: selectedEntityIds?.length || 0,
    currentLevelId,
    sceneLayerNames: scene?.layers ? Object.keys(scene.layers) : []
  });
  
  const { confirmDelete, confirmMerge } = useConfirmationToast();
  const layerService = new LayerOperationsService();
  const entityService = new EntityMergeService();

  const handleLayerToggle = (layerName: string, visible: boolean) => {
    if (!scene || !currentLevelId) return;
    const result = layerService.toggleLayerVisibility(layerName, visible, scene);
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleLayerDelete = async (layerName: string) => {
    if (!scene || !currentLevelId) return;
    
    const entityCount = scene.entities.filter(entity => entity.layer === layerName).length;
    const confirmed = await confirmDelete('layer', layerName, entityCount);
    if (!confirmed) return;
    
    const result = layerService.deleteLayer(layerName, scene);
    handleLayerServiceResult(result, selectedEntityIds, onEntitySelect, setLevelScene, currentLevelId);
  };

  const handleLayerColorChange = (layerName: string, color: string) => {
    if (!scene || !currentLevelId) return;
    const result = layerService.changeLayerColor(layerName, color, scene);
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleLayerRename = (oldName: string, newName: string) => {
    if (!scene || !currentLevelId) return;
    const result = layerService.renameLayer(oldName, newName, scene);
    if (!result.success && result.message) {
      alert(result.message);
      return;
    }
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleLayerCreate = (name: string, color: string) => {
    if (!scene || !currentLevelId) return;
    const result = layerService.createLayer({ name, color }, scene);
    if (!result.success && result.message) {
      alert(result.message);
      return;
    }
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleEntitiesMerge = async (targetEntityId: string, sourceEntityIds: string[]) => {
    if (!scene || !currentLevelId) return;
    
    const targetEntity = scene.entities.find(e => e.id === targetEntityId);
    if (!targetEntity) return;
    
    const sourceNames = scene.entities
      .filter(e => sourceEntityIds.includes(e.id))
      .map(e => e.name || e.type || e.id.substring(0, 8));
    
    const confirmed = await confirmMerge('entities', targetEntity.name || targetEntity.type || 'Entity', sourceNames);
    if (!confirmed) return;
    
    const result = await entityService.mergeEntities({
      targetEntityId,
      sourceEntityIds,
      scene,
      currentLevelId
    });
    
    if (result.success) {
      if (result.newEntityId) {
        onEntitySelect([result.newEntityId]);
        publishHighlight({ ids: [result.newEntityId] });
      } else {
        onEntitySelect([targetEntityId]);
        publishHighlight({ ids: [targetEntityId] });
      }
      setLevelScene(currentLevelId, result.updatedScene);
    } else if (result.message) {
      alert(result.message);
    }
  };

  const handleLayersMerge = async (targetLayerName: string, sourceLayerNames: string[]) => {
    if (!scene || !currentLevelId) return;
    
    const confirmed = await confirmMerge('layers', targetLayerName, sourceLayerNames);
    if (!confirmed) return;
    
    const result = layerService.mergeLayers(targetLayerName, sourceLayerNames, scene);
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleColorGroupsMerge = async (targetColorGroup: string, sourceColorGroups: string[]) => {
    if (!scene || !currentLevelId) return;
    
    const confirmed = await confirmMerge('colorGroups', targetColorGroup, sourceColorGroups);
    if (!confirmed) return;
    
    const result = layerService.mergeColorGroups(targetColorGroup, sourceColorGroups, scene);
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleEntityToggle = (entityId: string, visible: boolean) => {
    if (!scene || !currentLevelId) return;
    const updatedScene = {
      ...scene,
      entities: scene.entities.map(entity => 
        entity.id === entityId ? { ...entity, visible } : entity
      )
    };
    setLevelScene(currentLevelId, updatedScene);
  };

  const handleEntityDelete = async (entityId: string) => {
    if (!scene || !currentLevelId) return;
    
    const entity = scene.entities.find(e => e.id === entityId);
    if (!entity) return;
    
    const entityName = entity.name || entity.type || `Entity ${entityId.substring(0, 8)}`;
    const confirmed = await confirmDelete('entity', entityName);
    if (!confirmed) return;
    
    const updatedScene = {
      ...scene,
      entities: scene.entities.filter(entity => entity.id !== entityId)
    };
    
    const newSelection = selectedEntityIds.filter(id => id !== entityId);
    if (newSelection.length !== selectedEntityIds.length) {
      onEntitySelect(newSelection);
    }
    setLevelScene(currentLevelId, updatedScene);
  };

  const handleEntityColorChange = (entityId: string, color: string) => {
    if (!scene || !currentLevelId) return;
    
    const entity = scene.entities.find(e => e.id === entityId);
    if (!entity) return;
    
    const existingLayerWithColor = Object.keys(scene.layers).find(layerName => 
      scene.layers[layerName].color === color
    );
    
    let targetLayerName = existingLayerWithColor;
    let updatedLayers = { ...scene.layers };
    
    if (!existingLayerWithColor) {
      const newLayerName = entity.name || `Layer_${color.replace('#', '')}`;
      targetLayerName = newLayerName;
      
      let counter = 1;
      while (updatedLayers[targetLayerName]) {
        targetLayerName = `${newLayerName}_${counter}`;
        counter++;
      }
      
      updatedLayers[targetLayerName] = {
        name: targetLayerName,
        color: color,
        visible: true,
        frozen: false
      };
    }
    
    const updatedScene = {
      ...scene,
      layers: updatedLayers,
      entities: scene.entities.map(e => 
        e.id === entityId ? { 
          ...e, 
          color: color, 
          layer: targetLayerName 
        } : e
      )
    };
    
    setLevelScene(currentLevelId, updatedScene);
  };

  const handleEntityRename = (entityId: string, newName: string) => {
    if (!scene || !currentLevelId) return;
    const updatedScene = {
      ...scene,
      entities: scene.entities.map(entity => 
        entity.id === entityId ? { ...entity, name: newName } : entity
      )
    };
    setLevelScene(currentLevelId, updatedScene);
  };

  const handleColorGroupToggle = (colorGroupName: string, layersInGroup: string[], visible: boolean) => {
    if (!scene || !currentLevelId) return;
    const result = layerService.toggleColorGroup(colorGroupName, layersInGroup, visible, scene);
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleColorGroupDelete = (colorGroupName: string, layersInGroup: string[]) => {
    if (!scene || !currentLevelId) return;
    const result = layerService.deleteColorGroup(colorGroupName, layersInGroup, scene);
    handleLayerServiceResult(result, selectedEntityIds, onEntitySelect, setLevelScene, currentLevelId);
  };

  const handleColorGroupColorChange = (colorGroupName: string, layersInGroup: string[], color: string) => {
    if (!scene || !currentLevelId) return;
    const result = layerService.changeColorGroupColor(colorGroupName, layersInGroup, color, scene);
    if (result.success) {
      setLevelScene(currentLevelId, result.updatedScene);
    }
  };

  const handleColorGroupRename = (oldColorGroupName: string, newColorGroupName: string, layersInGroup: string[]) => {
    console.log(`📝 Renaming Color Group: ${oldColorGroupName} → ${newColorGroupName}`);
    // Color groups are dynamic based on actual colors, so this is primarily UI feedback
  };

  return (
    <div className="space-y-4">
      <SceneInfoSection 
        scene={scene}
        selectedEntityIds={selectedEntityIds}
        selectedRegions={selectedRegions}
        zoomLevel={zoomLevel}
      />
      
      <div className="mt-6">
        <LayersSection
          scene={scene}
          selectedEntityIds={selectedEntityIds}
          onEntitySelectionChange={onEntitySelect}
          onLayerToggle={handleLayerToggle}
          onLayerDelete={handleLayerDelete}
          onLayerColorChange={handleLayerColorChange}
          onLayerRename={handleLayerRename}
          onLayerCreate={handleLayerCreate}
          onEntityToggle={handleEntityToggle}
          onEntityDelete={handleEntityDelete}
          onEntityColorChange={handleEntityColorChange}
          onEntityRename={handleEntityRename}
          onColorGroupToggle={handleColorGroupToggle}
          onColorGroupDelete={handleColorGroupDelete}
          onColorGroupColorChange={handleColorGroupColorChange}
          onColorGroupRename={handleColorGroupRename}
          onEntitiesMerge={handleEntitiesMerge}
          onLayersMerge={handleLayersMerge}
          onColorGroupsMerge={handleColorGroupsMerge}
          expandedKeys={expandedKeys}
          onExpandChange={onExpandChange}
        />
      </div>
    </div>
  );
}