/**
 * COORDINATE SYSTEM
 * Centralized coordinate transformation and management system
 */

// Configuration (types and functions)
export * from './config';

// Utilities
export * from './utils';

// Hooks (can be imported safely)
export { useCoordinates, useCoord } from './useCoordinates';

// Components need to be imported from .tsx files directly
// For components, import directly: import { CoordinateSystem } from './systems/coordinates/CoordinateSystem';

// Re-export main system component for convenience
export { CoordinateSystem, useCoordinatesContext, CoordProvider } from './CoordinateSystem';