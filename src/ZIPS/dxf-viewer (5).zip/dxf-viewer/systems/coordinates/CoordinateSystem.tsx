'use client';

import React, { createContext, useContext, useMemo } from 'react';
import { 
  coordTransforms,
  type Point2D,
  type ViewTransform,
  type CanvasRect
} from './config';

interface CoordinateContextType {
  toWorld: (screenPoint: Point2D, transform: ViewTransform, canvasRect: CanvasRect) => Point2D | null;
  toScreen: (worldPoint: Point2D, transform: ViewTransform, canvasRect: CanvasRect) => Point2D;
}

export const CoordinateContext = createContext<CoordinateContextType | null>(null);

export function CoordinateSystem({ children }: { children: React.ReactNode }) {
  const value = useMemo(() => ({
    toWorld: (screenPoint: Point2D, transform: ViewTransform, canvasRect: CanvasRect) => 
      coordTransforms.screenToWorld(screenPoint, transform, canvasRect),
    toScreen: (worldPoint: Point2D, transform: ViewTransform, canvasRect: CanvasRect) => 
      coordTransforms.worldToScreen(worldPoint, transform, canvasRect),
  }), []);

  return (
    <CoordinateContext.Provider value={value}>
      {children}
    </CoordinateContext.Provider>
  );
}

export function useCoordinates() {
  const context = useContext(CoordinateContext);
  if (!context) {
    throw new Error('useCoordinates must be used within a CoordinateSystem');
  }
  return context;
}

// Backward compatibility - re-export old names
export const CoordProvider = CoordinateSystem;
export const useCoord = useCoordinates;