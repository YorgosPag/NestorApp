/**
 * COORDINATE SYSTEM HOOK
 * Standalone hook for accessing coordinate context
 */

import { useContext } from 'react';

// Import types only to avoid JSX issues
import type { Point2D, ViewTransform, CanvasRect } from './config';

interface CoordinateContextType {
  toWorld: (screenPoint: Point2D, transform: ViewTransform, canvasRect: CanvasRect) => Point2D | null;
  toScreen: (worldPoint: Point2D, transform: ViewTransform, canvasRect: CanvasRect) => Point2D;
}

// Create context type-only reference
declare const CoordinateContext: React.Context<CoordinateContextType | null>;

export function useCoordinates() {
  // Note: This will be properly imported from CoordinateSystem.tsx at runtime
  const context = useContext(CoordinateContext as any);
  if (!context) {
    throw new Error('useCoordinates must be used within a CoordinateSystem');
  }
  return context;
}

// Backward compatibility
export const useCoord = useCoordinates;