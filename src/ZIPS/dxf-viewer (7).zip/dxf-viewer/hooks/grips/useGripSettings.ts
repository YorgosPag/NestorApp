/**
 * useGripSettings
 * Manages grip settings and visual helpers
 */

'use client';

import { useState, useCallback } from 'react';
import type { GripSettings } from '../../types/gripSettings';
import { validateGripSettings, DEFAULT_GRIP_SETTINGS } from '../../types/gripSettings';

export function useGripSettings() {
  const [gripSettings, setGripSettings] = useState<GripSettings>(DEFAULT_GRIP_SETTINGS);

  // Update grip settings with validation
  const updateGripSettings = useCallback((updates: Partial<GripSettings>) => {
    setGripSettings(prev => validateGripSettings({ ...prev, ...updates }));
  }, []);

  // Get grip size based on state
  const getGripSize = useCallback((state: 'cold' | 'warm' | 'hot') => {
    const baseSize = gripSettings.gripSize * gripSettings.dpiScale;
    switch (state) {
      case 'warm': return Math.round(baseSize * 1.2);
      case 'hot': return Math.round(baseSize * 1.4);
      case 'cold':
      default: return Math.round(baseSize);
    }
  }, [gripSettings.gripSize, gripSettings.dpiScale]);

  // Get grip color based on state
  const getGripColor = useCallback((state: 'cold' | 'warm' | 'hot') => {
    return gripSettings.colors[state];
  }, [gripSettings.colors]);

  return {
    gripSettings,
    updateGripSettings,
    getGripSize,
    getGripColor
  };
}