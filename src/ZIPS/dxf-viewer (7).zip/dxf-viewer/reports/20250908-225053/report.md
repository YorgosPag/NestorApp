﻿# Code Analysis Report (20250908-225053)

- Root: `F:\Pagonis_Nestor\src\subapps\dxf-viewer`

- Node: v22.16.0


## ESLint

`"
  AppendToReport ESLint failed: 
  AppendToReport 

## Knip - unused files/exports/deps

`"
  AppendToReport 
  AppendToReport 
