/**
 * Grid Snap Engine
 * Υπεύθυνο για εύρεση snap points σε grid points
 */

import { Point2D, Entity, ExtendedSnapType } from '../extended-types';
import { BaseSnapEngine, SnapEngineContext, SnapEngineResult } from '../shared/BaseSnapEngine';

export class GridSnapEngine extends BaseSnapEngine {
  private gridStep = 50; // Default grid step

  constructor() {
    super(ExtendedSnapType.GRID);
  }

  initialize(entities: Entity[]): void {
    // Grid doesn't need entity initialization
    console.log('🎯 GridSnapEngine: Initialize (no entities needed for grid)');
  }

  findSnapCandidates(cursorPoint: Point2D, context: SnapEngineContext): SnapEngineResult {
    const candidates: any[] = [];
    const priority = 10; // Lower priority than geometric snaps
    
    const radius = context.worldRadiusForType(cursorPoint, ExtendedSnapType.GRID);
    
    // Calculate nearest grid point
    const gridPoint = this.getNearestGridPoint(cursorPoint);
    const distance = Math.sqrt(
      (cursorPoint.x - gridPoint.x) ** 2 + (cursorPoint.y - gridPoint.y) ** 2
    );
    
    if (distance <= radius) {
      const candidate = this.createCandidate(
        gridPoint,
        'Grid',
        distance,
        priority
      );
      
      candidates.push(candidate);
    }

    return { candidates };
  }

  private getNearestGridPoint(point: Point2D): Point2D {
    return {
      x: Math.round(point.x / this.gridStep) * this.gridStep,
      y: Math.round(point.y / this.gridStep) * this.gridStep
    };
  }

  setGridStep(step: number): void {
    this.gridStep = step;
  }

  dispose(): void {
    // Nothing to dispose for grid
  }

  getStats(): {
    gridStep: number;
  } {
    return {
      gridStep: this.gridStep
    };
  }
}