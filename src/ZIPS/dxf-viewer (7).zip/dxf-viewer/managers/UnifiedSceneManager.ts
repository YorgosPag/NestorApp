/**
 * Unified Scene Manager - Refactored  
 * Single source of truth για scene management using specialized components
 */

import { dlog } from '../utils/OptimizedLogger';
import { SceneUpdateManager } from './SceneUpdateManager';

interface Scene {
  entities: any[];
  layers: Record<string, any>;
  version: number;
  metadata?: any;
  [key: string]: any;
}

interface SceneUpdateOptions {
  skipRendererUpdate?: boolean;
  source?: string;
  reason?: string;
}

export class UnifiedSceneManager {
  private updateManager: SceneUpdateManager;

  constructor() {
    this.updateManager = new SceneUpdateManager();
    dlog('🎭 UnifiedSceneManager created');
  }

  // ═══ INITIALIZATION ═══

  setRenderer(renderer: any): void {
    this.updateManager.setRenderer(renderer);
  }

  setReactSetScene(setScene: (scene: Scene | null) => void): void {
    this.updateManager.setReactSetScene(setScene);
  }

  // ═══ SINGLE SOURCE OF TRUTH UPDATES ═══

  updateScene(
    newScene: Scene | null, 
    options: SceneUpdateOptions = {}
  ): void {
    this.updateManager.updateScene(newScene, options);
  }

  // ═══ CONVENIENCE METHODS ═══

  getCurrentScene(): Scene | null {
    return this.updateManager.getCurrentScene();
  }

  getCurrentVersion(): number {
    return this.updateManager.getCurrentVersion();
  }

  updateEntity(entityId: string, updates: any, source = 'entity-update'): void {
    this.updateManager.updateEntity(entityId, updates, source);
  }

  addEntity(entity: any, source = 'add-entity'): void {
    this.updateManager.addEntity(entity, source);
  }

  removeEntity(entityId: string, source = 'remove-entity'): void {
    this.updateManager.removeEntity(entityId, source);
  }

  // ═══ EMERGENCY METHODS ═══

  forceRendererSync(): void {
    this.updateManager.forceRendererSync();
  }

  resetScene(source = 'reset'): void {
    this.updateManager.resetScene(source);
  }

  // ═══ DEBUG & STATS ═══

  getStats() {
    return this.updateManager.getStats();
  }

  debugCurrentScene() {
    const currentScene = this.updateManager.getCurrentScene();
    if (currentScene) {
      console.log('🎭 Current Scene:', {
        version: currentScene.version,
        entities: currentScene.entities.length,
        layers: Object.keys(currentScene.layers).length,
        metadata: currentScene.metadata
      });
    } else {
      console.log('❌ No current scene');
    }
  }

  // ═══ CLEANUP ═══

  dispose(): void {
    this.updateManager.dispose();
    dlog('🎭 UnifiedSceneManager disposed');
  }
}

// ═══ SINGLETON INSTANCE ═══
export const unifiedSceneManager = new UnifiedSceneManager();

// ═══ CONVENIENCE FUNCTIONS ═══

export function setScene(scene: Scene | null, options?: SceneUpdateOptions): void {
  unifiedSceneManager.updateScene(scene, options);
}

export function getCurrentScene(): Scene | null {
  return unifiedSceneManager.getCurrentScene();
}

export function updateEntity(entityId: string, updates: any): void {
  unifiedSceneManager.updateEntity(entityId, updates);
}

export function getSceneStats() {
  return unifiedSceneManager.getStats();
}

// Debug helpers
if (typeof window !== 'undefined' && process.env.NODE_ENV !== 'production') {
  (window as any).debugScene = {
    manager: unifiedSceneManager,
    stats: getSceneStats,
    current: getCurrentScene,
    debug: () => unifiedSceneManager.debugCurrentScene()
  };
}