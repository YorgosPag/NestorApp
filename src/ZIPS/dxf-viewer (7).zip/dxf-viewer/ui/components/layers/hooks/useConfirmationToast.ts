'use client';

import React, { useCallback } from 'react';
import { useNotifications } from '../../../../../../providers/NotificationProvider';
import { useTranslation } from '../../../../../../i18n';
import { ConfirmationToast } from '../components/ConfirmationToast';

interface ConfirmationOptions {
  title: string;
  message: string;
  confirmText?: string;
  cancelText?: string;
  destructive?: boolean;
  irreversible?: boolean;
}

export function useConfirmationToast() {
  const notifications = useNotifications();
  const { t } = useTranslation('dxf-viewer');

  const showConfirm = useCallback(
    async (options: ConfirmationOptions): Promise<boolean> => {
      const {
        title,
        message,
        confirmText = 'Επιβεβαίωση',
        cancelText = 'Ακύρωση',
        destructive = false,
        irreversible = false
      } = options;

      return new Promise((resolve) => {
        const toastId = `confirm-${Date.now()}`;

        // Δημιουργία custom confirmation toast
        const confirmationToast = React.createElement(ConfirmationToast, {
          title,
          message,
          confirmText,
          cancelText,
          destructive,
          irreversible,
          onConfirm: () => {
            notifications.dismiss(toastId);
            notifications.success('✅ Ενέργεια επιβεβαιώθηκε');
            resolve(true);
          },
          onCancel: () => {
            notifications.dismiss(toastId);
            notifications.info('ℹ️ Ενέργεια ακυρώθηκε');
            resolve(false);
          }
        });

        // Εμφάνιση confirmation toast με custom cancel
        notifications.notify(title, {
          id: toastId,
          type: destructive ? 'warning' : 'info',
          duration: 0, // Persistent
          dismissible: true,
          content: message,
          actions: [{
            label: confirmText,
            onClick: () => {
              notifications.dismiss(toastId);
              notifications.success('✅ Ενέργεια επιβεβαιώθηκε');
              resolve(true);
            }
          }],
          cancel: {
            label: cancelText,
            onClick: () => {
              notifications.dismiss(toastId);
              notifications.info('ℹ️ Ενέργεια ακυρώθηκε');
              resolve(false);
            }
          }
        });
      });
    },
    [notifications]
  );

  const confirmDelete = useCallback(
    (itemType: 'layer' | 'entity' | 'colorGroup', itemName: string, entityCount?: number) => {
      let title = '';
      let message = '';
      
      if (itemType === 'layer') {
        title = 'Διαγραφή Layer';
        message = `Πρόκειται να διαγράψετε το layer "${itemName}".`;
        
        if (entityCount !== undefined) {
          if (entityCount === 0) {
            message += '\n\nΤο layer είναι κενό.';
          } else {
            message += `\n\nΘα διαγραφ${entityCount === 1 ? 'εί' : 'ούν'} ${entityCount} οντότητ${entityCount === 1 ? 'α' : 'ες'}.`;
          }
          message += '\n\nΌλες οι οντότητες αυτού του layer θα χαθούν οριστικά.';
        }
      } else if (itemType === 'entity') {
        title = 'Διαγραφή Οντότητας';
        message = `Πρόκειται να διαγράψετε την οντότητα "${itemName}".\n\nΗ οντότητα θα αφαιρεθεί οριστικά από το σχέδιο.`;
      } else {
        title = 'Διαγραφή Color Group';
        message = `Πρόκειται να διαγράψετε το color group "${itemName}".\n\nΌλα τα layers και οι οντότητες αυτού του color group θα χαθούν οριστικά.`;
      }
      
      return showConfirm({
        title,
        message,
        confirmText: 'Διαγραφή',
        destructive: true,
        irreversible: true
      });
    },
    [showConfirm]
  );

  const confirmMerge = useCallback(
    (mergeType: 'entities' | 'layers' | 'colorGroups', targetName: string, sourceNames: string[]) => {
      let title = '';
      let message = '';
      
      if (mergeType === 'colorGroups') {
        title = 'Ιεραρχική Συγχώνευση Color Groups';
        message = `Πρόκειται να συγχωνεύσετε ${sourceNames.length} color groups στο "${targetName}".`;
        message += `\n\nΠηγές για συγχώνευση: ${sourceNames.join(', ')}`;
        message += '\n\nΌλα τα layers από τα πηγαία color groups θα μεταφερθούν στο color group-στόχο. Τα πηγαία color groups θα εξαφανιστούν αλλά τα layers και οι οντότητες θα διατηρηθούν.';
      } else if (mergeType === 'layers') {
        title = 'Συγχώνευση Layers';
        message = `Πρόκειται να συγχωνεύσετε ${sourceNames.length} layers στο "${targetName}".`;
        message += `\n\nΠηγές για συγχώνευση: ${sourceNames.join(', ')}`;
        message += '\n\nΌλες οι οντότητες από τα πηγαία layers θα μεταφερθούν στο layer-στόχο και τα πηγαία layers θα διαγραφούν.';
      } else {
        title = 'Συγχώνευση Οντοτήτων';
        message = `Πρόκειται να συγχωνεύσετε ${sourceNames.length} οντότητες στην "${targetName}".`;
        message += `\n\nΠηγές για συγχώνευση: ${sourceNames.join(', ')}`;
        message += '\n\nΟι πηγαίες οντότητες θα διαγραφούν και όλα τα χαρακτηριστικά τους θα μεταφερθούν στην οντότητα-στόχο.';
      }
      
      return showConfirm({
        title,
        message,
        confirmText: 'Συγχώνευση',
        destructive: false,
        irreversible: true
      });
    },
    [showConfirm]
  );

  return {
    showConfirm,
    confirmDelete,
    confirmMerge
  };
}