/**
 * ΕΝΟΠΟΙΗΜΕΝΗ ΔΙΑΜΟΡΦΩΣΗ GRIPS - AutoCAD Style
 * Κεντρική διαχείριση όλων των grips settings και behaviors
 * Βασισμένο στο AutoCAD grips paradigm
 */

// ===== TYPES =====
export interface GripsSettings {
  // Visual appearance
  appearance: {
    enabled: boolean;
    size: number;              // Grip size σε pixels
    color: string;             // Default grip color (vertex grips)
    hoverColor: string;        // Hover state color
    selectedColor: string;     // Selected grip color
    edgeColor: string;         // Edge/midpoint grip color (για διαφοροποίηση)
    lineWidth: number;         // Grip border width
    shape: 'square' | 'circle' | 'diamond'; // AutoCAD-style shapes
  };
  
  // AutoCAD-style behavior
  behavior: {
    snapToGrid: boolean;       // Snap grips to grid
    snapToEntities: boolean;   // Snap to other entities
    showDimensions: boolean;   // Show dimension feedback
    multiSelect: boolean;      // Multi-grip selection
    rubberBand: boolean;       // Rubber band preview
  };
  
  // Interaction settings
  interaction: {
    clickTolerance: number;    // Click tolerance σε pixels
    dragThreshold: number;     // Minimum drag distance
    hoverDelay: number;        // Hover feedback delay
    doubleClickEdit: boolean;  // Double-click για edit mode
  };
  
  // Performance settings
  performance: {
    maxGrips: number;          // Maximum grips να εμφανίζονται
    useRAF: boolean;           // RAF-based updates
    throttleMs: number;        // Throttling για updates
  };
}

export interface GripState {
  id: string;
  type: 'vertex' | 'midpoint' | 'center' | 'corner';
  position: { x: number; y: number };
  worldPosition: { x: number; y: number };
  entityId: string;
  vertexIndex?: number;
  isSelected: boolean;
  isHovered: boolean;
  isActive: boolean;
}

export interface GripsInteractionState {
  selectedGrips: GripState[];
  hoveredGrip: GripState | null;
  isDragging: boolean;
  dragStartPosition: { x: number; y: number } | null;
  dragCurrentPosition: { x: number; y: number } | null;
  editMode: boolean;
}

// ===== DEFAULT AUTOCAD-STYLE CONFIGURATION =====
export const DEFAULT_GRIPS_SETTINGS: GripsSettings = {
  appearance: {
    enabled: true,
    size: 6,                   // AutoCAD default grip size
    color: '#0080ff',          // AutoCAD blue (vertex grips)
    hoverColor: '#ff8000',     // AutoCAD orange
    selectedColor: '#ff0000',  // AutoCAD red
    edgeColor: '#00ff80',      // Πράσινο για τα μεσαία grips (edge/midpoint)
    lineWidth: 1,
    shape: 'square'            // AutoCAD default
  },
  
  behavior: {
    snapToGrid: true,          // AutoCAD-style snapping
    snapToEntities: true,
    showDimensions: true,      // Real-time dimension display
    multiSelect: true,         // Multi-grip operations
    rubberBand: true           // Preview feedback
  },
  
  interaction: {
    clickTolerance: 8,         // AutoCAD-style tolerance
    dragThreshold: 3,
    hoverDelay: 250,           // Quarter second delay
    doubleClickEdit: true      // AutoCAD-style editing
  },
  
  performance: {
    maxGrips: 100,             // Reasonable limit
    useRAF: true,              // Smooth updates
    throttleMs: 16             // ~60fps
  }
};

// ===== STORAGE MANAGEMENT =====
const STORAGE_KEY = "autocad_grips_settings";

export class GripsConfiguration {
  private static instance: GripsConfiguration;
  private settings: GripsSettings;
  private listeners: Set<(settings: GripsSettings) => void> = new Set();

  private constructor() {
    this.settings = this.loadSettings();
  }

  static getInstance(): GripsConfiguration {
    if (!GripsConfiguration.instance) {
      GripsConfiguration.instance = new GripsConfiguration();
    }
    return GripsConfiguration.instance;
  }

  // Settings management
  getSettings(): GripsSettings {
    return { ...this.settings };
  }

  updateSettings(updates: Partial<GripsSettings>): void {
    this.settings = {
      ...this.settings,
      ...updates,
      appearance: { ...this.settings.appearance, ...updates.appearance },
      behavior: { ...this.settings.behavior, ...updates.behavior },
      interaction: { ...this.settings.interaction, ...updates.interaction },
      performance: { ...this.settings.performance, ...updates.performance }
    };
    
    this.saveSettings();
    this.notifyListeners();
  }

  resetToDefaults(): void {
    this.settings = { ...DEFAULT_GRIPS_SETTINGS };
    this.saveSettings();
    this.notifyListeners();
  }

  // Event listening
  subscribe(listener: (settings: GripsSettings) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notifyListeners(): void {
    this.listeners.forEach(listener => listener(this.settings));
    
    // Global event για legacy compatibility
    window.dispatchEvent(new CustomEvent('autocad-grips-change', {
      detail: this.settings
    }));
  }

  // Storage operations
  private loadSettings(): GripsSettings {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        return {
          ...DEFAULT_GRIPS_SETTINGS,
          ...parsed,
          appearance: { ...DEFAULT_GRIPS_SETTINGS.appearance, ...parsed.appearance },
          behavior: { ...DEFAULT_GRIPS_SETTINGS.behavior, ...parsed.behavior },
          interaction: { ...DEFAULT_GRIPS_SETTINGS.interaction, ...parsed.interaction },
          performance: { ...DEFAULT_GRIPS_SETTINGS.performance, ...parsed.performance }
        };
      }
    } catch (error) {
      console.warn('Failed to load grips settings:', error);
    }
    return { ...DEFAULT_GRIPS_SETTINGS };
  }

  private saveSettings(): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.settings));
    } catch (error) {
      console.warn('Failed to save grips settings:', error);
    }
  }
}

// ===== SINGLETON INSTANCE =====
export const gripsConfig = GripsConfiguration.getInstance();

// ===== UTILITY FUNCTIONS =====
export function getGripsSettings(): GripsSettings {
  return gripsConfig.getSettings();
}

export function updateGripsSettings(updates: Partial<GripsSettings>): void {
  gripsConfig.updateSettings(updates);
}

export function subscribeToGripsSettings(
  listener: (settings: GripsSettings) => void
): () => void {
  return gripsConfig.subscribe(listener);
}

// ===== GRIP UTILITIES =====
export function createGripId(entityId: string, type: string, index?: number): string {
  return `grip_${entityId}_${type}${index !== undefined ? `_${index}` : ''}`;
}

export function isGripInTolerance(
  gripPosition: { x: number; y: number },
  testPosition: { x: number; y: number },
  tolerance: number
): boolean {
  const dx = gripPosition.x - testPosition.x;
  const dy = gripPosition.y - testPosition.y;
  return Math.sqrt(dx * dx + dy * dy) <= tolerance;
}

// Legacy compatibility
export { GripsConfiguration as AutoCADGripsConfig };
