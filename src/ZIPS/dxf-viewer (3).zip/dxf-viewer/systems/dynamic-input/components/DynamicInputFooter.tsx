'use client';

import React from 'react';
import type { Phase } from './hooks/useDynamicInputState';

interface DynamicInputFooterProps {
  activeTool: string;
  drawingPhase: Phase;
}

export function DynamicInputFooter({ activeTool, drawingPhase }: DynamicInputFooterProps) {
  return (
    <div className="text-xs text-gray-400 mt-2 border-t border-gray-600 pt-2">
      <div className="text-blue-400 font-semibold mb-1">
        {activeTool === 'line' 
          ? drawingPhase === 'first-point'
            ? '🔐 Line (1st point): X→Y→°→L | ή X→Y→°(κενό)→Enter για 2ο σημείο'
            : '🔐 Line (2nd point): X→Y→Enter (complete line)'
          : '✅ Flow: X → Y → L → Enter (δημιουργεί σημείο)'
        }
      </div>
      <div className="text-orange-400 text-xs">
        {activeTool === 'line' 
          ? '⚠️ 1ο σημείο: °+L = άμεση γραμμή | Κενό ° = 2ο σημείο | Angle: 0-360°'
          : '⚠️ Length: Μόνο θετικές τιμές (χωρίς μείον)'
        }
      </div>
      <div className="text-xs text-gray-500 mt-1">
        Tab: Επόμενο πεδίο | Enter: Εφαρμογή | Esc: Ακύρωση
      </div>
    </div>
  );
}