/**
 * CONSTRAINTS SYSTEM HOOK
 * Standalone hook for accessing ortho/polar constraints context and utilities
 */

import { useContext } from 'react';
import type {
  ConstraintType,
  ConstraintDefinition,
  ConstraintsState,
  ConstraintsSettings,
  OrthoConstraintSettings,
  PolarConstraintSettings,
  ConstraintContext,
  ConstraintResult,
  ConstraintOperation,
  ConstraintOperationResult,
  ConstraintPreset,
  PolarCoordinates,
  CartesianCoordinates
} from './config';
import type { Point2D } from '../coordinates/config';

// Context type (will be properly typed when connected to ConstraintsSystem)
interface ConstraintsContextType {
  // State
  state: ConstraintsState;
  
  // Ortho Constraints
  enableOrtho: () => void;
  disableOrtho: () => void;
  toggleOrtho: () => void;
  isOrthoEnabled: () => boolean;
  updateOrthoSettings: (updates: Partial<OrthoConstraintSettings>) => void;
  getOrthoSettings: () => OrthoConstraintSettings;
  
  // Polar Constraints
  enablePolar: () => void;
  disablePolar: () => void;
  togglePolar: () => void;
  isPolarEnabled: () => boolean;
  updatePolarSettings: (updates: Partial<PolarConstraintSettings>) => void;
  getPolarSettings: () => PolarConstraintSettings;
  setPolarBasePoint: (point: Point2D) => void;
  setPolarBaseAngle: (angle: number) => void;
  
  // Constraint Management
  addConstraint: (constraint: ConstraintDefinition) => Promise<ConstraintOperationResult>;
  removeConstraint: (constraintId: string) => Promise<ConstraintOperationResult>;
  enableConstraint: (constraintId: string) => void;
  disableConstraint: (constraintId: string) => void;
  toggleConstraint: (constraintId: string) => void;
  getConstraint: (constraintId: string) => ConstraintDefinition | undefined;
  getConstraints: () => Record<string, ConstraintDefinition>;
  getActiveConstraints: () => ConstraintDefinition[];
  clearConstraints: () => void;
  
  // Constraint Application
  applyConstraints: (point: Point2D, context?: Partial<ConstraintContext>) => ConstraintResult;
  validatePoint: (point: Point2D, context?: Partial<ConstraintContext>) => boolean;
  getConstrainedPoint: (point: Point2D, context?: Partial<ConstraintContext>) => Point2D;
  
  // Coordinate Conversion
  cartesianToPolar: (point: Point2D, basePoint?: Point2D, baseAngle?: number) => PolarCoordinates;
  polarToCartesian: (polar: PolarCoordinates, basePoint?: Point2D) => CartesianCoordinates;
  
  // Angle Utilities
  normalizeAngle: (angle: number) => number;
  snapToAngle: (angle: number, angleStep: number, tolerance: number) => number | null;
  getAngleBetweenPoints: (point1: Point2D, point2: Point2D) => number;
  getDistanceBetweenPoints: (point1: Point2D, point2: Point2D) => number;
  
  // Constraint Context Management
  setConstraintContext: (context: Partial<ConstraintContext>) => void;
  updateConstraintContext: (updates: Partial<ConstraintContext>) => void;
  getConstraintContext: () => ConstraintContext | null;
  clearConstraintContext: () => void;
  
  // Keyboard/Mouse Modifiers
  handleKeyDown: (event: KeyboardEvent) => boolean;
  handleKeyUp: (event: KeyboardEvent) => boolean;
  handleMouseMove: (point: Point2D, modifiers: { shift: boolean; ctrl: boolean; alt: boolean }) => ConstraintResult;
  
  // Settings Management
  updateSettings: (updates: Partial<ConstraintsSettings>) => void;
  resetSettings: () => void;
  getSettings: () => ConstraintsSettings;
  
  // Presets
  loadPreset: (presetId: string) => void;
  savePreset: (name: string, description: string) => ConstraintPreset;
  getPresets: () => ConstraintPreset[];
  deletePreset: (presetId: string) => void;
  
  // Performance and Optimization
  isEnabled: () => boolean;
  isTemporarilyDisabled: () => boolean;
  temporarilyDisable: (duration?: number) => void;
  enable: () => void;
  disable: () => void;
  
  // Visual Feedback
  getRenderData: () => any;
  shouldShowFeedback: () => boolean;
  getConstraintLines: () => Array<{ start: Point2D; end: Point2D; color: string; style: string }>;
  getConstraintMarkers: () => Array<{ position: Point2D; type: string; color: string }>;
  
  // Validation
  validateConstraint: (constraint: ConstraintDefinition) => { valid: boolean; errors: string[] };
  validateSettings: (settings: ConstraintsSettings) => { valid: boolean; errors: string[] };
  
  // Export/Import
  exportSettings: () => string;
  importSettings: (data: string) => Promise<ConstraintOperationResult>;
  exportConstraints: () => string;
  importConstraints: (data: string) => Promise<ConstraintOperationResult>;
}

export function useConstraints(): ConstraintsContextType {
  const { ConstraintsContext } = require('./ConstraintsSystem');
  const context = useContext(ConstraintsContext);
  if (!context) {
    throw new Error('useConstraints must be used within a ConstraintsSystem');
  }
  return context;
}

// Additional convenience hooks
export function useOrthoConstraints() {
  const constraints = useConstraints();
  return {
    enabled: constraints.isOrthoEnabled(),
    settings: constraints.getOrthoSettings(),
    enable: constraints.enableOrtho,
    disable: constraints.disableOrtho,
    toggle: constraints.toggleOrtho,
    updateSettings: constraints.updateOrthoSettings
  };
}

export function usePolarConstraints() {
  const constraints = useConstraints();
  return {
    enabled: constraints.isPolarEnabled(),
    settings: constraints.getPolarSettings(),
    enable: constraints.enablePolar,
    disable: constraints.disablePolar,
    toggle: constraints.togglePolar,
    updateSettings: constraints.updatePolarSettings,
    setBasePoint: constraints.setPolarBasePoint,
    setBaseAngle: constraints.setPolarBaseAngle
  };
}

export function useConstraintApplication() {
  const constraints = useConstraints();
  return {
    applyConstraints: constraints.applyConstraints,
    validatePoint: constraints.validatePoint,
    getConstrainedPoint: constraints.getConstrainedPoint,
    context: constraints.getConstraintContext(),
    setContext: constraints.setConstraintContext,
    updateContext: constraints.updateConstraintContext
  };
}

export function useConstraintManagement() {
  const constraints = useConstraints();
  return {
    constraints: constraints.getConstraints(),
    activeConstraints: constraints.getActiveConstraints(),
    addConstraint: constraints.addConstraint,
    removeConstraint: constraints.removeConstraint,
    enableConstraint: constraints.enableConstraint,
    disableConstraint: constraints.disableConstraint,
    toggleConstraint: constraints.toggleConstraint,
    clearConstraints: constraints.clearConstraints
  };
}

export function useCoordinateConversion() {
  const constraints = useConstraints();
  return {
    cartesianToPolar: constraints.cartesianToPolar,
    polarToCartesian: constraints.polarToCartesian,
    normalizeAngle: constraints.normalizeAngle,
    snapToAngle: constraints.snapToAngle,
    getAngleBetweenPoints: constraints.getAngleBetweenPoints,
    getDistanceBetweenPoints: constraints.getDistanceBetweenPoints
  };
}

export function useConstraintSettings() {
  const constraints = useConstraints();
  return {
    settings: constraints.getSettings(),
    updateSettings: constraints.updateSettings,
    resetSettings: constraints.resetSettings,
    loadPreset: constraints.loadPreset,
    savePreset: constraints.savePreset,
    getPresets: constraints.getPresets(),
    deletePreset: constraints.deletePreset
  };
}

export function useConstraintInput() {
  const constraints = useConstraints();
  return {
    handleKeyDown: constraints.handleKeyDown,
    handleKeyUp: constraints.handleKeyUp,
    handleMouseMove: constraints.handleMouseMove,
    isEnabled: constraints.isEnabled(),
    temporarilyDisable: constraints.temporarilyDisable,
    enable: constraints.enable,
    disable: constraints.disable
  };
}

export function useConstraintVisualization() {
  const constraints = useConstraints();
  return {
    renderData: constraints.getRenderData(),
    shouldShowFeedback: constraints.shouldShowFeedback(),
    constraintLines: constraints.getConstraintLines(),
    constraintMarkers: constraints.getConstraintMarkers()
  };
}

// Legacy hook names for backward compatibility
export const useOrtho = useOrthoConstraints;
export const usePolar = usePolarConstraints;
export const useOrthoPolar = useConstraints;