/**
 * GRIPS SYSTEM HOOK
 * Unified hook for accessing grips functionality
 */

// Re-export existing hooks and utilities
export { useGripContext, useGripContext as useGripManager } from '../../providers/GripProvider';
export { useUnifiedGripsSystem } from '../../hooks/grips/useUnifiedGripsSystem';

// Import for additional functionality
import { useGripContext } from '../../providers/GripProvider';
import { useUnifiedGripsSystem } from '../../hooks/grips/useUnifiedGripsSystem';

/**
 * Main grips hook that provides all grips functionality
 */
export function useGrips() {
  return useGripContext();
}

/**
 * Hook for grip settings management
 */
export function useGripSettings() {
  const context = useGripContext();
  return {
    gripSettings: context.gripSettings,
    updateGripSettings: context.updateGripSettings,
    getGripSize: context.getGripSize,
    getGripColor: context.getGripColor,
  };
}

/**
 * Hook for enhanced grips system with AutoCAD-style features
 */
export function useGripInteraction(scene?: any, onSceneChange?: (scene: any) => void) {
  return useUnifiedGripsSystem(scene, onSceneChange);
}

// Backward compatibility
export const useGrip = useGrips;
export const useGripSystem = useGrips;