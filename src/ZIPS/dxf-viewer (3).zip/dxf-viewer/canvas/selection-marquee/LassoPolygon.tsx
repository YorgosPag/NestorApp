import React from 'react';
import type { LassoPolygonProps } from './types';
import { isCounterClockwise, getSelectionColors, generateSVGPath } from './utils';

export function LassoPolygon({ points }: LassoPolygonProps) {
  if (points.length < 2) return null;

  const isWindow = isCounterClockwise(points);
  const kind = isWindow ? 'window' : 'crossing';
  const { borderColor, fillColor } = getSelectionColors(kind);
  const pathData = generateSVGPath(points);

  return (
    <svg 
      className="absolute inset-0 w-full h-full"
      style={{ pointerEvents: 'none' }}
    >
      <path
        d={pathData}
        fill={fillColor}
        stroke={borderColor}
        strokeWidth="2"
        strokeDasharray={isWindow ? "0" : "8,4"}
      />
      
      {/* Vertex dots */}
      {points.map((point, i) => (
        <circle
          key={i}
          cx={point.x}
          cy={point.y}
          r="3"
          fill={borderColor}
          stroke="white"
          strokeWidth="1"
        />
      ))}
    </svg>
  );
}