// overlay-utils.ts
import type { Point2D } from '../overlays/types';

export function pointInPolygon(point: Point2D, polygon: Array<[number, number]>): boolean {
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const yi = polygon[i][1], yj = polygon[j][1];
    const xi = polygon[i][0], xj = polygon[j][0];
    const intersect = ((yi > point.y) !== (yj > point.y)) &&
      (point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi);
    if (intersect) inside = !inside;
  }
  return inside;
}

export function distanceToLineSegment(point: Point2D, p1: [number, number], p2: [number, number]): number {
  const A = point.x - p1[0];
  const B = point.y - p1[1];
  const C = p2[0] - p1[0];
  const D = p2[1] - p1[1];

  const dot = A * C + B * D;
  const lenSq = C * C + D * D;
  if (lenSq === 0) return Math.hypot(A, B);

  const t = Math.max(0, Math.min(1, dot / lenSq));
  const xx = p1[0] + t * C;
  const yy = p1[1] + t * D;
  return Math.hypot(point.x - xx, point.y - yy);
}

export function worldToScreen(point: [number, number], transform: { scale: number; offsetX: number; offsetY: number }): [number, number] {
  return [
    point[0] * transform.scale + transform.offsetX,
    point[1] * transform.scale + transform.offsetY
  ];
}

export function screenToWorld(point: Point2D, transform: { scale: number; offsetX: number; offsetY: number }): Point2D {
  return {
    x: (point.x - transform.offsetX) / transform.scale,
    y: (point.y - transform.offsetY) / transform.scale
  };
}