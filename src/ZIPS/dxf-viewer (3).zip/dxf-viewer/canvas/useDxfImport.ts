import { useState } from 'react';
import type { SceneModel } from '../types/scene';
import { dxfImportService } from '../io/dxf-import';

export function useDxfImport() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const importDxfFile = async (file: File): Promise<SceneModel | null> => {
    setIsLoading(true);
    setError(null);
    
    console.log('🔄 Starting DXF import for file:', file.name, 'Size:', file.size, 'Type:', file.type);
    
    try {
      const result = await dxfImportService.importDxfFile(file);
      
      console.log('📊 DXF Import result:', {
        success: result.success,
        hasScene: !!result.scene,
        error: result.error,
        stats: result.stats
      });
      
      if (result.success && result.scene) {
        console.log('✅ DXF import successful:', {
          entities: result.scene.entities.length,
          layers: Object.keys(result.scene.layers).length,
          bounds: result.scene.bounds
        });
        return result.scene;
      } else {
        const errorMsg = result.error || 'Import failed - unknown reason';
        console.error('❌ DXF import failed:', errorMsg);
        setError(errorMsg);
        return null;
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error';
      console.error('⛔ Exception during DXF import:', err);
      setError(errorMessage);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    importDxfFile,
    isLoading,
    error,
    clearError: () => setError(null)
  };
}