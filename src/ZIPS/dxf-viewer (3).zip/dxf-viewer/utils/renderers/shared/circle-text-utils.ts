/**
 * Circle Text Rendering Utilities
 * Shared utilities for rendering text on circles
 */

import type { Point2D } from '../../../systems/coordinates/config';

/**
 * Render area and circumference text on circle
 */
export function renderCircleAreaText(
  ctx: CanvasRenderingContext2D,
  screenCenter: Point2D,
  screenRadius: number,
  area: number,
  circumference: number
): void {
  ctx.fillText(`Εμβαδόν: ${area.toFixed(2)}`, screenCenter.x, screenCenter.y - screenRadius / 2);
  ctx.fillText(`Περιφέρεια: ${circumference.toFixed(2)}`, screenCenter.x, screenCenter.y + screenRadius / 2);
}