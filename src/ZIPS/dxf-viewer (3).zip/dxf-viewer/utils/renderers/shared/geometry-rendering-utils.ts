/**
 * Geometry rendering utilities  
 * Consolidates duplicate geometric calculation and rendering patterns
 */

import type { Point2D } from '../../../systems/coordinates/config';
import type { EntityModel } from '../BaseEntityRenderer';

/**
 * Extract and validate angle measurement points from entity
 */
export function extractAngleMeasurementPoints(entity: EntityModel): {
  vertex: Point2D;
  point1: Point2D;
  point2: Point2D;
  angle: number;
} | null {
  const vertex = entity.vertex as Point2D;
  const point1 = entity.point1 as Point2D;
  const point2 = entity.point2 as Point2D;
  const angle = entity.angle as number;
  
  if (!vertex || !point1 || !point2) return null;
  
  return { vertex, point1, point2, angle };
}

/**
 * Calculate distance between two points
 */
export function calculateDistance(point1: Point2D, point2: Point2D): number {
  const dx = point1.x - point2.x;
  const dy = point1.y - point2.y;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Calculate midpoint between two points
 */
export function calculateMidpoint(point1: Point2D, point2: Point2D): Point2D {
  return {
    x: (point1.x + point2.x) / 2,
    y: (point1.y + point2.y) / 2
  };
}

/**
 * Calculate angle between two points (in radians)
 */
export function calculateAngle(from: Point2D, to: Point2D): number {
  return Math.atan2(to.y - from.y, to.x - from.x);
}

/**
 * Rotate a point around another point
 */
export function rotatePoint(point: Point2D, center: Point2D, angle: number): Point2D {
  const cos = Math.cos(angle);
  const sin = Math.sin(angle);
  const dx = point.x - center.x;
  const dy = point.y - center.y;
  
  return {
    x: center.x + (dx * cos - dy * sin),
    y: center.y + (dx * sin + dy * cos)
  };
}

/**
 * Calculate perpendicular direction vector
 */
export function getPerpendicularDirection(from: Point2D, to: Point2D, normalize = true): Point2D {
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  
  // Perpendicular vector is (-dy, dx)
  let perpX = -dy;
  let perpY = dx;
  
  if (normalize) {
    const length = Math.sqrt(perpX * perpX + perpY * perpY);
    if (length > 0) {
      perpX /= length;
      perpY /= length;
    }
  }
  
  return { x: perpX, y: perpY };
}

/**
 * Check if entity should be rendered with specific styling
 */
export function shouldApplySpecialRendering(entity: EntityModel, renderMode: string): boolean {
  return (entity as any)?.[renderMode] === true;
}

/**
 * Apply common transformation for rendering
 */
export function applyRenderingTransform(
  ctx: CanvasRenderingContext2D,
  screenCenter: Point2D,
  rotation: number,
  callback: () => void
): void {
  ctx.save();
  ctx.translate(screenCenter.x, screenCenter.y);
  if (rotation !== 0) {
    ctx.rotate((rotation * Math.PI) / 180);
  }
  callback();
  ctx.restore();
}

/**
 * Draw a path through vertices - eliminates duplicate path drawing code
 */
export function drawVerticesPath(
  ctx: CanvasRenderingContext2D,
  screenVertices: Point2D[],
  closed = false
): void {
  if (screenVertices.length < 2) return;
  
  ctx.beginPath();
  ctx.moveTo(screenVertices[0].x, screenVertices[0].y);
  
  for (let i = 1; i < screenVertices.length; i++) {
    ctx.lineTo(screenVertices[i].x, screenVertices[i].y);
  }
  
  if (closed) {
    ctx.closePath();
  }
}

/**
 * Render measurement label - eliminates duplicate label rendering
 */
export function renderMeasurementLabel(
  ctx: CanvasRenderingContext2D, 
  x: number, 
  y: number, 
  text: string, 
  color: string = '#00ff00'
): void {
  ctx.save();
  ctx.fillStyle = color;
  ctx.font = '11px Arial';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.fillText(text, x, y);
  ctx.restore();
}