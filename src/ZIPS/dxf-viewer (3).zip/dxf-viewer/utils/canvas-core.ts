import { coordTransforms } from '../config/unified-grid-configuration';

// Simplified canvas-core - χρησιμοποιεί το ενιαίο coordinate system

export type ViewTransform = {
  scale: number;
  offsetX: number;
  offsetY: number;
};

export class CanvasCore {
  private canvas: HTMLCanvasElement;
  private ctx: CanvasRenderingContext2D;

  constructor(canvas: HTMLCanvasElement) {
    this.canvas = canvas;
    const context = canvas.getContext('2d');
    if (!context) {
      throw new Error('Failed to get 2D context from canvas');
    }
    this.ctx = context;
  }

  clear() {
    // Simplified: Use canvas dimensions directly
    this.ctx.setTransform(1, 0, 0, 1, 0, 0);
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
  }

  getContext(): CanvasRenderingContext2D {
    return this.ctx;
  }

  getCanvas(): HTMLCanvasElement {
    return this.canvas;
  }
}

export default CanvasCore;
