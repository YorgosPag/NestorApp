export const HILITE_EVENT = 'dxf.highlightByIds';

export type HighlightPayload = {
  ids: string[];
  layerName?: string;
  mode?: 'hover' | 'select'; // << νέο
};

// fire-and-forget: ενημερώνει τον καμβά να κάνει dashed+grips στα ids
export function publishHighlight(payload: HighlightPayload) {
  const detail = { mode: 'select', ...payload }; // ✅ default
  console.log('🎯 [selection-bus] publishHighlight called with:', detail);
  window.dispatchEvent(new CustomEvent(HILITE_EVENT, { detail }));
}
