import { useState, useCallback } from 'react';
import type { SceneModel } from '../../types/scene';

export interface SceneManagerState {
  levelScenes: Record<string, SceneModel>;
  setLevelScene: (levelId: string, scene: SceneModel) => void;
  getLevelScene: (levelId: string) => SceneModel | null;
  clearLevelScene: (levelId: string) => void;
  clearAllScenes: () => void;
  hasSceneForLevel: (levelId: string) => boolean;
  getSceneEntityCount: (levelId: string) => number;
}

export function useSceneManager(): SceneManagerState {
  const [levelScenes, setLevelScenes] = useState<Record<string, SceneModel>>({});

  const setLevelScene = useCallback((levelId: string, scene: SceneModel) => {
    // Μικρό warning για άδειες σκηνές που δημιουργούνται
    if (!scene.entities?.length) {
      console.debug(`🏢 [SceneManager] Setting empty scene for level ${levelId} (${scene.entities.length} entities)`);
    } else {
      console.log(`🏢 Setting scene για level ${levelId}:`, scene.entities.length, 'entities');
    }
    setLevelScenes(prev => {
      const prevScene = prev[levelId];
      // No-op αν δεν αλλάζει ο pointer (γλιτώνουμε rerender loops)
      if (prevScene === scene) return prev;
      return { ...prev, [levelId]: scene };
    });
  }, []);

  const getLevelScene = useCallback((levelId: string): SceneModel | null => {
    return levelScenes[levelId] || null;
  }, [levelScenes]);

  const clearLevelScene = useCallback((levelId: string) => {
    console.log(`🏢 Clearing scene για level ${levelId}`);
    setLevelScenes(prev => {
      const { [levelId]: removed, ...rest } = prev;
      return rest;
    });
  }, []);

  const clearAllScenes = useCallback(() => {
    console.log('🏢 Clearing all level scenes');
    setLevelScenes({});
  }, []);

  const hasSceneForLevel = (levelId: string): boolean => {
    return !!levelScenes[levelId];
  };

  const getSceneEntityCount = (levelId: string): number => {
    const scene = levelScenes[levelId];
    return scene?.entities.length || 0;
  };

  return {
    levelScenes,
    setLevelScene,
    getLevelScene,
    clearLevelScene,
    clearAllScenes,
    hasSceneForLevel,
    getSceneEntityCount
  };
}
