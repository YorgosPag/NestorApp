'use client';

import React, { useEffect, useRef, useCallback, useState } from 'react';
import type { SceneModel } from '../types/scene';
import { EntityRenderer } from '../utils/entity-renderer';
import { MARGINS, type ViewTransform, type Point2D } from '../config/unified-grid-configuration';
import { useGripContext } from '../providers/GripProvider';
import type { AnyMeasurement } from '../types/measurements';
import { MeasurementRenderer } from '../utils/measurement-tools';

// Import extracted modules
import { createCanvasRenderer, type CanvasRenderer } from './engine/createCanvasRenderer';
import { useHoverAndSelect } from './interaction/useHoverAndSelect';
import { useGripInteraction } from './interaction/useGripInteraction';
import { publishHighlight } from '../events/selection-bus';
import { UnifiedEntitySelection } from '../utils/unified-entity-selection';

interface Props {
  onRendererReady: (renderer: any) => void;
  onMouseMove?: (pt: Point2D) => void;
  onMouseLeave?: () => void;
  onMouseDown?: (pt: Point2D, e?: React.MouseEvent<HTMLCanvasElement>) => void;
  onMouseUp?: (e: React.MouseEvent<HTMLCanvasElement>) => void;
  onWheel?: (e: React.WheelEvent<HTMLCanvasElement>) => void;
  selectedEntityIds?: string[];
  hoveredEntityId?: string | null;
  alwaysShowCoarseGrid?: boolean;
  scene?: SceneModel | null;
  className?: string;
  isZoomWindowActive?: boolean;
  activeTool?: string;
  // ✅ Optional refs for hit-test (when provided, use these instead of internal refs)
  hitTestCanvasRef?: React.RefObject<HTMLCanvasElement>;
  hitTestTransformRef?: React.RefObject<ViewTransform>;
  // ✅ Scene change callback for grip drag commits
  onSceneChange?: (scene: SceneModel) => void;
  // ✅ Selection change callback for parent updates (panels κ.λπ.)
  onSelectChange?: (ids: string[]) => void;
  // ✅ Right-click color menu callback
  onRequestColorMenu?: (at: { x: number; y: number }) => void;
  // ✅ Cursor style callback
  setCursor?: (cursor: string) => void;
  // ✅ Snap functionality
  snapEnabled?: boolean;
  findSnapPoint?: (x: number, y: number) => {x: number; y: number} | null;
}

export function DxfCanvasCore({
  onRendererReady,
  onMouseMove,
  onMouseLeave,
  onMouseDown,
  onMouseUp,
  onWheel,
  selectedEntityIds,
  hoveredEntityId,
  alwaysShowCoarseGrid = true,
  scene = null,
  className,
  isZoomWindowActive = false,
  activeTool,
  hitTestCanvasRef,
  hitTestTransformRef,
  onSceneChange,
  onSelectChange,
  onRequestColorMenu,
  setCursor,
  snapEnabled = false,
  findSnapPoint,
}: Props) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const rendererRef = useRef<CanvasRenderer | null>(null);
  const entityRendererRef = useRef<EntityRenderer | null>(null);
  const selectedIdsRef = useRef<Set<string>>(new Set());
  const hoverIdRef = useRef<string | null>(null);
  
  const currentTransformRef = useRef<ViewTransform>({ scale: 1, offsetX: 0, offsetY: window.innerHeight });

  // ✅ Overlay preview system για smooth drag χωρίς redraw conflicts
  const previewOverrideRef = useRef<{ entityId: string; next: any } | null>(null);

  // RAF throttling για preview rendering
  const lastPreviewRef = useRef<{x: number, y: number} | null>(null);
  const rafRef = useRef<number | null>(null);
  const JITTER_PX2 = 0.25; // 0.5px^2

  const { gripSettings } = useGripContext();
  const DEBUG = false;

  // Create canvas renderer on mount
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    canvas.style.cursor = 'none';
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Could not get 2D context');

    entityRendererRef.current = new EntityRenderer(ctx);
    entityRendererRef.current.setGripSettings(gripSettings);

    const renderer = createCanvasRenderer({
      canvas,
      gripSettings,
      entityRenderer: entityRendererRef.current,
      initialTransform: { scale: 1, offsetX: 0, offsetY: canvas.height },
      alwaysShowCoarseGrid,
      selectedIdsRef,
      hoverIdRef,
      previewOverrideRef, // ✅ περνάω το preview overlay ref
      onRendererReady: (r) => {
        rendererRef.current = r;
        onRendererReady?.(r);
      }
    });

    return () => {
      rendererRef.current = null;
      entityRendererRef.current = null;
    };
  }, [gripSettings, alwaysShowCoarseGrid, onRendererReady]);

  // ✅ Native contextmenu listener για 100% βεβαιότητα
  useEffect(() => {
    const el = canvasRef.current;
    if (!el || !onRequestColorMenu) return;

    const onCtx = (ev: MouseEvent) => {
      console.debug('CTX on canvas!');
      ev.preventDefault();
      ev.stopPropagation();

      // απλώς ζήτα άνοιγμα μενού – ΜΗΝ πειράξεις επιλογές εδώ
      onRequestColorMenu?.({ x: ev.clientX, y: ev.clientY });
    };

    el.addEventListener('contextmenu', onCtx, { capture: true });
    return () => el.removeEventListener('contextmenu', onCtx, { capture: true } as any);
  }, [onRequestColorMenu]);

  // Update refs and re-render when selections change
  useEffect(() => {
    selectedIdsRef.current = new Set(selectedEntityIds ?? []);
    if (rendererRef.current && scene) {
      rendererRef.current.renderScene(scene);
    }
  }, [selectedEntityIds, scene]);

  // Safety net: ensure bus is updated when React state changes
  useEffect(() => {
    publishHighlight({ ids: selectedEntityIds ?? [] });
  }, [selectedEntityIds]);

  // Cleanup RAF on unmount
  useEffect(() => {
    return () => {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  const getPoint = (e: React.MouseEvent<HTMLCanvasElement>): Point2D => {
    const rect = e.currentTarget.getBoundingClientRect();
    return { x: e.clientX - rect.left, y: e.clientY - rect.top };
  };

  // ✅ Ctrl/⌘ multi-select helpers
  const isToggleKey = (e: React.MouseEvent) => e.ctrlKey || e.metaKey; // Ctrl (Win/Linux) ή ⌘ (Mac)

  const toggleSelectAtPoint = useCallback((screenPt: Point2D) => {
    console.debug('🎯 toggleSelectAtPoint called:', screenPt);
    if (!scene || !rendererRef.current) return;
    const rect = rendererRef.current.getCanvas().getBoundingClientRect();
    const hit = UnifiedEntitySelection.findEntityAtPoint(
      screenPt,
      scene.entities,
      scene.layers,
      currentTransformRef.current,
      rect,
      8
    );
    if (!hit) {
      console.debug('🎯 Ctrl+click on empty space - no change');
      return; // Ctrl + κλικ σε κενό: δεν κάνουμε τίποτα
    }
    console.debug('🎯 Hit entity:', hit.entity.id);
    
    // Merge / toggle πάνω στο ref (single source of truth)
    const set = new Set(selectedIdsRef.current);
    const id = hit.entity.id;
    const wasSelected = set.has(id);
    if (wasSelected) set.delete(id); else set.add(id);

    const ids = Array.from(set);
    selectedIdsRef.current = new Set(ids);
    
    console.debug('🎯 Toggle result:', { 
      entityId: id, 
      wasSelected, 
      newSelection: ids,
      totalSelected: ids.length 
    });
    
    publishHighlight({ ids, mode: 'select' });         // ένα event με ΟΛΑ τα ids
    rendererRef.current.renderSceneImmediate(scene);   // άμεσο redraw

    // ✅ ενημέρωσε το parent για να δείχνει σωστά panels κ.λπ.
    onSelectChange?.(ids);
  }, [scene, onSelectChange]);

  // Stable render callbacks to prevent infinite loops
  const renderImmediate = useCallback((scene: SceneModel) => {
    rendererRef.current?.renderSceneImmediate(scene);
  }, []);

  const render = useCallback((scene: SceneModel, opts?: any) => {
    rendererRef.current?.renderScene(scene, opts);
  }, []);

  // ✅ Overlay preview helper
  const setPreviewOverride = useCallback((ov: { entityId: string; next: any } | null) => {
    previewOverrideRef.current = ov;
    if (scene) rendererRef.current?.renderSceneImmediate(scene);
  }, [scene]);

  // Hook up interaction handlers
  const gripInteraction = useGripInteraction({
    scene,
    selectedIdsRef,  // ✅ use selectedIdsRef instead of props
    transformRef: hitTestTransformRef || currentTransformRef,  // ✅ use same ref as hoverAndSelect
    canvasRef: hitTestCanvasRef || canvasRef,  // ✅ use same canvas as hoverAndSelect
    entityRendererRef,
    render,
    gripSettings,
    // ✅ Overlay preview για smooth drag
    setPreviewOverride,
    // ✅ Grip drag commit callback
    onCommitLine: (entityId, next) => {
      if (!scene || !onSceneChange) return;
      // commit στο ανώτερο state (ιστορικό, undo/redo, setLevelScene κ.λπ.)
      const newScene = {
        ...scene,
        entities: scene.entities.map(e => e.id === entityId ? { ...e, ...next } : e)
      };
      onSceneChange(newScene);
    },
    // ✅ Scene change callback για line-to-polyline conversion
    onSceneChange,
    // ✅ Cursor callback για αλλαγή cursor
    setCursor: setCursor,
    // ✅ SNAP PARAMETERS - Missing from original implementation
    snapEnabled: snapEnabled,
    findSnapPoint: findSnapPoint
  });

  const hoverAndSelect = useHoverAndSelect({
    scene,
    canvasRef: hitTestCanvasRef || canvasRef,           // ✅ use renderer's canvas if provided
    transformRef: hitTestTransformRef || currentTransformRef, // ✅ use renderer's transform if provided
    selectedIdsRef,
    hoverIdRef,
    renderImmediate,
    activeTool,
    isDraggingRef: gripInteraction.isDraggingRef,      // ✅ περνάμε το isDraggingRef για να κόψουμε hover
    setCursor: setCursor                               // ✅ περνάμε το cursor callback
  });

  const handleMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pt = getPoint(e);
    if (Number.isFinite(pt.x) && Number.isFinite(pt.y)) {
      onMouseMove?.(pt);
      
      // Hover hit-test logic - μόνο όταν είμαστε σε select tool ή grip-edit ή δεν έχουμε active tool
      if (!activeTool || activeTool === 'select' || activeTool === 'grip-edit') {
        // ✅ ΠΡΩΤΑ: Drag (highest priority) - αν σέρνουμε, ΤΕΛΟΣ εδώ
        if (gripInteraction.onMouseMoveDrag(pt)) return;
        
        // ✅ ΔΕΥΤΕΡΑ: Grip hover (higher priority) - return αν βρει grip
        if (gripInteraction.onMouseMoveGrip(pt)) return;
        
        // ✅ ΤΡΙΤΑ: Regular entity hover ΜΟΝΟ αν ΔΕΝ βρήκαμε grip ή δεν σέρνουμε
        hoverAndSelect.onMouseMoveEntityHover(pt);
      }
    }
  };

  const handleDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const pt = getPoint(e);
    if (Number.isFinite(pt.x) && Number.isFinite(pt.y)) {
      onMouseDown?.(pt, e);
      
      // ✅ Bridge για το εργαλείο Layering: προώθησε τα clicks στο overlay system
      if (activeTool === 'layering') {
        // Μετατροπή σε world coords
        const cm = rendererRef.current?.getCoordinateManager?.();
        const worldPoint = cm?.screenToWorld?.(pt) || { x: pt.x, y: pt.y };

        // ✅ DISPATCH CUSTOM EVENT για overlay system
        window.dispatchEvent(new CustomEvent('overlay:canvas-click', {
          detail: { point: worldPoint }
        }));

        // ΜΗΝ συνεχίσεις σε selection/grips κτλ.
        e.preventDefault();
        e.stopPropagation();
        return;
      }
      
      // ✅ Right-click: Check for polygon break or context menu
      if (e.button === 2) {
        // ✅ First check if right-click is on an edge grip of a closed polygon
        const polygonBroken = gripInteraction.breakPolygonAtGrip?.(pt);
        if (polygonBroken) {
          console.log('🎯 Right-click broke polygon at grip');
          e.preventDefault();
          e.stopPropagation();
          return;
        }
        
        // ✅ Fallback to context menu
        console.debug('Right-click fallback triggered!', { button: e.button, hasCallback: !!onRequestColorMenu });
        e.preventDefault();
        e.stopPropagation();
        onRequestColorMenu?.({ x: e.clientX, y: e.clientY });
        return;
      }
      
      if (e.button !== 0) return; // μόνο left συνεχίζει
      
      // ✅ 1) Ctrl/⌘ toggling ΠΡΩΤΟ - πάνω από όλα τα άλλα!
      if (isToggleKey(e)) {
        toggleSelectAtPoint(pt);
        return; // ✅ μην ξεκινήσεις ούτε grip-drag ούτε single-select
      }
      
      // 2) Entity selection logic - only in select and grip-edit modes
      if (!activeTool || activeTool === 'select' || activeTool === 'grip-edit') {
        // ✅ Κανονική ροή: grips πρώτα, μετά single select
        const gripClicked = gripInteraction.onMouseDownGrip(pt);
        
        if (!gripClicked) {
          hoverAndSelect.onMouseDownEntitySelect(pt);
        }
      }
    }
  };

  const handleUp = () => {
    gripInteraction.onMouseUpDrag();
  };

  return (
    <canvas
      ref={canvasRef}
      className={className}
      onMouseMove={handleMove}
      onMouseLeave={() => {
        hoverAndSelect.onMouseLeave();
        onMouseLeave?.();
      }}
      onMouseDown={handleDown}
      onMouseUp={(e) => {
        handleUp();
        onMouseUp?.(e);
      }}
      onWheel={onWheel}
      style={{
        display: 'block',
        width: '100%',
        height: '100%',
        touchAction: 'none'
      }}
    />
  );
}