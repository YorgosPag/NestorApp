/**
 * COORDINATE SYSTEM CONFIGURATION
 * Single Source of Truth για όλα τα coordinate systems
 */

import { Point2D } from '../../types/shared';
import { BaseConfigurationManager } from '../../utils/renderers/shared/geometry-rendering-utils';

// ===== BASIC TYPES =====
// Point2D imported from shared types

export interface ViewTransform {
  scale: number;
  offsetX: number;
  offsetY: number;
}

export interface CanvasRect {
  width: number;
  height: number;
}

export interface BoundingBox {
  min: Point2D;
  max: Point2D;
}

// ===== LAYOUT CONSTANTS =====
export const COORDINATE_LAYOUT = {
  RULER_LEFT_WIDTH: 30,
  RULER_BOTTOM_HEIGHT: 30,
  ORIGIN: { x: 0, y: 0 } as Point2D,
  MARGINS: {
    left: 30,
    right: 0,
    top: 0,
    bottom: 30
  }
} as const;

// ===== COORDINATE TRANSFORMATIONS =====
export function worldToScreen(
  worldPoint: Point2D, 
  transform: ViewTransform, 
  canvasRect: CanvasRect
): Point2D {
  const { left, bottom } = COORDINATE_LAYOUT.MARGINS;
  if (!worldPoint) {
    console.warn("worldToScreen received undefined point. Returning (0,0)");
    return { x: left, y: canvasRect.height - bottom };
  }
  return {
    x: left + (worldPoint.x + transform.offsetX) * transform.scale,
    y: canvasRect.height - bottom - (worldPoint.y + transform.offsetY) * transform.scale
  };
}

export function screenToWorld(
  screenPoint: Point2D, 
  transform: ViewTransform, 
  canvasRect: CanvasRect
): Point2D {
  const { left, bottom } = COORDINATE_LAYOUT.MARGINS;
  if (!screenPoint) {
    console.warn("screenToWorld received undefined point. Returning (0,0)");
    return { x: -transform.offsetX, y: -transform.offsetY };
  }
  return {
    x: (screenPoint.x - left) / transform.scale - transform.offsetX,
    y: (canvasRect.height - bottom - screenPoint.y) / transform.scale - transform.offsetY
  };
}

// ===== EXPORTS =====
export const RULER_SIZE = COORDINATE_LAYOUT.RULER_LEFT_WIDTH;
export const MARGINS = COORDINATE_LAYOUT.MARGINS;

export const coordTransforms = {
  worldToScreen,
  screenToWorld
};

// Grid settings (for coordinate system integration)
export interface GridSettings {
  visual: { enabled: boolean; step: number; opacity: number; color: string; subDivisions: number; };
  snap: { enabled: boolean; step: number; tolerance: number; showIndicators: boolean; };
  behavior: { autoZoomGrid: boolean; minGridSpacing: number; maxGridSpacing: number; adaptiveGrid: boolean; };
}

export const DEFAULT_GRID_SETTINGS: GridSettings = {
  visual: { enabled: true, step: 10, opacity: 0.3, color: "#888888", subDivisions: 5 },
  snap: { enabled: false, step: 10, tolerance: 12, showIndicators: true },
  behavior: { autoZoomGrid: true, minGridSpacing: 5, maxGridSpacing: 100, adaptiveGrid: true }
};

// Grid Configuration Manager
class GridConfigurationManager extends BaseConfigurationManager<GridSettings> {
  private settings: GridSettings = { ...DEFAULT_GRID_SETTINGS };
  
  getSettings(): GridSettings { return { ...this.settings }; }
  updateSettings(updates: Partial<GridSettings>): void {
    this.settings = { ...this.settings, ...updates };
    this.notifyListeners(this.settings);
  }
}

export const gridConfig = new GridConfigurationManager();
export function getGridSettings(): GridSettings { return gridConfig.getSettings(); }
export function updateGridSettings(updates: Partial<GridSettings>): void { gridConfig.updateSettings(updates); }
export function subscribeToGridSettings(listener: (settings: GridSettings) => void): () => void { return gridConfig.subscribe(listener); }