/**
 * RULERS/GRID SYSTEM HOOK
 * Standalone hook for accessing rulers and grid context and utilities
 */

import { useContext } from 'react';
import type {
  RulerSettings,
  GridSettings,
  RulersGridState,
  RulersGridOperation,
  RulersGridOperationResult,
  UnitType,
  GridBounds,
  SnapResult,
  RulerTick,
  GridLine,
  RulersLayoutInfo
} from './config';
import type { Point2D, ViewTransform, CanvasRect } from '../coordinates/config';

// Context type (will be properly typed when connected to RulersGridSystem)
interface RulersGridContextType {
  // State
  state: RulersGridState;
  
  // Ruler Management
  toggleRulers: (type?: 'horizontal' | 'vertical' | 'both') => void;
  setRulerVisibility: (type: 'horizontal' | 'vertical', visible: boolean) => void;
  updateRulerSettings: (updates: Partial<RulerSettings>) => void;
  setRulerUnits: (units: UnitType) => void;
  setRulerPosition: (type: 'horizontal' | 'vertical', position: 'top' | 'bottom' | 'left' | 'right') => void;
  
  // Grid Management
  toggleGrid: () => void;
  setGridVisibility: (visible: boolean) => void;
  updateGridSettings: (updates: Partial<GridSettings>) => void;
  setGridStep: (step: number) => void;
  setGridOpacity: (opacity: number) => void;
  setGridColor: (color: string) => void;
  
  // Origin and Coordinate System
  setOrigin: (point: Point2D) => void;
  resetOrigin: () => void;
  getOrigin: () => Point2D;
  
  // Snap Functionality
  toggleRulerSnap: () => void;
  toggleGridSnap: () => void;
  setSnapTolerance: (tolerance: number) => void;
  findSnapPoint: (point: Point2D, transform: ViewTransform, canvasRect: CanvasRect) => SnapResult | null;
  
  // Calculation Functions
  calculateGridBounds: (transform: ViewTransform, canvasRect: CanvasRect) => GridBounds;
  calculateGridLines: (bounds: GridBounds, settings: GridSettings, transform: ViewTransform) => GridLine[];
  calculateRulerTicks: (
    type: 'horizontal' | 'vertical',
    bounds: GridBounds,
    settings: RulerSettings,
    transform: ViewTransform,
    canvasRect: CanvasRect
  ) => RulerTick[];
  
  // Layout Information
  getLayoutInfo: (canvasRect: CanvasRect) => RulersLayoutInfo;
  getContentArea: (canvasRect: CanvasRect) => { x: number; y: number; width: number; height: number };
  
  // Unit Conversion
  convertUnits: (value: number, fromUnit: UnitType, toUnit: UnitType) => number;
  formatValue: (value: number, units: UnitType, precision?: number) => string;
  
  // Visibility and Display
  isRulerVisible: (type: 'horizontal' | 'vertical') => boolean;
  isGridVisible: () => boolean;
  getEffectiveOpacity: (transform: ViewTransform) => number;
  shouldRenderGrid: (transform: ViewTransform) => boolean;
  shouldRenderRulers: (transform: ViewTransform) => boolean;
  
  // Performance and Optimization
  getMaxGridLines: () => number;
  getMaxRulerTicks: () => number;
  isPerformanceOptimized: () => boolean;
  
  // Settings Management
  resetRulerSettings: () => void;
  resetGridSettings: () => void;
  resetAllSettings: () => void;
  exportSettings: () => string;
  importSettings: (data: string) => Promise<RulersGridOperationResult>;
  validateSettings: (settings: any) => { valid: boolean; errors: string[] };
  
  // Auto-fit and Smart Behavior
  autoFitGrid: (transform: ViewTransform, canvasRect: CanvasRect) => void;
  getOptimalGridStep: (transform: ViewTransform) => number;
  getOptimalTickSpacing: (transform: ViewTransform, type: 'horizontal' | 'vertical') => number;
}

export function useRulersGrid(): RulersGridContextType {
  const { RulersGridContext } = require('./RulersGridSystem');
  const context = useContext(RulersGridContext);
  if (!context) {
    throw new Error('useRulersGrid must be used within a RulersGridSystem');
  }
  return context;
}

// Additional convenience hooks
export function useRulerState() {
  const rulersGrid = useRulersGrid();
  return {
    horizontal: rulersGrid.state.rulers.horizontal,
    vertical: rulersGrid.state.rulers.vertical,
    units: rulersGrid.state.rulers.units,
    isHorizontalVisible: rulersGrid.isRulerVisible('horizontal'),
    isVerticalVisible: rulersGrid.isRulerVisible('vertical'),
    toggleRulers: rulersGrid.toggleRulers,
    setRulerVisibility: rulersGrid.setRulerVisibility,
    updateRulerSettings: rulersGrid.updateRulerSettings
  };
}

export function useGridState() {
  const rulersGrid = useRulersGrid();
  return {
    settings: rulersGrid.state.grid,
    isVisible: rulersGrid.isGridVisible(),
    toggleGrid: rulersGrid.toggleGrid,
    setGridVisibility: rulersGrid.setGridVisibility,
    updateGridSettings: rulersGrid.updateGridSettings,
    setGridStep: rulersGrid.setGridStep,
    setGridOpacity: rulersGrid.setGridOpacity,
    setGridColor: rulersGrid.setGridColor
  };
}

export function useSnapState() {
  const rulersGrid = useRulersGrid();
  return {
    rulerSnap: rulersGrid.state.rulers.snap,
    gridSnap: rulersGrid.state.grid.snap,
    toggleRulerSnap: rulersGrid.toggleRulerSnap,
    toggleGridSnap: rulersGrid.toggleGridSnap,
    setSnapTolerance: rulersGrid.setSnapTolerance,
    findSnapPoint: rulersGrid.findSnapPoint
  };
}

export function useOriginState() {
  const rulersGrid = useRulersGrid();
  return {
    origin: rulersGrid.state.origin,
    setOrigin: rulersGrid.setOrigin,
    resetOrigin: rulersGrid.resetOrigin,
    getOrigin: rulersGrid.getOrigin
  };
}

export function useRulersGridCalculations() {
  const rulersGrid = useRulersGrid();
  return {
    calculateGridBounds: rulersGrid.calculateGridBounds,
    calculateGridLines: rulersGrid.calculateGridLines,
    calculateRulerTicks: rulersGrid.calculateRulerTicks,
    getLayoutInfo: rulersGrid.getLayoutInfo,
    getContentArea: rulersGrid.getContentArea,
    convertUnits: rulersGrid.convertUnits,
    formatValue: rulersGrid.formatValue
  };
}

export function useRulersGridDisplay() {
  const rulersGrid = useRulersGrid();
  return {
    shouldRenderGrid: rulersGrid.shouldRenderGrid,
    shouldRenderRulers: rulersGrid.shouldRenderRulers,
    getEffectiveOpacity: rulersGrid.getEffectiveOpacity,
    isPerformanceOptimized: rulersGrid.isPerformanceOptimized,
    getMaxGridLines: rulersGrid.getMaxGridLines,
    getMaxRulerTicks: rulersGrid.getMaxRulerTicks
  };
}

export function useRulersGridSettings() {
  const rulersGrid = useRulersGrid();
  return {
    resetRulerSettings: rulersGrid.resetRulerSettings,
    resetGridSettings: rulersGrid.resetGridSettings,
    resetAllSettings: rulersGrid.resetAllSettings,
    exportSettings: rulersGrid.exportSettings,
    importSettings: rulersGrid.importSettings,
    validateSettings: rulersGrid.validateSettings,
    autoFitGrid: rulersGrid.autoFitGrid,
    getOptimalGridStep: rulersGrid.getOptimalGridStep,
    getOptimalTickSpacing: rulersGrid.getOptimalTickSpacing
  };
}

// Legacy hook names for backward compatibility
export const useRulers = useRulersGrid;
export const useGrid = useRulersGrid;
export const useRulersAndGrid = useRulersGrid;