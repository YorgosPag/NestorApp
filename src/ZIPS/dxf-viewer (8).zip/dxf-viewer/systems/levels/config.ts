/**
 * LEVELS SYSTEM - Configuration
 * Types, interfaces, and configuration for level management
 */

export interface Level {
  id: string;
  name: string;
  order: number;
  isDefault: boolean;
  visible: boolean;
}

export interface FloorplanDoc {
  id: string;
  levelId: string;
  name: string;
  fileName: string;
  units: 'mm' | 'cm' | 'm' | 'in' | 'ft';
  transform: {
    scaleX: number;
    scaleY: number;
    offsetX: number;
    offsetY: number;
    rotation: number;
  };
  bbox: {
    min: { x: number; y: number };
    max: { x: number; y: number };
  };
  importedAt: string;
  calibrated: boolean;
}

export interface CalibrationData {
  point1: {
    screen: { x: number; y: number };
    world: { x: number; y: number };
  };
  point2: {
    screen: { x: number; y: number };
    world: { x: number; y: number };
  };
  units: 'mm' | 'cm' | 'm' | 'in' | 'ft';
  realDistance: number;
}

export interface ImportWizardState {
  step: 'level' | 'calibration' | 'preview' | 'complete';
  file?: File;
  selectedLevelId?: string;
  newLevelName?: string;
  calibration?: CalibrationData;
  floorplan?: FloorplanDoc;
}

export interface LevelSystemConfig {
  enableAutoSave: boolean;
  defaultUnits: FloorplanDoc['units'];
  maxLevels: number;
  firebaseCollection: string;
  defaultLevels: Omit<Level, 'id'>[];
}

export const DEFAULT_LEVEL_CONFIG: LevelSystemConfig = {
  enableAutoSave: true,
  defaultUnits: 'mm',
  maxLevels: 50,
  firebaseCollection: 'dxf-viewer-levels',
  defaultLevels: [
    { name: 'Ισόγειο', order: 0, isDefault: true, visible: true },
    { name: '1ος Όροφος', order: 1, isDefault: false, visible: true },
  ],
};

export interface LevelSystemSettings {
  showLevelNumbers: boolean;
  allowLevelReordering: boolean;
  enableLevelDuplication: boolean;
  showFloorplanThumbnails: boolean;
  autoSelectNewLevel: boolean;
}

export const DEFAULT_LEVEL_SETTINGS: LevelSystemSettings = {
  showLevelNumbers: true,
  allowLevelReordering: true,
  enableLevelDuplication: true,
  showFloorplanThumbnails: true,
  autoSelectNewLevel: true,
};