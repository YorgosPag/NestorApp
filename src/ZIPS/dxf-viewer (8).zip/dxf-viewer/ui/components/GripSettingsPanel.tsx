'use client';

import React, { useState, useCallback, useMemo } from 'react';
import { useTranslation } from '../../../../i18n';
import type { GripSettings } from '../../types/gripSettings';
import { GRIP_LIMITS } from '../../types/gripSettings';
import { SliderInput } from './shared/SliderInput';

interface GripSettingsPanelProps {
  settings: GripSettings;
  onSettingsChange: (updates: Partial<GripSettings>) => void;
  className?: string;
}

export function GripSettingsPanel({ settings, onSettingsChange, className = '' }: GripSettingsPanelProps) {
  const { t } = useTranslation('dxf-viewer');
  
  // === DRAFT STATE για Color Pickers - ΝΟ MORE RE-RENDER STORM ===
  const [colorDrafts, setColorDrafts] = useState<Record<string, string>>({});
  
  // Debug logs (αφαιρούνται σε production)
  const DEBUG = process.env.NODE_ENV !== 'production';
  if (DEBUG) console.log('🎯 [GripSettingsPanel] Rendered with settings:', settings);
  
  // στο panel, όταν αλλάζει gripSize:
  const onChangeGripSize = useCallback((size: number) => {
    onSettingsChange({
      gripSize: size,
      apertureSize: Math.max(12, Math.round(size * 2.0)) // π.χ. 2×
    });
  }, [onSettingsChange]);

  const handleSliderChange = useCallback((key: keyof GripSettings, value: number) => {
    if (DEBUG) console.log(`🎯 [GripSettingsPanel] Slider: ${key} = ${value}`);
    
    if (key === 'gripSize') {
      onChangeGripSize(value);
    } else {
      onSettingsChange({ [key]: value });
    }
  }, [onSettingsChange, onChangeGripSize, DEBUG]);

  // === DRAFT PREVIEW - local state only ===
  const handleColorDraft = useCallback((colorType: string, color: string) => {
    setColorDrafts(prev => ({ ...prev, [colorType]: color }));
  }, []);

  // === GET DISPLAY COLOR (draft or committed) ===
  const getDisplayColor = useCallback((colorType: keyof GripSettings['colors']) => {
    return colorDrafts[colorType] || settings.colors[colorType];
  }, [colorDrafts, settings.colors]);

  // === THROTTLED COLOR COMMIT - Όχι σε κάθε pixel ===
  const commitColorChange = useCallback((colorType: keyof GripSettings['colors'], color: string) => {
    if (DEBUG) console.log(`🎯 [GripSettingsPanel] COLOR COMMIT: ${colorType} = ${color}`);
    const updates = {
      colors: {
        ...settings.colors,
        [colorType]: color
      }
    };
    onSettingsChange(updates);
    
    // Clear draft
    setColorDrafts(prev => {
      const next = { ...prev };
      delete next[colorType];
      return next;
    });
  }, [settings.colors, onSettingsChange, DEBUG]);

  // === COLOR PICKER COMPONENT - Eliminates 122-token duplications ===
  const renderColorPicker = useCallback((colorType: keyof GripSettings['colors'], labelKey: string) => (
    <div className="space-y-2">
      <label className="block text-xs text-gray-400">{t(labelKey)}</label>
      <div className="flex items-center space-x-2">
        <input
          type="color"
          value={getDisplayColor(colorType)}
          onChange={(e) => handleColorDraft(colorType, e.target.value)}
          onBlur={(e) => commitColorChange(colorType, e.target.value)}
          onMouseUp={(e) => commitColorChange(colorType, e.currentTarget.value)}
          className="w-8 h-6 rounded border border-gray-600 cursor-pointer"
        />
        <span className="text-xs text-gray-400 font-mono">
          {getDisplayColor(colorType)}
        </span>
      </div>
    </div>
  ), [getDisplayColor, handleColorDraft, commitColorChange, t]);

  const handleToggleChange = useCallback((key: keyof GripSettings, checked: boolean) => {
    if (DEBUG) console.log(`🎯 [GripSettingsPanel] Toggle: ${key} = ${checked}`);
    onSettingsChange({ [key]: checked });
  }, [onSettingsChange, DEBUG]);

  return (
    <div className={`space-y-4 ${className}`}>
      <div className="bg-gray-800 rounded-lg p-4">
        <h3 className="text-sm font-medium text-gray-100 mb-3 flex items-center">
          {t('panels.grips.panelTitle')}
        </h3>
        
        {/* === GRIP SIZES === */}
        <div className="space-y-3">
          <SliderInput
            label={t('panels.grips.gripSize', { size: settings.gripSize })}
            value={settings.gripSize}
            min={GRIP_LIMITS.gripSize.min}
            max={GRIP_LIMITS.gripSize.max}
            onChange={(value) => handleSliderChange('gripSize', value)}
          />

          <SliderInput
            label={t('panels.grips.pickbox', { size: settings.pickBoxSize })}
            value={settings.pickBoxSize}
            min={GRIP_LIMITS.pickBoxSize.min}
            max={GRIP_LIMITS.pickBoxSize.max}
            onChange={(value) => handleSliderChange('pickBoxSize', value)}
            tooltip={t('panels.grips.pickboxTooltip')}
          />

          <SliderInput
            label={t('panels.grips.aperture', { size: settings.apertureSize })}
            value={settings.apertureSize}
            min={GRIP_LIMITS.apertureSize.min}
            max={GRIP_LIMITS.apertureSize.max}
            onChange={(value) => handleSliderChange('apertureSize', value)}
            tooltip={t('panels.grips.apertureTooltip')}
          />
        </div>

        {/* === ANTI-STORM COLOR PICKERS === */}
        <div className="mt-4 pt-4 border-t border-gray-700">
          <h4 className="text-xs font-medium text-gray-300 mb-3">{t('panels.grips.colors.title')}</h4>
          <div className="grid grid-cols-2 gap-3">
            
            {/* Cold Color */}
            {renderColorPicker('cold', 'panels.grips.colors.cold')}

            {/* Warm Color */}
            {renderColorPicker('warm', 'panels.grips.colors.warm')}

            {/* Hot Color */}
            {renderColorPicker('hot', 'panels.grips.colors.hot')}

            {/* Contour Color */}
            {renderColorPicker('contour', 'panels.grips.colors.contour')}
          </div>
        </div>

        {/* === ADVANCED OPTIONS === */}
        <div className="mt-4 pt-4 border-t border-gray-700">
          <h4 className="text-xs font-medium text-gray-300 mb-3">{t('panels.grips.advanced.title')}</h4>
          <div className="space-y-2">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.showAperture}
                onChange={(e) => handleToggleChange('showAperture', e.target.checked)}
                className="rounded border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-2"
              />
              <span className="text-xs text-gray-300">{t('panels.grips.advanced.showAperture')}</span>
            </label>

            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.multiGripEdit}
                onChange={(e) => handleToggleChange('multiGripEdit', e.target.checked)}
                className="rounded border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-2"
              />
              <span className="text-xs text-gray-300">{t('panels.grips.advanced.multiGripEdit')}</span>
            </label>

            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={settings.snapToGrips}
                onChange={(e) => handleToggleChange('snapToGrips', e.target.checked)}
                className="rounded border-gray-600 text-blue-600 focus:ring-blue-500 focus:ring-2"
              />
              <span className="text-xs text-gray-300">{t('panels.grips.advanced.snapToGrips')}</span>
            </label>
          </div>
        </div>

        {/* === QUICK PRESETS === */}
        <div className="mt-4 pt-4 border-t border-gray-700">
          <h4 className="text-xs font-medium text-gray-300 mb-3">{t('panels.grips.presets.title')}</h4>
          <div className="flex space-x-2">
            <button
              onClick={() => onSettingsChange({ gripSize: 5, pickBoxSize: 2, apertureSize: 10 })}
              className="px-2 py-1 text-xs bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
            >
              {t('panels.grips.presets.small')}
            </button>
            <button
              onClick={() => onSettingsChange({ gripSize: 8, pickBoxSize: 3, apertureSize: 16 })}
              className="px-2 py-1 text-xs bg-blue-700 hover:bg-blue-600 rounded text-white"
            >
              {t('panels.grips.presets.default')}
            </button>
            <button
              onClick={() => onSettingsChange({ gripSize: 12, pickBoxSize: 5, apertureSize: 24 })}
              className="px-2 py-1 text-xs bg-gray-700 hover:bg-gray-600 rounded text-gray-300"
            >
              {t('panels.grips.presets.large')}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
