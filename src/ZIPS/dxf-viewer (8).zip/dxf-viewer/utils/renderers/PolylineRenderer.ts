/**
 * Polyline Entity Renderer
 * Handles rendering of polyline entities
 */

import { BaseEntityRenderer } from './BaseEntityRenderer';
import type { EntityModel, GripInfo, RenderOptions } from '../../types/renderer';
import type { Point2D } from '../../systems/coordinates/config';
import { HoverManager } from '../hover';
import { calculatePolygonArea, calculatePolygonCentroid, pointToLineDistance } from '../geometry-utils';
import { calculateAngleData, calculateAngleBisector, type AngleData } from '../angle-calculation';
import { TOLERANCE_CONFIG } from '../../config/tolerance-config';
import { renderTextAtEdgePosition } from '../hover/text-labeling-utils';
import { hitTestLineSegments, createEdgeGrips, calculatePerimeter } from './shared/line-utils';
import { drawVerticesPath, calculateMidpoint } from './shared/geometry-rendering-utils';

export class PolylineRenderer extends BaseEntityRenderer {

  render(entity: EntityModel, options: RenderOptions = {}): void {
    if (entity.type !== 'polyline' && entity.type !== 'lwpolyline') return;
    
    const vertices = entity.vertices as Point2D[];
    const closed = entity.closed as boolean;
    
    if (!vertices || vertices.length < 2) return;
    
    // 🎯 Χρήση 3-phase system όπως όλες οι άλλες οντότητες
    this.renderWithPhases(
      entity,
      options,
      // Geometry rendering
      () => this.renderPolylineGeometry(vertices, closed, entity, options),
      // Measurements rendering  
      () => this.renderPolylineMeasurements(vertices, closed, entity, options),
      // Yellow dots rendering
      () => this.renderPolylineYellowDots(vertices)
    );
  }

  private renderPolylineGeometry(vertices: Point2D[], closed: boolean, entity: EntityModel, options: RenderOptions): void {
    const screenVertices = vertices.map(v => this.worldToScreen(v));
    
    // 🎯 Έλεγχος αν χρειάζεται split line για κάθε τμήμα
    if (this.shouldRenderSplitLine(entity, options)) {
      // Σχεδίασε κάθε τμήμα ξεχωριστά με split line
      for (let i = 0; i < vertices.length - 1; i++) {
        const start = screenVertices[i];
        const end = screenVertices[i + 1];
        this.renderSplitLineWithGap(start, end);
      }
      
      // Αν είναι κλειστή, σχεδίασε και το τελευταίο τμήμα
      if (closed && vertices.length > 2) {
        const start = screenVertices[screenVertices.length - 1];
        const end = screenVertices[0];
        this.renderSplitLineWithGap(start, end);
      }
    } else {
      // Κανονικό polyline (solid lines)
      this.drawPath(screenVertices, closed);
      
      this.ctx.stroke();
    }
  }

  private renderPolylineMeasurements(vertices: Point2D[], closed: boolean, entity: EntityModel, options: RenderOptions): void {
    const screenVertices = vertices.map(v => this.worldToScreen(v));
    
    // Render edge distances for each segment
    for (let i = 0; i < vertices.length - 1; i++) {
      const start = vertices[i];
      const end = vertices[i + 1];
      const screenStart = screenVertices[i];
      const screenEnd = screenVertices[i + 1];
      
      this.renderDistanceTextPhaseAware(start, end, screenStart, screenEnd, entity, options);
    }
    
    // If closed, render distance for closing segment
    if (closed && vertices.length > 2) {
      const start = vertices[vertices.length - 1];
      const end = vertices[0];
      const screenStart = screenVertices[vertices.length - 1];
      const screenEnd = screenVertices[0];
      
      this.renderDistanceTextPhaseAware(start, end, screenStart, screenEnd, entity, options);
    }
    
    // 🎯 Προσθήκη τόξων γωνιών κατά τη φάση προεπισκόπησης
    this.renderPolygonAngles(vertices, screenVertices, closed);
    
    // If closed polygon, show area and perimeter at centroid
    if (closed) {
      const area = calculatePolygonArea(vertices);
      const perimeter = calculatePerimeter(vertices, closed);
      const centroid = calculatePolygonCentroid(vertices);
      const screenCentroid = this.worldToScreen(centroid);
      
      this.ctx.save();
      this.applyCenterMeasurementTextStyle();
      this.ctx.fillText(`Ε: ${area.toFixed(2)}`, screenCentroid.x, screenCentroid.y - 10);
      this.ctx.fillText(`Περ: ${perimeter.toFixed(2)}`, screenCentroid.x, screenCentroid.y + 10);
      this.ctx.restore();
    }
  }
  
  private renderPolylineYellowDots(vertices: Point2D[]): void {
    // Use centralized vertex dots rendering
    this.renderVertexDots(vertices);
  }
  
  // Removed - using shared calculatePerimeter from line-utils

  getGrips(entity: EntityModel): GripInfo[] {
    if (entity.type !== 'polyline' && entity.type !== 'lwpolyline') return [];
    
    const grips: GripInfo[] = [];
    const vertices = entity.vertices as Point2D[];
    
    if (!vertices) return grips;
    
    // Vertex grips
    vertices.forEach((vertex, index) => {
      grips.push({
        entityId: entity.id,
        gripType: 'vertex',
        gripIndex: index,
        position: vertex,
        state: 'cold'
      });
    });
    
    // Use shared utility for edge grips
    const edgeGrips = createEdgeGrips(entity.id, vertices, entity.closed as boolean, vertices.length);
    grips.push(...edgeGrips);
    
    return grips;
  }

  hitTest(entity: EntityModel, point: Point2D, tolerance: number): boolean {
    if (entity.type !== 'polyline' && entity.type !== 'lwpolyline') return false;
    
    const vertices = entity.vertices as Point2D[];
    const closed = entity.closed as boolean;
    
    if (!vertices || vertices.length < 2) return false;
    
    // Use shared hit test utility
    return hitTestLineSegments(point, vertices, tolerance, closed, this.worldToScreen.bind(this));
  }

  private renderPolygonWithAreaMeasurement(worldVertices: Point2D[], screenVertices: Point2D[]): void {
    // Save current context state
    this.ctx.save();
    
    // Draw the polygon outline with normal styling
    this.drawPath(screenVertices, true);
    this.ctx.stroke();
    
    // Add vertex markers at each corner (similar to measure-distance perpendicular markers)
    this.applyDimensionTextStyle(); // Use centralized fuchsia color
    const markerRadius = 3;
    
    screenVertices.forEach(vertex => {
      this.ctx.beginPath();
      this.ctx.arc(vertex.x, vertex.y, markerRadius, 0, 2 * Math.PI);
      this.ctx.fill();
    });
    
    // Calculate and display area at centroid
    if (worldVertices.length >= 3) {
      const area = calculatePolygonArea(worldVertices);
      const centroid = calculatePolygonCentroid(screenVertices);
      this.renderAreaLabel(centroid.x, centroid.y, area);
    }
    
    // Restore context state
    this.ctx.restore();
  }



  private renderAreaLabel(x: number, y: number, area: number): void {
    const text = `${area.toFixed(2)}`;
    
    // Save context for text rendering
    this.ctx.save();
    
    // Move to text position
    this.ctx.translate(x, y);
    
    // 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ font styling
    this.applyDimensionTextStyle();
    
    // No background - completely transparent
    // Draw text directly without background
    this.ctx.fillText(text, 0, 0);
    
    // Restore context
    this.ctx.restore();
  }

  /**
   * 🎯 Νέα μέθοδος για τόξα γωνιών στη φάση προεπισκόπησης - κεντρικοποιημένη
   */
  private renderPolygonAngles(worldVertices: Point2D[], screenVertices: Point2D[], closed: boolean): void {
    if (worldVertices.length < 3) return;
    
    // Check if this is a rectangle - skip angle rendering for rectangles (they use RectangleRenderer)
    const isRectangle = this.isRectangleShape(worldVertices);
    if (isRectangle) return;
    
    // Draw angle arcs and labels (starting from the second vertex)
    for (let i = 1; i < worldVertices.length - 1; i++) {
      const prevVertex = worldVertices[i - 1];
      const currentVertex = worldVertices[i];
      const nextVertex = worldVertices[i + 1];
      
      const prevScreen = screenVertices[i - 1];
      const currentScreen = screenVertices[i];
      const nextScreen = screenVertices[i + 1];
      
      this.renderAngleAtVertex(prevVertex, currentVertex, nextVertex, prevScreen, currentScreen, nextScreen);
    }
    
    // If closed, draw angles for first and last vertices
    if (closed && worldVertices.length >= 3) {
      // First vertex angle (last -> first -> second)
      const lastVertex = worldVertices[worldVertices.length - 1];
      const firstVertex = worldVertices[0];
      const secondVertex = worldVertices[1];
      
      const lastScreen = screenVertices[screenVertices.length - 1];
      const firstScreen = screenVertices[0];
      const secondScreen = screenVertices[1];
      
      this.renderAngleAtVertex(lastVertex, firstVertex, secondVertex, lastScreen, firstScreen, secondScreen);
      
      // Last vertex angle (second-to-last -> last -> first)
      if (worldVertices.length > 3) {
        const secondToLastVertex = worldVertices[worldVertices.length - 2];
        const lastVertexAgain = worldVertices[worldVertices.length - 1];
        const firstVertexAgain = worldVertices[0];
        
        const secondToLastScreen = screenVertices[screenVertices.length - 2];
        const lastScreenAgain = screenVertices[screenVertices.length - 1];
        const firstScreenAgain = screenVertices[0];
        
        this.renderAngleAtVertex(secondToLastVertex, lastVertexAgain, firstVertexAgain, secondToLastScreen, lastScreenAgain, firstScreenAgain);
      }
    }
  }

  private renderPolygonWithEdgeDistances(worldVertices: Point2D[], screenVertices: Point2D[], closed: boolean): void {
    this.ctx.save();
    
    // Draw distance labels on each edge
    this.renderAllEdgeDistances(worldVertices, screenVertices, closed);
    
    // Draw angle arcs and labels if not rectangle
    const isRectangle = this.isRectangleShape(worldVertices);
    if (!isRectangle) {
      this.renderAllPolygonAngles(worldVertices, screenVertices, closed);
    }
    
    // Draw area label for closed polygons
    if (closed && worldVertices.length >= 3) {
      this.renderPolygonAreaLabel(worldVertices, screenVertices);
    }
    
    this.ctx.restore();
  }

  private renderEdgeWithDistanceLabel(worldStart: Point2D, worldEnd: Point2D, screenStart: Point2D, screenEnd: Point2D): void {
    // Calculate distance in world coordinates
    const distance = calculateDistance(worldStart, worldEnd);
    
    // Use shared line direction calculation from BaseEntityRenderer
    const midpoint = calculateMidpoint(screenStart, screenEnd);
    
    // Line direction calculation (same as renderSplitLineWithGap)
    const dx = screenEnd.x - screenStart.x;
    const dy = screenEnd.y - screenStart.y;
    const length = Math.sqrt(dx * dx + dy * dy);
    if (length === 0) return;
    
    const unitX = dx / length;
    const unitY = dy / length;
    const textGap = 30; // Gap size in pixels for text
    
    // Calculate gap points (half gap on each side of center)
    const gapHalf = textGap / 2;
    const gapStart = {
      x: midX - unitX * gapHalf,
      y: midY - unitY * gapHalf
    };
    const gapEnd = {
      x: midX + unitX * gapHalf,
      y: midY + unitY * gapHalf
    };
    
    // Save context
    this.ctx.save();
    
    // Use shared split line rendering from base class
    this.renderSplitLineWithGap(screenStart, screenEnd, textGap);
    
    // Calculate line angle for text rotation
    const angle = Math.atan2(dy, dx);
    
    // Move to midpoint and rotate for text
    this.ctx.translate(midX, midY);
    this.ctx.rotate(angle);
    
    // 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ font styling
    this.applyDimensionTextStyle();
    
    const distanceText = distance.toFixed(2);
    
    // Draw text directly without background
    this.ctx.fillText(distanceText, 0, 0);
    
    // Restore context
    this.ctx.restore();
  }

  private renderAngleAtVertex(
    prevVertex: Point2D, 
    currentVertex: Point2D, 
    nextVertex: Point2D,
    prevScreen: Point2D,
    currentScreen: Point2D,
    nextScreen: Point2D,
    arcRadius: number = 25,
    labelOffset: number = 15
  ): void {
    const angleData = calculateAngleData(prevVertex, currentVertex, nextVertex, prevScreen, currentScreen, nextScreen);
    this.renderAngleArcAndLabel(currentVertex, currentScreen, angleData, arcRadius, labelOffset);
  }

  // MIGRATED: This method has been moved to HoverManager.renderPolylineHover()
  // All polyline hover behavior is now centralized

  private renderHoverEdgeWithDistance(worldStart: Point2D, worldEnd: Point2D, screenStart: Point2D, screenEnd: Point2D): void {
    // Calculate distance in world coordinates
    const distance = calculateDistance(worldStart, worldEnd);
    
    // Draw dashed line
    this.ctx.beginPath();
    this.ctx.moveTo(screenStart.x, screenStart.y);
    this.ctx.lineTo(screenEnd.x, screenEnd.y);
    this.ctx.stroke();
    
    // Use shared text positioning utility
    renderTextAtEdgePosition(this.ctx, distance.toFixed(2), screenStart, screenEnd, 12, false);
  }

  private renderDistanceNearGrip(worldStart: Point2D, worldEnd: Point2D, screenStart: Point2D, screenEnd: Point2D): void {
    // 🎯 Χρήση κεντρικοποιημένης μεθόδου - κείμενο ΕΣΩΤΕΡΙΚΑ της γραμμής
    // Μικρό offset για να μη κρύβει το grip
    this.renderDistanceTextCentralized(worldStart, worldEnd, screenStart, screenEnd, 15);
  }

  private renderAngleNearGrip(
    prevVertex: Point2D, 
    currentVertex: Point2D, 
    nextVertex: Point2D,
    prevScreen: Point2D,
    currentScreen: Point2D,
    nextScreen: Point2D
  ): void {
    // Use helper method for angle calculation and rendering
    const angleData = calculateAngleData(prevVertex, currentVertex, nextVertex, prevScreen, currentScreen, nextScreen);
    this.renderAngleArcAndLabel(currentVertex, currentScreen, angleData, 20, 25);
  }


  private renderHoverAngleAtVertex(
    prevVertex: Point2D, 
    currentVertex: Point2D, 
    nextVertex: Point2D,
    prevScreen: Point2D,
    currentScreen: Point2D,
    nextScreen: Point2D
  ): void {
    this.renderAngleAtVertex(prevVertex, currentVertex, nextVertex, prevScreen, currentScreen, nextScreen, 30, 20);
  }

  // Helper methods to eliminate duplications - now using shared utility
  private drawPath(screenVertices: Point2D[], closed = false): void {
    drawVerticesPath(this.ctx, screenVertices, closed);
  }
  private renderAllEdgeDistances(worldVertices: Point2D[], screenVertices: Point2D[], closed: boolean): void {
    for (let i = 0; i < worldVertices.length - 1; i++) {
      this.renderEdgeWithDistanceLabel(worldVertices[i], worldVertices[i + 1], screenVertices[i], screenVertices[i + 1]);
    }
    
    if (closed && worldVertices.length > 2) {
      const lastIdx = worldVertices.length - 1;
      this.renderEdgeWithDistanceLabel(worldVertices[lastIdx], worldVertices[0], screenVertices[lastIdx], screenVertices[0]);
    }
  }

  private renderAllPolygonAngles(worldVertices: Point2D[], screenVertices: Point2D[], closed: boolean): void {
    if (worldVertices.length < 3) return;
    
    // Middle vertices
    for (let i = 1; i < worldVertices.length - 1; i++) {
      this.renderAngleAtVertex(
        worldVertices[i - 1], worldVertices[i], worldVertices[i + 1],
        screenVertices[i - 1], screenVertices[i], screenVertices[i + 1]
      );
    }
    
    // First and last vertices for closed polygons
    if (closed && worldVertices.length >= 3) {
      const lastIdx = worldVertices.length - 1;
      
      // First vertex angle (last -> first -> second)
      this.renderAngleAtVertex(
        worldVertices[lastIdx], worldVertices[0], worldVertices[1],
        screenVertices[lastIdx], screenVertices[0], screenVertices[1]
      );
      
      // Last vertex angle (second-to-last -> last -> first)
      if (worldVertices.length > 3) {
        this.renderAngleAtVertex(
          worldVertices[lastIdx - 1], worldVertices[lastIdx], worldVertices[0],
          screenVertices[lastIdx - 1], screenVertices[lastIdx], screenVertices[0]
        );
      }
    }
  }

  private renderPolygonAreaLabel(worldVertices: Point2D[], screenVertices: Point2D[]): void {
    const area = calculatePolygonArea(worldVertices);
    const centroid = calculatePolygonCentroid(screenVertices);
    
    this.ctx.save();
    this.ctx.translate(centroid.x, centroid.y);
    this.applyDimensionTextStyle();
    this.ctx.font = `bold ${this.getBaseFontSize()}px Arial`;
    
    const areaText = `Area: ${area.toFixed(2)}`;
    this.ctx.fillText(areaText, 0, 0);
    this.ctx.restore();
  }

  private renderAngleArcAndLabel(
    currentVertex: Point2D, 
    currentScreen: Point2D, 
    angleData: AngleData,
    arcRadius: number,
    labelOffset: number
  ): void {
    const { degrees, startAngle, endAngle } = angleData;
    
    // Draw arc
    this.drawCentralizedArc(currentVertex.x, currentVertex.y, arcRadius, startAngle, endAngle);
    
    // Calculate label position
    const { bisectorAngle } = calculateAngleBisector(startAngle, endAngle);
    const labelRadius = arcRadius + labelOffset;
    const labelX = currentScreen.x + Math.cos(bisectorAngle) * labelRadius;
    const labelY = currentScreen.y + Math.sin(bisectorAngle) * labelRadius;
    
    // Draw label
    this.ctx.save();
    this.applyArcStyle();
    this.ctx.fillStyle = this.ctx.strokeStyle;
    this.ctx.font = `${this.getBaseFontSize()}px Arial`;
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    
    const angleText = `${degrees.toFixed(1)}°`;
    this.ctx.fillText(angleText, labelX, labelY);
    this.ctx.restore();
  }

  private isRectangleShape(vertices: Point2D[]): boolean {
    // A rectangle must have exactly 4 vertices
    if (vertices.length !== 4) return false;
    
    // Check if vertices form a rectangle by verifying:
    // 1. Opposite sides are parallel and equal
    // 2. Adjacent sides are perpendicular
    const [p1, p2, p3, p4] = vertices;
    
    // Calculate vectors for the sides
    const side1 = { x: p2.x - p1.x, y: p2.y - p1.y }; // p1 -> p2
    const side2 = { x: p3.x - p2.x, y: p3.y - p2.y }; // p2 -> p3
    const side3 = { x: p4.x - p3.x, y: p4.y - p3.y }; // p3 -> p4
    const side4 = { x: p1.x - p4.x, y: p1.y - p4.y }; // p4 -> p1
    
    // Check if opposite sides are parallel and equal
    const tolerance = TOLERANCE_CONFIG.POLYLINE_PRECISION;
    const side1Length = Math.sqrt(side1.x * side1.x + side1.y * side1.y);
    const side3Length = Math.sqrt(side3.x * side3.x + side3.y * side3.y);
    const side2Length = Math.sqrt(side2.x * side2.x + side2.y * side2.y);
    const side4Length = Math.sqrt(side4.x * side4.x + side4.y * side4.y);
    
    // Opposite sides should be equal in length
    if (Math.abs(side1Length - side3Length) > tolerance || Math.abs(side2Length - side4Length) > tolerance) {
      return false;
    }
    
    // Adjacent sides should be perpendicular (dot product = 0)
    const dot1 = side1.x * side2.x + side1.y * side2.y; // side1 · side2
    const dot2 = side2.x * side3.x + side2.y * side3.y; // side2 · side3
    
    if (Math.abs(dot1) > tolerance || Math.abs(dot2) > tolerance) {
      return false;
    }
    
    return true;
  }
}