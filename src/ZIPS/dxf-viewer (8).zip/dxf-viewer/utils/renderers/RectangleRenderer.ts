/**
 * Rectangle Entity Renderer
 * Handles rendering of rectangle entities
 */

import { BaseEntityRenderer } from './BaseEntityRenderer';
import type { EntityModel, GripInfo, RenderOptions } from '../../types/renderer';
import type { Point2D } from '../../systems/coordinates/config';
import { HoverManager } from '../hover';
import { pointToLineDistance } from '../geometry-utils';
import { hitTestLineSegments, createEdgeGrips } from './shared/line-utils';
import { drawVerticesPath } from './shared/geometry-rendering-utils';
import { getRectangleVertices } from '../../systems/selection/utils';

export class RectangleRenderer extends BaseEntityRenderer {
  private getVertices(entity: EntityModel): Point2D[] | null {
    return getRectangleVertices(entity);
  }

  render(entity: EntityModel, options: RenderOptions = {}): void {
    if (entity.type !== 'rectangle' && entity.type !== 'rect') return;
    
    const vertices = this.getVertices(entity);
    if (!vertices) return;
    
    // Use universal 3-phase rendering template
    this.renderWithPhases(
      entity,
      options,
      // Geometry rendering
      () => this.renderRectangleGeometry(vertices, entity, options),
      // Measurements rendering
      () => this.renderRectangleMeasurements(vertices, entity, options),
      // Yellow dots rendering
      () => this.renderRectangleYellowDots(vertices)
    );
  }

  private renderRectangleGeometry(vertices: Point2D[], entity: EntityModel, options: RenderOptions): void {
    const screenVertices = vertices.map(v => this.worldToScreen(v));
    
    // 🎯 Έλεγχος αν χρειάζεται split line για κάθε πλευρά
    if (this.shouldRenderSplitLine(entity, options)) {
      // Σχεδίασε κάθε πλευρά ξεχωριστά με split line
      for (let i = 0; i < screenVertices.length; i++) {
        const start = screenVertices[i];
        const end = screenVertices[(i + 1) % screenVertices.length];
        this.renderSplitLineWithGap(start, end);
      }
    } else {
      // Κανονικό ορθογώνιο (solid lines) - use shared utility
      drawVerticesPath(this.ctx, screenVertices, true);
      this.ctx.stroke();
    }
  }

  private renderRectangleMeasurements(vertices: Point2D[], entity: EntityModel, options: RenderOptions): void {
    // Calculate rectangle dimensions
    const width = Math.abs(vertices[1].x - vertices[0].x);
    const height = Math.abs(vertices[2].y - vertices[1].y);
    const area = width * height;
    const perimeter = 2 * (width + height);
    
    this.ctx.save();
    
    // 🎯 ΚΕΝΤΡΙΚΕΣ ΜΕΤΡΗΣΕΙΣ (στο κέντρο)
    this.applyCenterMeasurementTextStyle();
    const centerX = (vertices[0].x + vertices[2].x) / 2;
    const centerY = (vertices[0].y + vertices[2].y) / 2;
    const screenCenter = this.worldToScreen({ x: centerX, y: centerY });
    this.ctx.fillText(`Ε: ${area.toFixed(2)}`, screenCenter.x, screenCenter.y - 10);
    this.ctx.fillText(`Περ: ${perimeter.toFixed(2)}`, screenCenter.x, screenCenter.y + 10);
    
    // 🎯 ΔΙΑΣΤΑΣΕΙΣ ΠΛΕΥΡΩΝ - Εσωτερικές στο ορθογώνιο (αρνητικό offset)
    
    // Top side (horizontal) - κείμενο ΚΑΤΩ από τη γραμμή (εσωτερικά)
    const topStart = vertices[0];
    const topEnd = vertices[1];
    const topScreenStart = this.worldToScreen(topStart);
    const topScreenEnd = this.worldToScreen(topEnd);
    this.renderDistanceTextPhaseAware(topStart, topEnd, topScreenStart, topScreenEnd, entity, options);
    
    // Bottom side (horizontal) - κείμενο ΠΑΝΩ από τη γραμμή (εσωτερικά)  
    const bottomStart = vertices[3];
    const bottomEnd = vertices[2];
    const bottomScreenStart = this.worldToScreen(bottomStart);
    const bottomScreenEnd = this.worldToScreen(bottomEnd);
    this.renderDistanceTextPhaseAware(bottomStart, bottomEnd, bottomScreenStart, bottomScreenEnd, entity, options);
    
    // Left side (vertical) - κείμενο ΔΕΞΙΑ από τη γραμμή (εσωτερικά)
    const leftStart = vertices[0];
    const leftEnd = vertices[3];
    const leftScreenStart = this.worldToScreen(leftStart);
    const leftScreenEnd = this.worldToScreen(leftEnd);
    this.renderDistanceTextPhaseAware(leftStart, leftEnd, leftScreenStart, leftScreenEnd, entity, options);
    
    // Right side (vertical) - κείμενο ΑΡΙΣΤΕΡΑ από τη γραμμή (εσωτερικά)
    const rightStart = vertices[1];
    const rightEnd = vertices[2];
    const rightScreenStart = this.worldToScreen(rightStart);
    const rightScreenEnd = this.worldToScreen(rightEnd);
    this.renderDistanceTextPhaseAware(rightStart, rightEnd, rightScreenStart, rightScreenEnd, entity, options);
    
    // 🎯 ΤΟΞΑ ΓΩΝΙΩΝ με 90° 
    this.renderCornerArcs(vertices);
    
    this.ctx.restore();
  }

  private renderCornerArcs(vertices: Point2D[]): void {
    const cornerSize = 15; // Μέγεθος διακεκομμένης ορθής γωνίας σε pixels
    
    this.ctx.save();
    // 🎯 Χρήση κεντρικοποιημένου στιλ τόξων
    this.applyArcStyle(); // Πορτοκαλί με διακεκομμένες γραμμές
    this.ctx.font = `${this.getBaseFontSize()}px Arial`;
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    
    // Κάθε γωνία του ορθογωνίου είναι 90°
    const angleText = '90°';
    
    // Διακεκομμένες ορθές γωνίες σε όλες τις 4 γωνίες
    vertices.forEach((vertex, index) => {
      const screenVertex = this.worldToScreen(vertex);
      
      // Για κάθε γωνία, υπολογίζουμε τις κατευθύνσεις των 2 πλευρών
      const prevIndex = (index - 1 + vertices.length) % vertices.length;
      const nextIndex = (index + 1) % vertices.length;
      
      // Υπολογίζουμε το κέντρο του ορθογωνίου
      const centerX = (vertices[0].x + vertices[1].x + vertices[2].x + vertices[3].x) / 4;
      const centerY = (vertices[0].y + vertices[1].y + vertices[2].y + vertices[3].y) / 4;
      
      // Vector από την κορυφή προς το ΚΕΝΤΡΟ (πραγματικά εσωτερικά)
      const toCenter = {
        x: centerX - vertex.x,
        y: centerY - vertex.y
      };
      
      // Vectors προς τις διπλανές κορυφές (για την ορθή γωνία)
      const toPrev = {
        x: vertices[prevIndex].x - vertex.x,
        y: vertices[prevIndex].y - vertex.y
      };
      const toNext = {
        x: vertices[nextIndex].x - vertex.x,
        y: vertices[nextIndex].y - vertex.y
      };
      
      // Normalize vectors
      const centerLength = Math.sqrt(toCenter.x * toCenter.x + toCenter.y * toCenter.y);
      const prevLength = Math.sqrt(toPrev.x * toPrev.x + toPrev.y * toPrev.y);
      const nextLength = Math.sqrt(toNext.x * toNext.x + toNext.y * toNext.y);
      
      if (centerLength > 0 && prevLength > 0 && nextLength > 0) {
        const centerUnit = { x: toCenter.x / centerLength, y: toCenter.y / centerLength };
        const prevUnit = { x: toPrev.x / prevLength, y: toPrev.y / prevLength };
        const nextUnit = { x: toNext.x / nextLength, y: toNext.y / nextLength };
        
        // Απλό L-shape προς το εσωτερικό του ορθογωνίου
        // Κάθε γωνία πάει ΜΕΣΑ κατά μήκος των δύο πλευρών της
        const innerPoint1 = {
          x: screenVertex.x + centerUnit.x * cornerSize,  // προς το κέντρο
          y: screenVertex.y + centerUnit.y * cornerSize
        };
        const cornerPoint1 = {
          x: innerPoint1.x + prevUnit.x * cornerSize * 0.5,  // στραμμένο στην πρώτη πλευρά
          y: innerPoint1.y + prevUnit.y * cornerSize * 0.5
        };
        const cornerPoint2 = {
          x: innerPoint1.x + nextUnit.x * cornerSize * 0.5,  // στραμμένο στη δεύτερη πλευρά
          y: innerPoint1.y + nextUnit.y * cornerSize * 0.5
        };
        
        // 🎯 ΤΟΞΟ 90° - Χρήση κεντρικοποιημένης μεθόδου
        const prevAngle = Math.atan2(prevUnit.y, prevUnit.x);
        const nextAngle = Math.atan2(nextUnit.y, nextUnit.x);
        const arcRadius = cornerSize * 0.8;
        
        this.drawCentralizedArc(vertex.x, vertex.y, arcRadius, prevAngle, nextAngle);
        
        // 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ κείμενο 90° - χρήση centerUnit για σίγουρη εσωτερική τοποθέτηση
        const textDistance = cornerSize * 1.5;
        const worldTextX = vertex.x + centerUnit.x * (textDistance / this.transform.scale);
        const worldTextY = vertex.y + centerUnit.y * (textDistance / this.transform.scale);
        
        this.ctx.save();
        this.applyArcStyle(); 
        this.ctx.fillStyle = this.ctx.strokeStyle; // Πορτοκαλί χρώμα από την applyArcStyle
        this.ctx.font = `${this.getBaseFontSize()}px Arial`;
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        this.ctx.setLineDash([]); // Solid για το κείμενο
        this.ctx.fillText(angleText, this.worldToScreen({x: worldTextX, y: worldTextY}).x, this.worldToScreen({x: worldTextX, y: worldTextY}).y);
        this.ctx.restore();
        
      }
    });
    
    this.ctx.restore();
  }

  private renderRectangleYellowDots(vertices: Point2D[]): void {
    // Use centralized vertex dots rendering  
    this.renderVertexDots(vertices);
  }

  getGrips(entity: EntityModel): GripInfo[] {
    if (entity.type !== 'rectangle' && entity.type !== 'rect') return [];
    
    const grips: GripInfo[] = [];
    const vertices = this.getVertices(entity);
    if (!vertices) return grips;
    
    // Corner grips
    vertices.forEach((vertex, index) => {
      grips.push({
        entityId: entity.id,
        gripType: 'corner',
        gripIndex: index,
        position: vertex,
        state: 'cold'
      });
    });
    
    // Use shared utility for edge grips (closed rectangle)
    const edgeGrips = createEdgeGrips(entity.id, vertices, true, vertices.length);
    grips.push(...edgeGrips);
    
    return grips;
  }

  hitTest(entity: EntityModel, point: Point2D, tolerance: number): boolean {
    if (entity.type !== 'rectangle' && entity.type !== 'rect') return false;
    
    const vertices = this.getVertices(entity);
    if (!vertices) return false;
    
    // Use shared hit test utility (closed rectangle)
    return hitTestLineSegments(point, vertices, tolerance, true, this.worldToScreen.bind(this));
  }

}