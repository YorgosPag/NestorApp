import { useMemo } from 'react';
import { GRID_STEP_CSS } from '../../constants';
import type { GridRenderingProps } from './types';

export interface GridRenderingHook {
  gridLines: JSX.Element[];
}

export function useGridRendering({
  canvasRect,
  coordinateManager,
  showGrid
}: GridRenderingProps): GridRenderingHook {
  
  const gridLines = useMemo((): JSX.Element[] => {
    if (!showGrid || !canvasRect || !coordinateManager) return [];

    const lines: JSX.Element[] = [];
    const stepCSS = GRID_STEP_CSS;

    // Vertical lines
    for (let x = 0; x < canvasRect.width; x += stepCSS) {
      const worldX = coordinateManager.screenToWorld({ x, y: 100 })?.x;
      if (worldX !== undefined) {
        lines.push(
          <div 
            key={`vline-${x}`} 
            style={{ 
              position: 'absolute', 
              left: x, 
              top: 0, 
              bottom: 0, 
              width: 1, 
              background: 'rgba(0,255,255,0.3)', 
              pointerEvents: 'none' 
            }}
          >
            <div 
              style={{ 
                position: 'absolute', 
                top: 10, 
                left: 2, 
                fontSize: 10, 
                color: '#00ffff', 
                background: 'rgba(0,0,0,0.7)', 
                padding: '1px 3px', 
                borderRadius: 2, 
                whiteSpace: 'nowrap' 
              }}
            >
              X:{worldX.toFixed(0)}
            </div>
          </div>
        );
      }
    }

    // Horizontal lines
    for (let y = 0; y < canvasRect.height; y += stepCSS) {
      const worldY = coordinateManager.screenToWorld({ x: 100, y })?.y;
      if (worldY !== undefined) {
        lines.push(
          <div 
            key={`hline-${y}`} 
            style={{ 
              position: 'absolute', 
              top: y, 
              left: 0, 
              right: 0, 
              height: 1, 
              background: 'rgba(0,255,255,0.3)', 
              pointerEvents: 'none' 
            }}
          >
            <div 
              style={{ 
                position: 'absolute', 
                left: 10, 
                top: 2, 
                fontSize: 10, 
                color: '#00ffff', 
                background: 'rgba(0,0,0,0.7)', 
                padding: '1px 3px', 
                borderRadius: 2, 
                whiteSpace: 'nowrap' 
              }}
            >
              Y:{worldY.toFixed(0)}
            </div>
          </div>
        );
      }
    }

    return lines;
  }, [showGrid, canvasRect, coordinateManager]);

  return {
    gridLines,
  };
}