import React from 'react';
import type { MarqueeRectProps } from './types';
import { calculateRectGeometry, getSelectionColors } from './utils';

export function MarqueeRect({ start, end, kind }: MarqueeRectProps) {
  const rect = calculateRectGeometry(start, end);
  const { borderColor, fillColor } = getSelectionColors(kind);

  return (
    <div
      className="absolute"
      style={{
        left: rect.x,
        top: rect.y,
        width: rect.width,
        height: rect.height,
        border: `2px ${kind === 'crossing' ? 'dashed' : 'solid'} ${borderColor}`,
        backgroundColor: fillColor,
        borderRadius: '1px'
      }}
    />
  );
}