
'use client';

import React, { useRef, useEffect, useState, useCallback } from 'react';
import { getCursorSettings, subscribeToCursorSettings, type CursorSettings } from '../systems/cursor/config';
import { useGripContext } from '../providers/GripProvider';
import { useCanvasSetup } from './hooks/useCanvasSetup';

interface CrosshairOverlayProps {
  className?: string;
  isActive?: boolean;
  cursorPosition?: { x: number; y: number } | null;
  viewport?: { width: number; height: number };
  transform?: any;
}

export default function CrosshairOverlay({
  className = '',
  isActive = true,
  cursorPosition = null,
  viewport = { width: 0, height: 0 },
  transform
}: CrosshairOverlayProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [settings, setSettings] = useState<CursorSettings>(getCursorSettings());
  const rafRef = useRef<number>();

  // === GRIP SETTINGS INTEGRATION ===
  const { gripSettings } = useGripContext();

  // Subscribe to settings changes
  useEffect(() => {
    const unsubscribe = subscribeToCursorSettings(setSettings);
    return unsubscribe;
  }, []);

  // Setup canvas using shared hook
  useCanvasSetup(canvasRef, {
    viewport,
    imageSmoothingEnabled: settings.performance.precision_mode
  });

  // Render perfect AutoCAD-style crosshair με grip pickbox & aperture
  const renderCrosshair = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear full canvas
    ctx.clearRect(0, 0, viewport.width, viewport.height);

    if (!settings.crosshair.enabled || !isActive || !cursorPosition) {
      return;
    }

    const { x: rawMouseX, y: rawMouseY } = cursorPosition;
    const dpr = window.devicePixelRatio || 1;
    
    // Λειτουργία ακρίβειας: sub-pixel positioning
    let mouseX, mouseY;
    if (settings.performance.precision_mode) {
      // High precision: no rounding για pixel-perfect positioning
      mouseX = rawMouseX;
      mouseY = rawMouseY;
    } else {
      // Normal precision: round to nearest pixel
      mouseX = Math.round(rawMouseX);
      mouseY = Math.round(rawMouseY);
    }
    
    // AutoCAD crosshair settings - για full screen crosshair
    // Στο 100% το σταυρόνημα πρέπει να φτάνει από 0 μέχρι width/height
    // Υπολογισμός για να φτάνει πάντα στα άκρα
    const fullWidth = viewport.width;
    const fullHeight = viewport.height;
    const crosshairHalfWidth = (fullWidth / 2) * (settings.crosshair.size_percent / 100);
    const crosshairHalfHeight = (fullHeight / 2) * (settings.crosshair.size_percent / 100);
    
    // === PICKBOX από GRIP SETTINGS ===
    const pickboxSize = gripSettings.pickBoxSize * dpr;
    // Χρησιμοποιούμε το custom center gap από τις ρυθμίσεις
    const centerGap = Math.max(pickboxSize + 4, settings.crosshair.center_gap_px);

    // Setup drawing style
    ctx.strokeStyle = settings.crosshair.color;
    ctx.lineWidth = settings.crosshair.line_width;
    ctx.lineCap = 'square';
    ctx.globalAlpha = 0.9;
    
    // Λειτουργία ακρίβειας: βελτίωση rendering
    if (settings.performance.precision_mode) {
      ctx.lineJoin = 'miter';
      ctx.miterLimit = 10;
    }

    // Draw horizontal crosshair lines (with gap for pickbox)
    ctx.beginPath();
    // Left side - πάντα από το 0 έως centerGap (ή από mouseX-crosshairHalfWidth αν είναι μεγαλύτερο)
    const leftStart = 0;
    const leftEnd = mouseX - centerGap;
    if (leftEnd > leftStart) {
      ctx.moveTo(leftStart, mouseY);
      ctx.lineTo(leftEnd, mouseY);
    }
    
    // Right side - από centerGap έως το τέλος του viewport
    const rightStart = mouseX + centerGap;
    const rightEnd = viewport.width;
    if (rightStart < rightEnd) {
      ctx.moveTo(rightStart, mouseY);
      ctx.lineTo(rightEnd, mouseY);
    }
    ctx.stroke();

    // Draw vertical crosshair lines (with gap for pickbox)
    ctx.beginPath();
    // Top side - πάντα από το 0 έως centerGap
    const topStart = 0;
    const topEnd = mouseY - centerGap;
    if (topEnd > topStart) {
      ctx.moveTo(mouseX, topStart);
      ctx.lineTo(mouseX, topEnd);
    }
    
    // Bottom side - από centerGap έως το τέλος του viewport
    const bottomStart = mouseY + centerGap;
    const bottomEnd = viewport.height;
    if (bottomStart < bottomEnd) {
      ctx.moveTo(mouseX, bottomStart);
      ctx.lineTo(mouseX, bottomEnd);
    }
    ctx.stroke();

    // === PICKBOX RENDERING (από GripSettings) ===
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    
    if (settings.performance.precision_mode) {
      // High precision: exact positioning
      const halfPickbox = pickboxSize / 2;
      ctx.strokeRect(
        mouseX - halfPickbox, 
        mouseY - halfPickbox, 
        pickboxSize, 
        pickboxSize
      );
    } else {
      // Normal precision: pixel-aligned
      const halfPickbox = Math.round(pickboxSize / 2);
      ctx.strokeRect(
        Math.round(mouseX - halfPickbox) + 0.5, 
        Math.round(mouseY - halfPickbox) + 0.5, 
        Math.round(pickboxSize), 
        Math.round(pickboxSize)
      );
    }

    // === SNAP APERTURE RENDERING ===
    if (gripSettings.showAperture) {
      ctx.strokeStyle = 'rgba(255, 255, 0, 0.8)'; // Κίτρινο aperture
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.arc(mouseX, mouseY, gripSettings.apertureSize * dpr, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.globalAlpha = 1;
  }, [settings, isActive, cursorPosition, gripSettings, viewport]);

  // RAF-optimized rendering
  useEffect(() => {
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
    }

    if (settings.performance.use_raf) {
      rafRef.current = requestAnimationFrame(renderCrosshair);
    } else {
      renderCrosshair();
    }

    return () => {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [renderCrosshair, settings.performance.use_raf]);

  return (
    <canvas
      ref={canvasRef}
      className={`absolute top-0 left-0 pointer-events-none ${className}`}
      style={{
        zIndex: 10,
        display: settings.crosshair.enabled && isActive ? 'block' : 'none'
      }}
      data-debug={`enabled:${settings.crosshair.enabled} active:${isActive} position:${cursorPosition ? `${cursorPosition.x},${cursorPosition.y}` : 'null'}`}
    />
  );
}

export { CrosshairOverlay };
