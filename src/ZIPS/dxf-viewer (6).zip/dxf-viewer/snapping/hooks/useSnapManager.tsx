'use client';

import { useEffect, useRef, useMemo } from 'react';
import { ProSnapEngineV2 as SnapManager } from '../ProSnapEngineV2';
import { useSnapContext } from '../context/SnapContext';
import { ExtendedSnapType } from '../extended-types';
import type { SceneModel } from '../../types/scene';

interface UseSnapManagerOptions {
  scene?: SceneModel | null;
  onSnapPoint?: (point: {x: number, y: number} | null) => void;
}

export const useSnapManager = (
  canvasRef: React.RefObject<HTMLCanvasElement>,
  options: UseSnapManagerOptions = {}
) => {
  const { snapEnabled, enabledModes } = useSnapContext();
  const snapManagerRef = useRef<SnapManager | null>(null);
  const { scene, onSnapPoint } = options;

  // Initialize SnapManager
  useEffect(() => {
    if (!canvasRef.current) return;

    snapManagerRef.current = new SnapManager();
    
    console.log('🎯 SnapManager initialized');

    return () => {
      if (snapManagerRef.current) {
        snapManagerRef.current.dispose();
        snapManagerRef.current = null;
        console.log('🎯 SnapManager destroyed');
      }
    };
  }, [canvasRef]);

  // Create stable enabledTypes Set για τον engine
  const enabledTypes = useMemo(() => {
    return new Set<ExtendedSnapType>(enabledModes);
  }, [enabledModes]);

  // Update snap modes when snap settings change
  useEffect(() => {
    if (snapManagerRef.current && scene?.entities?.length > 0) {
      console.log('🎯 Updating snap engine with modes:', Array.from(enabledTypes));
      
      // 1) Enable/disable snapping
      snapManagerRef.current.setEnabled(snapEnabled);
      
      // 2) ΠΕΡΑΣΕ ΑΚΡΙΒΩΣ τα ενεργά modes (χωρίς leftovers)
      snapManagerRef.current.updateSettings({ enabledTypes });
    }
  }, [snapEnabled, enabledTypes, scene?.entities?.length]);

  // Update scene when it changes
  useEffect(() => {
    console.log('🎯 useSnapManager: Scene changed, snapManager exists:', !!snapManagerRef.current, 'Scene:', !!scene, 'Scene entities count:', scene?.entities?.length);
    
    if (snapManagerRef.current) {
      const entities = scene?.entities || [];
      
      console.log('🎯 useSnapManager: About to check entities, length:', entities.length);
      
      // Only initialize if we have entities - avoid spam with empty scenes
      if (entities.length === 0) {
        console.log('🎯 No entities in scene! Scene object:', scene);
        return;
      }
      
      console.log('🎯 Initializing snap manager with', entities.length, 'entities');
      
      // Create viewport from canvas (with proper HTMLCanvasElement access)
      if (canvasRef.current) {
        try {
          const canvasElement = canvasRef.current.getCanvas ? canvasRef.current.getCanvas() : canvasRef.current;
          
          if (canvasElement && typeof canvasElement.getContext === 'function') {
            const transform = canvasElement.getContext('2d')?.getTransform();
            
            if (transform) {
              const viewport = {
                scale: transform.a || 1,
                worldPerPixelAt: () => 1 / (transform.a || 1),
                worldToScreen: (p: any) => ({
                  x: p.x * transform.a + transform.e,
                  y: p.y * transform.d + transform.f
                })
              };
              
              snapManagerRef.current.setViewport(viewport);
              console.log('🎯 Viewport set with scale:', viewport.scale);
            }
          }
        } catch (error) {
          console.warn('🎯 Could not set viewport:', error);
          // Continue without viewport - better than crashing
        }
      }
      
      snapManagerRef.current.initialize(entities);
      
      if (entities.length > 0) {
        // Debug: Log entity types to understand what we're working with
        console.log('🎯 Scene entities loaded for snapping:', entities.length);
        const entityTypes = entities.reduce((types, entity) => {
          types[entity.type] = (types[entity.type] || 0) + 1;
          return types;
        }, {} as Record<string, number>);
        console.log('🎯 Entity types:', entityTypes);
        
        // Sample first few entities to see their structure
        entities.slice(0, 3).forEach((entity, i) => {
          console.log(`🎯 Entity ${i}:`, {
            type: entity.type,
            id: entity.id,
            points: (entity as any).points?.length || 0,
            center: (entity as any).center,
            radius: (entity as any).radius,
            start: (entity as any).start,
            end: (entity as any).end,
            fullEntity: entity
          });
        });
      } else {
        console.log('🎯 No entities in scene!');
      }
    } else {
      console.log('🎯 SnapManager not ready yet');
    }
  }, [scene]);

  // Return the snap manager instance for external use
  return {
    snapManager: snapManagerRef.current,
    findSnapPoint: (worldX: number, worldY: number) => {
      return snapManagerRef.current?.findSnapPoint({ x: worldX, y: worldY }) || null;
    }
  };
};
