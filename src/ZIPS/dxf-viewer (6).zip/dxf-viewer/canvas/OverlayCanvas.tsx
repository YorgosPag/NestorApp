'use client';
import React, { useRef, useState } from 'react';
import { OverlayCanvasCore } from './OverlayCanvasCore';
import { useOverlayStore } from '../overlays/overlay-store';
import { useLevels } from '../systems/levels';
import { PROPERTY_STATUS_COLORS } from '../../../constants/statuses';
import type { PropertyStatus } from '../../../constants/statuses';

// DXF-style grip colors (like BaseEntityRenderer)
const DXF_GRIP_COLORS = {
  cold: '#00A2FF',    // Blue (normal grips)
  warm: '#FFD400',    // Orange (hovered grips)
  hot: '#FF3B30'      // Red (active/selected grips)
};

interface OverlayCanvasProps {
  transform: { scale: number; offsetX: number; offsetY: number };
  isDrawingMode?: boolean;
  drawingStatus?: PropertyStatus;
  drawingKind?: string;
  showGrid?: boolean;
}

export default function OverlayCanvas(props: OverlayCanvasProps) {
  const overlayStore = useOverlayStore();
  const levelManager = useLevels();
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentVertices, setCurrentVertices] = useState<Array<[number, number]>>([]);
  const rendererRef = useRef<any>(null);
  
  // DXF-style hover/grip interaction states
  const [hoveredGrip, setHoveredGrip] = useState<number | null>(null);
  const [activeGrip, setActiveGrip] = useState<number | null>(null);
  const [isHoveringLine, setIsHoveringLine] = useState(false);
  const [cursor, setCursor] = useState('crosshair');

  const {
    transform,
    isDrawingMode = false,
    drawingStatus = 'for-sale' as PropertyStatus,
    drawingKind = 'unit',
    showGrid = false,
  } = props;

  const startDrawing = (status: PropertyStatus) => {
    console.log('🎯 Starting overlay drawing with status:', status);
    setIsDrawing(true);
    setCurrentVertices([]);
  };

  const addVertex = (vertex: [number, number]) => {
    console.log('➕ Adding vertex:', vertex);
    setCurrentVertices(prev => [...prev, vertex]);
  };

  const finishDrawing = async () => {
    if (currentVertices.length >= 3 && levelManager.currentLevelId) {
      console.log('✅ Finishing overlay with vertices:', currentVertices);
      try {
        await overlayStore.add({
          levelId: levelManager.currentLevelId,
          kind: drawingKind as any,
          polygon: currentVertices,
          status: drawingStatus,
          label: `${drawingKind} ${Date.now()}`,
        });
        console.log('💾 Overlay saved successfully');
      } catch (error) {
        console.error('❌ Failed to save overlay:', error);
      }
    }
    // Reset all DXF-style states
    setIsDrawing(false);
    setCurrentVertices([]);
    setHoveredGrip(null);
    setActiveGrip(null);
    setIsHoveringLine(false);
    setCursor('crosshair');
  };

  const cancelDrawing = () => {
    console.log('❌ Canceling overlay drawing');
    // Reset all DXF-style states
    setIsDrawing(false);
    setCurrentVertices([]);
    setHoveredGrip(null);
    setActiveGrip(null);
    setIsHoveringLine(false);
    setCursor('crosshair');
  };

  // DXF-style grip hit testing
  const findGripAtMouse = (mousePos: { x: number; y: number }): number | null => {
    for (let i = 0; i < currentVertices.length; i++) {
      const vertex = currentVertices[i];
      const screenX = vertex[0] * transform.scale + transform.offsetX;
      const screenY = vertex[1] * transform.scale + transform.offsetY;
      
      const distance = Math.sqrt(
        Math.pow(mousePos.x - screenX, 2) + 
        Math.pow(mousePos.y - screenY, 2)
      );
      
      if (distance <= 8) { // 8px grip tolerance like DXF
        return i;
      }
    }
    return null;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDrawing) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const mousePos = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };
    
    // Check for grip hover first (DXF-style priority)
    const gripIndex = findGripAtMouse(mousePos);
    setHoveredGrip(gripIndex);
    
    // Check if hovering over the polyline itself (DXF white dashed effect)
    if (gripIndex === null) {
      setIsHoveringLine(isPointNearPolyline(mousePos, currentVertices, transform, 5));
    } else {
      setIsHoveringLine(false);
    }
    
    // Update cursor like DXF system
    if (gripIndex !== null) {
      setCursor('move'); // Cross with arrows for grip hover
    } else if (isHoveringLine) {
      setCursor('pointer'); // Pointer for line hover
    } else {
      setCursor('crosshair');
    }
  };

  // Helper function to detect if mouse is near the polyline
  const isPointNearPolyline = (
    mousePos: { x: number; y: number },
    vertices: Array<[number, number]>,
    transform: { scale: number; offsetX: number; offsetY: number },
    tolerance: number
  ): boolean => {
    if (vertices.length < 2) return false;
    
    for (let i = 0; i < vertices.length - 1; i++) {
      const start = {
        x: vertices[i][0] * transform.scale + transform.offsetX,
        y: vertices[i][1] * transform.scale + transform.offsetY
      };
      const end = {
        x: vertices[i + 1][0] * transform.scale + transform.offsetX,
        y: vertices[i + 1][1] * transform.scale + transform.offsetY
      };
      
      const distance = distancePointToLine(mousePos, start, end);
      if (distance <= tolerance) {
        return true;
      }
    }
    return false;
  };

  // Distance from point to line segment
  const distancePointToLine = (
    point: { x: number; y: number },
    lineStart: { x: number; y: number },
    lineEnd: { x: number; y: number }
  ): number => {
    const A = point.x - lineStart.x;
    const B = point.y - lineStart.y;
    const C = lineEnd.x - lineStart.x;
    const D = lineEnd.y - lineStart.y;

    const dot = A * C + B * D;
    const lenSq = C * C + D * D;
    let param = -1;
    if (lenSq !== 0) param = dot / lenSq;

    let xx, yy;
    if (param < 0) {
      xx = lineStart.x;
      yy = lineStart.y;
    } else if (param > 1) {
      xx = lineEnd.x;
      yy = lineEnd.y;
    } else {
      xx = lineStart.x + param * C;
      yy = lineStart.y + param * D;
    }

    const dx = point.x - xx;
    const dy = point.y - yy;
    return Math.sqrt(dx * dx + dy * dy);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const mousePos = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };

    const worldPos: [number, number] = [
      (mousePos.x - transform.offsetX) / transform.scale,
      (mousePos.y - transform.offsetY) / transform.scale
    ];

    console.log('🖱️ OverlayCanvas click:', { mousePos, worldPos, isDrawingMode, isDrawing });

    // Check for grip click first (DXF-style priority)
    if (isDrawing) {
      const gripIndex = findGripAtMouse(mousePos);
      if (gripIndex !== null) {
        setActiveGrip(gripIndex);
        setCursor('grab'); // Hand cursor for grip drag
        console.log('🎯 DXF-style grip clicked:', gripIndex);
        return;
      }
    }

    // ✅ AUTO-START: If in drawing mode but not yet drawing, start now
    if (isDrawingMode && !isDrawing) {
      startDrawing(drawingStatus);
      addVertex(worldPos);
      return;
    }

    if (!isDrawingMode && isDrawing) {
      cancelDrawing();
      return;
    }

    if (isDrawing && isDrawingMode) {
      if (currentVertices.length >= 3) {
        const firstVertex = currentVertices[0];
        const screenFirst = [
          firstVertex[0] * transform.scale + transform.offsetX,
          firstVertex[1] * transform.scale + transform.offsetY
        ];
        
        const distance = Math.sqrt(
          Math.pow(mousePos.x - screenFirst[0], 2) + 
          Math.pow(mousePos.y - screenFirst[1], 2)
        );
        
        if (distance < 20) {
          console.log('🔄 Closing polygon - clicked near start');
          finishDrawing();
          return;
        }
      }
      
      addVertex(worldPos);
    }
  };

  const handleDoubleClick = () => {
    if (isDrawing && currentVertices.length >= 3) {
      console.log('⚡ Double-click - finishing polygon');
      finishDrawing();
    }
  };

  React.useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        cancelDrawing();
      } else if (e.key === 'Enter' && currentVertices.length >= 3) {
        finishDrawing();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentVertices.length]);

  return (
    <div 
      className="absolute inset-0 pointer-events-auto"
      style={{ zIndex: 10 }}
      onMouseDown={handleMouseDown}
      onMouseMove={handleMouseMove}
      onDoubleClick={handleDoubleClick}
      style={{ cursor }}
    >
      {isDrawing && (
        <svg 
          className="absolute inset-0 pointer-events-none"
          style={{ zIndex: 11 }}
        >
          {currentVertices.length > 0 && (
            <g>
              {/* DXF-style polyline with hover effects */}
              <polyline
                points={currentVertices.map(([x, y]) => 
                  `${x * transform.scale + transform.offsetX},${y * transform.scale + transform.offsetY}`
                ).join(' ')}
                fill="none"
                stroke={isHoveringLine ? '#FFFFFF' : PROPERTY_STATUS_COLORS[drawingStatus]}
                strokeWidth={isHoveringLine ? "3" : "2"}
                strokeDasharray={isHoveringLine ? "12,6" : "4,4"}
                opacity="0.8"
              />
              {/* Preview closing line when hovering near first point */}
              {currentVertices.length >= 3 && (
                <line
                  x1={currentVertices[currentVertices.length - 1][0] * transform.scale + transform.offsetX}
                  y1={currentVertices[currentVertices.length - 1][1] * transform.scale + transform.offsetY}
                  x2={currentVertices[0][0] * transform.scale + transform.offsetX}
                  y2={currentVertices[0][1] * transform.scale + transform.offsetY}
                  stroke={PROPERTY_STATUS_COLORS[drawingStatus]}
                  strokeWidth="1"
                  strokeDasharray="2,2"
                  opacity="0.4"
                />
              )}
              {/* DXF-style grips με blue/orange/red colors */}
              {currentVertices.map(([x, y], i) => {
                const screenX = x * transform.scale + transform.offsetX;
                const screenY = y * transform.scale + transform.offsetY;
                
                // DXF grip color logic
                let gripColor = DXF_GRIP_COLORS.cold; // Blue by default
                if (activeGrip === i) {
                  gripColor = DXF_GRIP_COLORS.hot; // Red for active
                } else if (hoveredGrip === i) {
                  gripColor = DXF_GRIP_COLORS.warm; // Orange for hovered
                }
                
                return (
                  <g key={i}>
                    {/* DXF-style grip square */}
                    <rect
                      x={screenX - 4}
                      y={screenY - 4}
                      width="8"
                      height="8"
                      fill={gripColor}
                      stroke="#000"
                      strokeWidth="1"
                    />
                  </g>
                );
              })}
            </g>
          )}
        </svg>
      )}
    </div>
  );
}
