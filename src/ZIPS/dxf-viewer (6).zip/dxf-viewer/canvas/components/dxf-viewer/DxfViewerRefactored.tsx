import React, { useEffect, useMemo, useCallback } from 'react';
import { EnhancedDXFToolbar } from '../../../ui/toolbar/EnhancedDXFToolbar';
import { ToolType } from '../../../ui/toolbar/types';
import { DxfCanvasRefactored as DxfCanvas, type DxfCanvasRef } from '../../DxfCanvasRefactored';
import { useDxfViewerState } from './hooks/useDxfViewerState';
import OverlayCanvas from '../../OverlayCanvas';
import { FloatingPanelContainer } from '../../../ui/FloatingPanelContainer';
import { useLevels, LevelsSystem } from '../../../systems/levels';
import type { SceneModel } from '../../../types/scene';
import { CoordProvider } from '../../../systems/coordinates/CoordinateSystem';
import { GripProvider, useGripContext } from '../../../providers/GripProvider';

// 🎯 SNAPPING SYSTEM IMPORTS
import { useSnapManager } from '../../../snapping/hooks/useSnapManager';
import { useSnapContext } from '../../../snapping/context/SnapContext';
// 🚫 ΑΦΑΙΡΕΣΗ - useSnapIntegration (χρησιμοποιείται μόνο στο DxfCanvasRefactored)
import { Upload } from 'lucide-react';
import { useDxfImport } from '../../useDxfImport';

// 📏 MEASUREMENT SYSTEM IMPORTS
// import { useMeasurement } from '../../../../../hooks/useMeasurement';
// import { MeasurementRenderer } from '../utils/measurement-tools';
type MeasurementType = string;

// 🎨 NEW: UNIFIED DRAWING SYSTEM IMPORTS
import { useUnifiedDrawing } from '../../../hooks/drawing/useUnifiedDrawing';
import type { DrawingTool } from '../../../hooks/drawing/useUnifiedDrawing';

interface DxfViewerAppProps {
  className?: string;
}

type Pt = { x:number; y:number };

function DxfViewerContent({ className }: DxfViewerAppProps) {
  // ✨ CENTRALIZED STATE MANAGEMENT
  const {
    // Tool state
    activeTool, setActiveTool,
    // Canvas state  
    dxfCanvasRef, overlayCanvasRef, canvasRef, currentZoom, setCurrentZoom,
    // UI state
    showGrid, setShowGrid, showLayers, setShowLayers, showProperties, setShowProperties,
    showCalibration, setShowCalibration, isZoomWindowActive, setIsZoomWindowActive,
    // Selection state
    selectedEntityIds, setSelectedEntityIds,
    // System state
    measurementRenderer, setMeasurementRenderer, canUndo, setCanUndo, canRedo, setCanRedo,
    // Helpers
    resetUIState, resetToolState, resetSelectionState, resetSystemState, resetAllState,
  } = useDxfViewerState();


  // 🎨 NEW: UNIFIED DRAWING SYSTEM
  const drawingSystem = useUnifiedDrawing();

  // 🎯 SNAPPING SYSTEM
  const { snapEnabled, enabledModes } = useSnapContext();
  const snapManager = null; // TODO: Initialize snap manager if needed
  const findSnapPoint = () => null; // TODO: Implement snap point finding
  const applySnap = (point: any) => point; // TODO: Implement snap application

  // Level Manager Integration
  const { currentLevelId, getLevelScene, setLevelScene, levels } = useLevels();
  
  // Current scene για το DxfCanvas (μόνο τρέχον επίπεδο)
  const currentScene = useMemo(() => currentLevelId ? getLevelScene(currentLevelId) : null, [currentLevelId, getLevelScene]);
  
  // Combined scene για το LayersSection (όλα τα επίπεδα)
  const allLevelsScene = useMemo(() => {
    if (!levels || levels.length === 0) return null;
    
    const allEntities: any[] = [];
    const allLayers: Record<string, any> = {};
    let bounds: { min: { x: number; y: number }; max: { x: number; y: number } } | null = null;
    
    // Συλλογή όλων των entities και layers από όλα τα επίπεδα
    levels.forEach((level, levelIndex) => {
      const levelScene = getLevelScene(level.id);
      if (levelScene) {
        // Προσθήκη entities με level prefix στο layer name
        levelScene.entities.forEach((entity: any) => {
          allEntities.push({
            ...entity,
            layer: `${level.name}_${entity.layer}`, // Prefix με όνομα επιπέδου
            originalLayer: entity.layer,
            levelId: level.id,
            levelName: level.name,
            levelIndex: levelIndex
          });
        });
        
        // Προσθήκη layers με level prefix
        Object.entries(levelScene.layers).forEach(([layerName, layer]) => {
          allLayers[`${level.name}_${layerName}`] = {
            ...(layer || {}),
            originalName: layerName,
            levelId: level.id,
            levelName: level.name,
            levelIndex: levelIndex
          };
        });
        
        // Ενημέρωση bounds
        if (levelScene.bounds) {
          if (!bounds) {
            bounds = {
              min: { x: levelScene.bounds.min.x, y: levelScene.bounds.min.y },
              max: { x: levelScene.bounds.max.x, y: levelScene.bounds.max.y }
            };
          } else {
            bounds.min.x = Math.min(bounds.min.x, levelScene.bounds.min.x);
            bounds.min.y = Math.min(bounds.min.y, levelScene.bounds.min.y);
            bounds.max.x = Math.max(bounds.max.x, levelScene.bounds.max.x);
            bounds.max.y = Math.max(bounds.max.y, levelScene.bounds.max.y);
          }
        }
      }
    });
    
    return {
      entities: allEntities,
      layers: allLayers,
      bounds: bounds || { min: { x: 0, y: 0 }, max: { x: 100, y: 100 } },
      units: 'mm' as const
    };
  }, [levels, getLevelScene]);
  
  // Enhanced scene για το DxfCanvas (τρέχον επίπεδο + επιλεγμένα entities από άλλα επίπεδα)
  const enhancedCurrentScene = useMemo(() => {
    if (!currentScene) return null;
    if (!selectedEntityIds.length || !allLevelsScene) return currentScene;
    
    console.log(`🔧 [enhancedCurrentScene] Selected entities: ${selectedEntityIds.length}`, selectedEntityIds);
    console.log(`🔧 [enhancedCurrentScene] Current level: ${currentLevelId}`);
    console.log(`🔧 [enhancedCurrentScene] All levels entities: ${allLevelsScene.entities.length}`);
    
    // Βρες τα επιλεγμένα entities από άλλα επίπεδα
    const selectedFromOtherLevels = allLevelsScene.entities.filter((entity: any) => 
      selectedEntityIds.includes(entity.id) && entity.levelId !== currentLevelId
    );
    
    console.log(`🔧 [enhancedCurrentScene] Selected from other levels: ${selectedFromOtherLevels.length}`, selectedFromOtherLevels.map(e => `${e.id}(${e.levelName})`));
    
    if (selectedFromOtherLevels.length === 0) return currentScene;
    
    // Συνδύασε το current scene με τα επιλεγμένα από άλλα επίπεδα
    const enhancedEntities = [
      ...currentScene.entities,
      ...selectedFromOtherLevels.map((entity: any) => ({
        ...entity,
        layer: entity.originalLayer, // Επαναφορά στο original layer name
        fromOtherLevel: true // Flag για rendering
      }))
    ];
    
    console.log(`🔧 [enhancedCurrentScene] Final enhanced scene: ${enhancedEntities.length} entities (${currentScene.entities.length} current + ${selectedFromOtherLevels.length} from other levels)`);
    
    return {
      ...currentScene,
      entities: enhancedEntities,
      layers: {
        ...currentScene.layers,
        // Προσθήκη των layers από άλλα επίπεδα αν χρειάζεται
        ...selectedFromOtherLevels.reduce((acc: any, entity: any) => {
          const layerKey = entity.originalLayer;
          if (!acc[layerKey] && allLevelsScene.layers[entity.layer]) {
            acc[layerKey] = {
              ...allLevelsScene.layers[entity.layer],
              name: entity.originalLayer,
              fromOtherLevel: true
            };
          }
          return acc;
        }, {})
      }
    };
  }, [currentScene, selectedEntityIds, allLevelsScene, currentLevelId]);
  
  // === GRIP SETTINGS from Context ===
  const { gripSettings } = useGripContext();

  // ——— UPDATE UNDO/REDO STATE ———
  useEffect(() => {
    if (dxfCanvasRef.current) {
      setCanUndo(dxfCanvasRef.current.canUndo());
      setCanRedo(dxfCanvasRef.current.canRedo());
    }
  }, [currentScene, selectedEntityIds]);


  // 🚫 ΑΦΑΙΡΕΣΗ - useSnapIntegration (χρησιμοποιείται μόνο στο DxfCanvasRefactored)

  // Debug effect για να παρακολουθούμε τις αλλαγές
  useEffect(() => {
    console.log('🎯 Snap state changed:', {
      snapEnabled,
      enabledModes: Array.from(enabledModes),
      hasSnapManager: !!snapManager,
      hasFindSnapPoint: !!findSnapPoint
    });
  }, [snapEnabled, enabledModes, snapManager, findSnapPoint]);
  // === UNIFIED TOOL DETECTION ===
  // === UNIFIED TOOL DETECTION ===
  const isMeasurementTool = activeTool?.startsWith('measure-');
  const isDrawingTool = ['line', 'rectangle', 'circle', 'circle-diameter', 'polyline', 'polygon', 'measure-distance', 'measure-area'].includes(activeTool);
  
  console.log('🎯 [DxfViewerRefactored] Tool detection:', {
    activeTool,
    isMeasurementTool,
    isDrawingTool
  });
  
  // Debug effect to track activeTool changes
  useEffect(() => {
    console.log('🔄 [DxfViewerRefactored] activeTool changed to:', activeTool);
  }, [activeTool]);

  const handleToolChange = (tool: ToolType) => {
    console.log('🔧 [DxfViewerRefactored] handleToolChange called with:', tool);
    
    // 📏 Reset measurement system when changing tool
    // No measurement system();
    
    // 🎨 NEW: Reset drawing system when changing tool
    drawingSystem.cancelDrawing();

    if (tool === 'zoom-window') {
      setActiveTool('zoom-window');
      setIsZoomWindowActive(true);
      dxfCanvasRef.current?.activateZoomWindow();
      return;
    }
    
    // 📏 MEASUREMENT TOOLS - Extended support
    if (tool === 'measure' || tool.startsWith('measure-')) {
      setActiveTool(tool);
      const measurementType = tool.replace('measure-', '') as MeasurementType;
      // No measurement system(measurementType);
      console.log('📏 Started measurement:', measurementType);
      
      dxfCanvasRef.current?.deactivateZoomWindow();
      return;
    }

    // 🎨 NEW: DRAWING TOOLS - Check incoming tool parameter, not current activeTool
    const isIncomingDrawingTool = ['line', 'rectangle', 'circle', 'circle-diameter', 'polyline', 'polygon', 'measure-distance', 'measure-area'].includes(tool);
    if (isIncomingDrawingTool) {
      setActiveTool(tool);
      drawingSystem.startDrawing(tool as DrawingTool);
      console.log('🎨 Started drawing:', tool);
      
      dxfCanvasRef.current?.deactivateZoomWindow();
      return;
    }

    if (isZoomWindowActive) {
      setIsZoomWindowActive(false);
      dxfCanvasRef.current?.deactivateZoomWindow();
    }

    setActiveTool(tool);
  };

  // 🎯 HELPER: Update currentZoom from canvas
  const updateCurrentZoomFromCanvas = () => {
    setTimeout(() => {
      const canvas = dxfCanvasRef.current;
      if (canvas) {
        const transform = canvas.getTransform();
        if (transform?.scale) {
          setCurrentZoom(transform.scale);
        }
      }
    }, 50);
  };
  
  const handleAction = (action: string, data?: any) => {
    switch (action) {
      case 'zoom-in-action':
        dxfCanvasRef.current?.zoomIn();
        updateCurrentZoomFromCanvas();
        break;
        
      case 'zoom-out-action':
        dxfCanvasRef.current?.zoomOut();
        updateCurrentZoomFromCanvas();
        break;
        
      case 'fit':
        dxfCanvasRef.current?.fitToView();
        setTimeout(() => updateCurrentZoomFromCanvas(), 100);
        break;
        
      case 'set-zoom':
        if (typeof data === 'number') {
          const canvas = dxfCanvasRef.current;
          if (canvas && currentScene) {
            try {
              const coordinateManager = (canvas as any).getCoordinateManager?.();
              if (coordinateManager) {
                const currentTransform = canvas.getTransform();
                coordinateManager.setTransform({
                  ...currentTransform,
                  scale: data
                });
                canvas.renderScene(currentScene);
                setCurrentZoom(data);
              }
            } catch (error) {
              console.error('❌ Error in set-zoom:', error);
            }
          }
        }
        break;
        
      case 'grid':
        setShowGrid(prev => !prev);
        break;
      case 'toggle-layers':
        setShowLayers(prev => !prev);
        break;
      case 'toggle-properties':
        setShowProperties(prev => !prev);
        break;
      case 'toggle-calibration':
        setShowCalibration(prev => !prev);
        break;
      case 'zoom-window':
        handleToolChange('zoom-window');
        break;
      case 'undo':
        if (dxfCanvasRef.current?.undo()) {
          setCanUndo(dxfCanvasRef.current.canUndo());
          setCanRedo(dxfCanvasRef.current.canRedo());
        }
        break;
      case 'redo':
        if (dxfCanvasRef.current?.redo()) {
          setCanUndo(dxfCanvasRef.current.canUndo());
          setCanRedo(dxfCanvasRef.current.canRedo());
        }
        break;
      default:
        console.log('🔍 Unhandled action:', action, data);
    }
  };

  const handleZoomWindowModeChange = (active: boolean) => {
    setIsZoomWindowActive(active);
    if (!active) {
      setActiveTool('select');
    }
  };

  const { importDxfFile } = useDxfImport();
  const handleSceneImported = async (file: File, encoding?: string) => {
    console.log('📦 DXF selected:', file.name, 'with encoding:', encoding || 'default');
    if (!currentLevelId) {
      alert('Δεν έχει επιλεγεί επίπεδο (Level) για εισαγωγή.');
      return;
    }
    try {
      const scene = await importDxfFile(file);
      if (!scene) {
        alert('Αποτυχία εισαγωγής DXF. Έλεγξε το αρχείο.');
        return;
      }
      // Σώζουμε στο state του επιπέδου
      setLevelScene(currentLevelId, scene);
      // Ζωγραφίζουμε και κάνουμε fit
      if (dxfCanvasRef.current) {
        dxfCanvasRef.current.renderScene(scene);
        requestAnimationFrame(() => dxfCanvasRef.current?.fitToView());
      }
      console.log('🎯 Scene entities loaded for snapping:', scene.entities?.length ?? 0);
    } catch (e) {
      console.error('⛔ DXF import failed:', e);
      alert('Αποτυχία εισαγωγής DXF.');
    }
  };

  const handleTransformChange = (transform: any) => {
    if (transform?.scale && typeof transform.scale === 'number') {
      setCurrentZoom(transform.scale);
    }
  };

  const handleSceneChange = (scene: SceneModel) => {
    if (!currentLevelId) return;
    
    try {
      setLevelScene(currentLevelId, scene);
      
      if (dxfCanvasRef.current) {
        setCanUndo(dxfCanvasRef.current.canUndo());
        setCanRedo(dxfCanvasRef.current.canRedo());
      }
    } catch (error) {
      console.error('⛔ Error updating scene:', error);
    }
  };

  const handleCalibrationToggle = (show: boolean) => {
    setShowCalibration(show);
  };

  // 📏 MEASUREMENT HANDLERS
  const onMeasurementPoint = (p: Pt) => {
    console.log('📏 Measurement point requested:', p);
    
    
    const snappedPoint = applySnap(p);
    // No measurement system({ position: {x:0, y:0}, worldPosition: snappedPoint } as MeasurementPoint);
    
    // 🎯 Emit canvas-click event για το DynamicInputOverlay (measurement tools)
    console.log('[EntityToolMapping] 🎯 DISPATCHING canvas-click event for measurement tool');
    window.dispatchEvent(new CustomEvent('canvas-click'));
  };
  
  const onMeasurementHover = (p: Pt | null) => {
    // Logic for hover is handled internally by the measurement system hook
  };

  const onMeasurementCancel = () => {
    
    // No measurement system();
  };

  // 🎨 NEW: DRAWING HANDLERS
  const onDrawingPoint = (p: Pt) => {
    console.log('🎨 Drawing point requested:', p);
    console.log('🎨 Drawing point requested:', p);
    const snappedPoint = applySnap(p);
    // Drawing is handled directly by the useUnifiedDrawing hook in DxfCanvas
    const transform = dxfCanvasRef.current?.getTransform() || { scale: 1, offsetX: 0, offsetY: 0 };
    drawingSystem.addPoint(snappedPoint, transform);
    console.log('🎨 Drawing point added (snapped):', snappedPoint, 'from:', p);
  };
  
  const onDrawingHover = (p: Pt | null) => {
    // Logic for hover preview is handled internally by the drawing system
     if(p) {
        const transform = dxfCanvasRef.current?.getTransform() || { scale: 1, offsetX: 0, offsetY: 0 };
        drawingSystem.updatePreview(p, transform);
    }
  };

  const onDrawingCancel = () => {
    drawingSystem.cancelDrawing();
    setActiveTool('select');
  };

  const onDrawingDoubleClick = () => {
    if (activeTool === 'polyline' || activeTool === 'polygon') {
      drawingSystem.finishPolyline();
      setActiveTool('select');
    }
  };

  // === UNIFIED CANVAS DOUBLE CLICK ===
  const onCanvasDoubleClick = () => {
    if (activeTool === 'polyline' || activeTool === 'polygon') {
      onDrawingDoubleClick();
    }
  };

  return (
    <div className={`flex flex-col h-full bg-gray-900 ${className || ''}`} onDoubleClick={onCanvasDoubleClick}>
      <div className="flex-shrink-0 p-2">
        <EnhancedDXFToolbar
          activeTool={activeTool}
          onToolChange={handleToolChange}
          onAction={handleAction}
          showGrid={showGrid}
          autoCrop={false}
          canUndo={canUndo}
          canRedo={canRedo}
          snapEnabled={snapEnabled}
          showLayers={showLayers}
          showProperties={showProperties}
          showCalibration={showCalibration}
          currentZoom={currentZoom}
          commandCount={0}
          onSceneImported={handleSceneImported}
        />
      </div>

      <div className="flex-1 flex overflow-hidden">
        <div className="w-80 flex-shrink-0 pl-3 pr-0 py-0">
          <div className="h-full bg-gray-800 rounded-lg shadow-lg border border-gray-700 overflow-hidden">
            <FloatingPanelContainer
              sceneModel={allLevelsScene}
              selectedEntityIds={selectedEntityIds}
              onEntitySelect={setSelectedEntityIds}
              zoomLevel={currentZoom}
              currentTool={activeTool}
            />
          </div>
        </div>
        <div className="flex-1 relative">
          <DxfCanvas
            ref={dxfCanvasRef}
            scene={enhancedCurrentScene}
            onTransformChange={handleTransformChange}
            selectedEntityIds={selectedEntityIds}
            onSelectEntity={(entityIds) => {
              // Always allow entity selection when clicking on canvas
              console.log('🎯 [EntityToolMapping] onSelectEntity called with:', entityIds, 'activeTool:', activeTool);
              setSelectedEntityIds(Array.isArray(entityIds) ? entityIds : [entityIds]);
            }}
            alwaysShowCoarseGrid={true}
            isZoomWindowActive={isZoomWindowActive}
            onZoomWindowModeChange={handleZoomWindowModeChange}
            showCalibration={showCalibration}
            onCalibrationToggle={handleCalibrationToggle}
            onSceneChange={handleSceneChange}
            activeTool={activeTool}
            // 📏 MEASUREMENT props
            measurements={[]}
            tempMeasurementPoints={[]}
            onMeasurementPoint={onMeasurementPoint}
            onMeasurementHover={onMeasurementHover}
            onMeasurementCancel={onMeasurementCancel}
            // 🎨 NEW: DRAWING props
            onDrawingPoint={onDrawingPoint}
            onDrawingHover={onDrawingHover}
            onDrawingCancel={onDrawingCancel}
            onDrawingDoubleClick={onDrawingDoubleClick}
            drawingState={drawingSystem.state}
            gripSettings={gripSettings}
            onEntityCreated={() => {}}
            // snapEnabled={snapEnabled}
            // enabledSnapModes={Array.from(enabledModes)}
            // onSnapPoint={findSnapPoint}
            className="absolute inset-0"
          />
          <OverlayCanvas
            transform={dxfCanvasRef.current?.getTransform() || { scale: 1, offsetX: 0, offsetY: 0 }}
          />
        </div>
      </div>
    </div>
  );
}

export default DxfViewerContent;
