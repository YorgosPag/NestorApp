/**
 * Arc Entity Renderer
 * Handles rendering of arc entities
 */

import { BaseEntityRenderer, type EntityModel, type GripInfo, type RenderOptions } from './BaseEntityRenderer';
import type { Point2D } from '../../systems/coordinates/config';
import { HoverManager } from '../hover';
import { validateArcEntity } from '../entity-validation-utils';
import { renderDotAtPoint } from './shared/dot-rendering-utils';

export class ArcRenderer extends BaseEntityRenderer {
  private validateArc(entity: EntityModel) {
    if (entity.type !== 'arc') return null;
    return validateArcEntity(entity);
  }

  render(entity: EntityModel, options: RenderOptions = {}): void {
    const arcData = this.validateArc(entity);
    if (!arcData) return;
    
    // 🎯 Χρήση 3-phase system όπως όλες οι άλλες οντότητες
    this.renderWithPhases(
      entity,
      options,
      // Geometry rendering
      () => this.renderArcGeometry(arcData.center, arcData.radius, arcData.startAngle, arcData.endAngle),
      // Measurements rendering  
      () => this.renderArcMeasurements(arcData.center, arcData.radius, arcData.startAngle, arcData.endAngle),
      // Yellow dots rendering
      () => this.renderArcYellowDots(arcData.center, arcData.radius, arcData.startAngle, arcData.endAngle)
    );
  }

  private renderArcGeometry(center: Point2D, radius: number, startAngle: number, endAngle: number): void {
    // Convert angles from degrees to radians
    const startRad = (startAngle * Math.PI) / 180;
    const endRad = (endAngle * Math.PI) / 180;
    
    // 🎯 Χρήση κεντρικοποιημένης μεθόδου - περνάμε world radius (η μέθοδος κάνει τη μετατροπή)
    this.drawCentralizedArc(center.x, center.y, radius, startRad, endRad);
  }

  private renderArcMeasurements(center: Point2D, radius: number, startAngle: number, endAngle: number): void {
    const screenCenter = this.worldToScreen(center);
    
    // Calculate arc measurements
    const arcAngle = Math.abs(endAngle - startAngle);
    const arcLength = (arcAngle * Math.PI / 180) * radius;
    
    this.ctx.save();
    this.applyCenterMeasurementTextStyle();
    this.ctx.fillText(`R: ${radius.toFixed(2)}`, screenCenter.x, screenCenter.y - 30);
    this.ctx.fillText(`∠: ${arcAngle.toFixed(1)}°`, screenCenter.x, screenCenter.y - 10);
    this.ctx.fillText(`L: ${arcLength.toFixed(2)}`, screenCenter.x, screenCenter.y + 10);
    this.ctx.restore();
  }

  private renderArcYellowDots(center: Point2D, radius: number, startAngle: number, endAngle: number): void {
    // 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ ΧΡΏΜΑ - το fillStyle έχει ήδη οριστεί από το renderWithPhases
    const dotRadius = 4;
    
    // Convert angles from degrees to radians
    const startRad = (startAngle * Math.PI) / 180;
    const endRad = (endAngle * Math.PI) / 180;
    
    // Center dot
    renderDotAtPoint(this.ctx, this.worldToScreen, center, dotRadius);
    
    // Start point dot
    const startPoint: Point2D = {
      x: center.x + radius * Math.cos(startRad),
      y: center.y + radius * Math.sin(startRad)
    };
    const screenStartPoint = this.worldToScreen(startPoint);
    this.ctx.beginPath();
    this.ctx.arc(screenStartPoint.x, screenStartPoint.y, dotRadius, 0, Math.PI * 2);
    this.ctx.fill();
    
    // End point dot
    const endPoint: Point2D = {
      x: center.x + radius * Math.cos(endRad),
      y: center.y + radius * Math.sin(endRad)
    };
    const screenEndPoint = this.worldToScreen(endPoint);
    this.ctx.beginPath();
    this.ctx.arc(screenEndPoint.x, screenEndPoint.y, dotRadius, 0, Math.PI * 2);
    this.ctx.fill();
  }

  getGrips(entity: EntityModel): GripInfo[] {
    const arcData = this.validateArcEntity(entity);
    if (!arcData) return [];
    
    const grips: GripInfo[] = [];
    const { center, radius, startAngle, endAngle } = arcData;
    
    // Convert angles from degrees to radians
    const startRad = (startAngle * Math.PI) / 180;
    const endRad = (endAngle * Math.PI) / 180;
    const midRad = (startRad + endRad) / 2;
    
    // Center grip
    grips.push({
      entityId: entity.id,
      gripType: 'center',
      gripIndex: 0,
      position: center,
      state: 'cold'
    });
    
    // Start point grip
    const startPoint: Point2D = {
      x: center.x + radius * Math.cos(startRad),
      y: center.y + radius * Math.sin(startRad)
    };
    
    grips.push({
      entityId: entity.id,
      gripType: 'vertex',
      gripIndex: 1,
      position: startPoint,
      state: 'cold'
    });
    
    // End point grip
    const endPoint: Point2D = {
      x: center.x + radius * Math.cos(endRad),
      y: center.y + radius * Math.sin(endRad)
    };
    
    grips.push({
      entityId: entity.id,
      gripType: 'vertex',
      gripIndex: 2,
      position: endPoint,
      state: 'cold'
    });
    
    // Midpoint grip
    const midPoint: Point2D = {
      x: center.x + radius * Math.cos(midRad),
      y: center.y + radius * Math.sin(midRad)
    };
    
    grips.push({
      entityId: entity.id,
      gripType: 'edge',
      gripIndex: 3,
      position: midPoint,
      state: 'cold'
    });
    
    return grips;
  }

  hitTest(entity: EntityModel, point: Point2D, tolerance: number): boolean {
    const arcData = this.validateArcEntity(entity);
    if (!arcData) return false;
    
    const { center, radius, startAngle, endAngle } = arcData;
    
    // Calculate distance from point to center
    const dx = point.x - center.x;
    const dy = point.y - center.y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // Check if point is near the arc's radius
    const worldTolerance = tolerance / this.transform.scale;
    if (Math.abs(distance - radius) > worldTolerance) {
      return false;
    }
    
    // Check if point is within the arc's angle range
    let angle = Math.atan2(dy, dx) * 180 / Math.PI;
    if (angle < 0) angle += 360;
    
    // Normalize angles
    let start = startAngle % 360;
    let end = endAngle % 360;
    if (start < 0) start += 360;
    if (end < 0) end += 360;
    
    // Check if angle is within arc range
    if (start <= end) {
      return angle >= start && angle <= end;
    } else {
      // Arc crosses 0 degrees
      return angle >= start || angle <= end;
    }
  }
}