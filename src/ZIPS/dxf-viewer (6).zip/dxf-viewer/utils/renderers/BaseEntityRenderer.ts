/**
 * Base Entity Renderer
 * Abstract base class for all entity-specific renderers
 */

import { coordTransforms, type ViewTransform, type Point2D } from '../../systems/coordinates/config';
import { CAD_UI } from '../../config/cadUiConfig';
import type { GripSettings } from '../../types/gripSettings';
import { PhaseManager, type PhaseManagerOptions } from '../../systems/phase-manager/PhaseManager';
import { calculateSplitLineGap } from './shared/line-utils';
import { DEFAULT_TOLERANCE } from '../../config/tolerance-config';
import { UI_COLORS } from '../../config/color-config';

export interface EntityModel {
  id: string;
  type: string;
  layer: string;
  visible?: boolean;
  preview?: boolean;
  color?: string;
  [key: string]: any;
}

export interface GripInfo {
  entityId: string;
  gripType: 'vertex' | 'edge' | 'center' | 'corner';
  gripIndex: number;
  position: Point2D;
  state: 'cold' | 'warm' | 'hot';
}

export interface RenderOptions {
  selected?: boolean;
  hovered?: boolean;
  preview?: boolean;
  grips?: boolean;
  strokeOverride?: string | null;
  measurement?: boolean;
}

export abstract class BaseEntityRenderer {
  protected ctx: CanvasRenderingContext2D;
  protected transform: ViewTransform = { scale: 1, offsetX: 0, offsetY: 0 };
  protected gripSettings?: GripSettings;
  protected gripInteraction: {
    hovered?: { entityId: string; gripIndex: number };
    active?: { entityId: string; gripIndex: number };
  } = {};
  protected phaseManager: PhaseManager;

  constructor(ctx: CanvasRenderingContext2D) {
    this.ctx = ctx;
    this.phaseManager = new PhaseManager({
      ctx: this.ctx,
      transform: this.transform,
      worldToScreen: this.worldToScreen.bind(this)
    });
  }

  // Transform setters
  setTransform(transform: ViewTransform): void {
    this.transform = { ...transform };
    this.phaseManager.updateTransform(this.transform);
  }

  setGripSettings(settings: GripSettings): void {
    this.gripSettings = settings;
  }

  public setGripInteractionState(next: typeof this.gripInteraction) {
    this.gripInteraction = next || {};
  }

  // Coordinate transformations
  protected worldToScreen(point: Point2D): Point2D {
    const rect = this.ctx.canvas.getBoundingClientRect();
    return coordTransforms.worldToScreen(point, this.transform, rect);
  }

  protected screenToWorld(point: Point2D): Point2D {
    const rect = this.ctx.canvas.getBoundingClientRect();
    return coordTransforms.screenToWorld(point, this.transform, rect);
  }

  // Abstract methods to be implemented by subclasses
  abstract render(entity: EntityModel, options: RenderOptions): void;
  abstract getGrips(entity: EntityModel): GripInfo[];
  abstract hitTest(entity: EntityModel, point: Point2D, tolerance: number): boolean;

  // New phase-based grip rendering
  protected renderGrips(entity: EntityModel, options: RenderOptions = {}): void {
    if (!this.gripSettings?.showGrips) return;
    
    const grips = this.getGrips(entity);
    const phaseState = this.phaseManager.determinePhase(entity, options);
    
    // Set grip interaction state for PhaseManager
    phaseState.gripState = {
      hovered: this.gripInteraction.hovered,
      active: this.gripInteraction.active,
      dragging: this.isDragging() // Check if currently dragging
    };
    
    this.phaseManager.renderPhaseGrips(entity, grips, phaseState);
  }

  /**
   * Check if grip is currently being dragged
   */
  private isDragging(): boolean {
    // This will be connected to actual drag detection logic
    // For now, return false - to be implemented
    return false;
  }

  /**
   * DEPRECATED: Live drag measurements are now handled by individual entity renderers
   * This method is kept for compatibility but should not be used
   */
  public renderGripDragMeasurements(entity: EntityModel, draggedGripIndex: number, currentPosition: Point2D): void {
    // DEPRECATED: Live drag measurements are now handled by individual entity renderers
  }

  /**
   * 🎨 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ TEXT STYLING SYSTEM
   * Όλα τα κείμενα χρησιμοποιούν αυτές τις μεθόδους
   */
  
  // Base font size - ΣΤΑΘΕΡΟ 11px όπως η πολυγραμμή
  protected getBaseFontSize(): number {
    return 11; // Σταθερό μέγεθος για consistency
  }

  /**
   * Style για μετρήσεις διαστάσεων (δίπλα στα grips)
   */
  protected applyDimensionTextStyle(): void {
    this.ctx.fillStyle = 'fuchsia';  // Fuchsia
    this.ctx.font = `${this.getBaseFontSize()}px Arial`;
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ ΧΡΏΜΑ DISTANCE TEXT - μία αλλαγή εδώ αλλάζει όλα
   * Χρώμα για τα κείμενα αποστάσεων στη φάση προεπισκόπησης
   */
  protected applyDistanceTextStyle(): void {
    this.ctx.fillStyle = UI_COLORS.DISTANCE_TEXT; // Πράσινο για distance text
    this.ctx.font = `${this.getBaseFontSize()}px Arial`;
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
  }

  /**
   * Style για κεντρικές μετρήσεις (εμβαδόν, περίμετρος) - Χρησιμοποιεί κεντρικοποιημένο χρώμα
   */
  protected applyCenterMeasurementTextStyle(): void {
    this.applyDimensionTextStyle(); // Use centralized fuchsia color and styling
  }

  /**
   * Style για corner/grip μετρήσεις - Χρησιμοποιεί κεντρικοποιημένο χρώμα
   */
  protected applyCornerTextStyle(): void {
    this.applyDimensionTextStyle(); // Use centralized fuchsia color and styling
  }


  /**
   * Γενική μέθοδος - όλα τα κείμενα
   */
  protected applyMeasurementTextStyle(): void {
    this.applyDimensionTextStyle(); // Default
  }

  private stateForGrip(entityId: string, idx: number): 'cold'|'warm'|'hot' {
    if (this.gripInteraction.active?.entityId === entityId &&
        this.gripInteraction.active?.gripIndex === idx) return 'hot';
    if (this.gripInteraction.hovered?.entityId === entityId &&
        this.gripInteraction.hovered?.gripIndex === idx) return 'warm';
    return 'cold';
  }

  private drawGripAtWorld(worldPt: Point2D, state: 'cold'|'warm'|'hot', gripType?: string) {
    const rect = this.ctx.canvas.getBoundingClientRect();
    const screenPoint = coordTransforms.worldToScreen(worldPt, this.transform, rect);
    this.drawGrip(screenPoint, state, gripType);
  }

  // viewport culling για grips - κερδίζουμε πολλά όταν έχουμε χιλιάδες
  private onScreen = (p: Point2D) => {
    const rect = this.ctx.canvas.getBoundingClientRect();
    return p.x >= 0 && p.y >= 0 && p.x <= rect.width && p.y <= rect.height;
  };

  // όταν σχεδιάζεις grips για γραμμή:
  renderLineGrips(entity: any) {
    const rect = this.ctx.canvas.getBoundingClientRect();
    const s = coordTransforms.worldToScreen(entity.start, this.transform, rect);
    const e = coordTransforms.worldToScreen(entity.end,   this.transform, rect);
    const mid = { x:(s.x+e.x)/2, y:(s.y+e.y)/2 };

    if (!this.onScreen(s) && !this.onScreen(e) && !this.onScreen(mid)) return; // ✅ skip

    this.drawGripAtWorld(entity.start, this.stateForGrip(entity.id, 0), 'vertex'); // start
    this.drawGripAtWorld(entity.end,   this.stateForGrip(entity.id, 1), 'vertex'); // end
    this.drawGripAtWorld({ x: (entity.start.x+entity.end.x)/2, y: (entity.start.y+entity.end.y)/2 }, this.stateForGrip(entity.id, 2), 'edge'); // mid
  }

  protected drawGrip(position: Point2D, state: 'cold' | 'warm' | 'hot', gripType?: string): void {
    const base = this.gripSettings?.gripSize || 10;
    const size = state === 'hot'  ? Math.round(base * 1.5)
               : state === 'warm' ? Math.round(base * 1.25)
                                  : Math.round(base);

    const colors = this.gripSettings?.colors ?? {
      cold: UI_COLORS.THERMAL_COLD,
      warm: UI_COLORS.THERMAL_WARM, 
      hot: UI_COLORS.THERMAL_HOT,
      contour: UI_COLORS.THERMAL_CONTOUR
    };
    
    // Διαφοροποίηση χρώματος ανάλογα με το gripType
    let baseColor = colors.cold; // Default για vertex grips
    if (gripType === 'edge') {
      // Χρησιμοποιούμε πράσινο χρώμα για edge/midpoint grips
      baseColor = UI_COLORS.GRIP_DEFAULT; // Πράσινο για μεσαία grips
    }
    
    const fill = state === 'hot'  ? colors.hot
               : state === 'warm' ? colors.warm
                                  : baseColor;

    this.ctx.save();
    this.ctx.fillStyle = fill;
    this.ctx.strokeStyle = UI_COLORS.GRIP_OUTLINE;
    this.ctx.lineWidth = 1;

    this.ctx.fillRect(position.x - size/2, position.y - size/2, size, size);
    this.ctx.strokeRect(position.x - size/2, position.y - size/2, size, size);
    this.ctx.restore();
  }

  // Grip hit testing
  public findGripAtPoint(entity: EntityModel, screenPoint: Point2D, tolerance: number = DEFAULT_TOLERANCE): GripInfo | null {
    if (!this.gripSettings) return null;
    
    const grips = this.getGrips(entity);
    
    for (const grip of grips) {
      const screenGrip = this.worldToScreen(grip.position);
      const dx = screenPoint.x - screenGrip.x;
      const dy = screenPoint.y - screenGrip.y;
      const distance = Math.sqrt(dx * dx + dy * dy);
      
      if (distance <= tolerance) {
        return grip;
      }
    }
    
    return null;
  }

  // New phase-based style setup
  protected setupStyle(entity: EntityModel, options: RenderOptions = {}): void {
    this.ctx.save();
    
    // Determine current phase and apply appropriate styling
    const phaseState = this.phaseManager.determinePhase(entity, options);
    this.phaseManager.applyPhaseStyle(entity, phaseState);
  }

  protected applyEntityStyle(entity: EntityModel): void {
    // Apply authentic entity style (color from layer/entity)
    this.ctx.strokeStyle = entity.color || CAD_UI.entity.default;
    this.ctx.lineWidth = 1;
    // Keep solid line for authentic style
    this.ctx.setLineDash([]);
  }

  protected cleanupStyle(): void {
    this.ctx.restore();
  }

  // ===== TEMPLATE METHOD PATTERN =====
  // Unified rendering flow to eliminate duplication
  
  /**
   * Universal Template Method for 3-Phase Entity Rendering
   * Handles all entities uniformly through PhaseManager
   */
  protected renderWithPhases(
    entity: EntityModel, 
    options: RenderOptions = {}, 
    renderGeometry: () => void,
    renderMeasurements?: () => void,
    renderYellowDots?: () => void
  ): void {
    // 1. Determine current phase
    const phaseState = this.phaseManager.determinePhase(entity, options);
    
    // 2. Setup phase-appropriate style
    this.setupStyle(entity, options);
    
    // 3. Render geometry (always)
    renderGeometry();
    
    // 4. Render measurements if phase requires them
    const shouldMeasure = this.phaseManager.shouldRenderMeasurements(phaseState, entity);
    if (shouldMeasure && renderMeasurements) {
      renderMeasurements();
    }
    
    // 5. Render colored dots with centralized color management
    if (this.phaseManager.shouldRenderYellowDots(phaseState, entity) && renderYellowDots) {
      // Set centralized dot color before rendering dots
      this.ctx.save();
      this.ctx.fillStyle = this.phaseManager.getPreviewDotColor(entity);
      renderYellowDots();
      this.ctx.restore();
    }
    
    // 6. Draw grips with phase-appropriate colors
    if (options.grips && !options.preview) {
      this.renderGrips(entity, options);
    }
    
    // 7. Cleanup
    this.cleanupStyle();
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΗ ΤΟΠΟΘΈΤΗΣΗ ΚΕΙΜΈΝΩΝ ΑΠΟΣΤΆΣΕΩΝ
   * Υπολογίζει τη θέση του κειμένου ΕΣΩΤΕΡΙΚΑ της γραμμής 
   * για να μη κρύβει το midpoint grip
   */
  protected calculateDistanceTextPosition(screenStart: Point2D, screenEnd: Point2D, offsetDistance: number = 15): Point2D {
    // Calculate line direction
    const dx = screenEnd.x - screenStart.x;
    const dy = screenEnd.y - screenStart.y;
    const length = Math.sqrt(dx * dx + dy * dy);
    
    if (length === 0) {
      return { x: screenStart.x, y: screenStart.y };
    }
    
    // Unit vectors for line direction and perpendicular
    const unitX = dx / length;
    const unitY = dy / length;
    const perpX = -unitY; // Perpendicular to the left
    const perpY = unitX;
    
    // Midpoint of the line
    const midX = (screenStart.x + screenEnd.x) / 2;
    const midY = (screenStart.y + screenEnd.y) / 2;
    
    // Offset the text position INSIDE the line (perpendicular offset)
    // Positive offset moves text to the "left" side of the line direction
    return {
      x: midX + perpX * offsetDistance,
      y: midY + perpY * offsetDistance
    };
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΗ ΜΈΘΟΔΟΣ INLINE DISTANCE TEXT ΓΙΑ ΠΡΟΕΠΙΣΚΌΠΗΣΗ
   * Σχεδιάζει το κείμενο απόστασης ΣΤΗΝ ΊΔΙΑ ΕΥΘΕΊΑ της γραμμής (όχι έκκεντρα)
   */
  protected renderInlineDistanceText(worldStart: Point2D, worldEnd: Point2D, screenStart: Point2D, screenEnd: Point2D): void {
    // Calculate midpoint (στο κέντρο της γραμμής - inline)
    const midX = (screenStart.x + screenEnd.x) / 2;
    const midY = (screenStart.y + screenEnd.y) / 2;
    const textPosition = { x: midX, y: midY };
    
    // Use common distance text rendering
    this.renderDistanceTextCommon(worldStart, worldEnd, screenStart, screenEnd, textPosition);
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΗ ΜΈΘΟΔΟΣ ΑΠΌΣΤΑΣΗΣ ΓΙΑ ΌΛΕΣ ΤΙΣ ΓΡΑΜΜΈΣ
   * Σχεδιάζει το κείμενο απόστασης με περιστροφή στο εσωτερικό της γραμμής
   */
  protected renderDistanceTextCentralized(worldStart: Point2D, worldEnd: Point2D, screenStart: Point2D, screenEnd: Point2D, offsetDistance: number = 15): void {
    // Get text position inside the line
    const textPos = this.calculateDistanceTextPosition(screenStart, screenEnd, offsetDistance);
    
    // Use common distance text rendering
    this.renderDistanceTextCommon(worldStart, worldEnd, screenStart, screenEnd, textPos);
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΗ ΜΈΘΟΔΟΣ DISTANCE TEXT ΜΕ PHASE-AWARE POSITIONING
   * Επιλέγει την κατάλληλη μέθοδος ανάλογα με τη φάση (inline για preview, offset για measurements)
   */
  protected renderDistanceTextPhaseAware(worldStart: Point2D, worldEnd: Point2D, screenStart: Point2D, screenEnd: Point2D, entity: EntityModel, options: RenderOptions): void {
    const phaseState = this.phaseManager.determinePhase(entity, options);
    
    if (phaseState.phase === 'preview') {
      // Στη φάση προεπισκόπησης: inline positioning (στην ίδια ευθεία)
      this.renderInlineDistanceText(worldStart, worldEnd, screenStart, screenEnd);
    } else {
      // Στις άλλες φάσεις: offset positioning (έκκεντρα)
      this.renderDistanceTextCentralized(worldStart, worldEnd, screenStart, screenEnd);
    }
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟΣ ΈΛΕΓΧΟΣ SPLIT LINE 
   * Καθορίζει αν μια οντότητα χρειάζεται split line με distance text
   */
  protected shouldRenderSplitLine(entity: EntityModel, options: RenderOptions = {}): boolean {
    // Αν είναι preview phase και έχει showEdgeDistances flag
    const phaseState = this.phaseManager.determinePhase(entity, options);
    const hasDistanceFlag = (entity as any).showEdgeDistances === true;
    
    return phaseState.phase === 'preview' && hasDistanceFlag;
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΗ ΜΈΘΟΔΟΣ ΣΠΑΣΜΈΝΗΣ ΓΡΑΜΜΉΣ ΓΙΑ ΌΛΕΣ ΤΙΣ ΟΝΤΌΤΗΤΕΣ
   * Σχεδιάζει γραμμή με κενό στο κέντρο για distance text - για όλες τις οντότητες κατά την προεπισκόπηση
   */
  protected renderSplitLineWithGap(screenStart: Point2D, screenEnd: Point2D, gapSize: number = 30): void {
    // Use shared gap calculation logic
    const { gapStart, gapEnd } = calculateSplitLineGap(screenStart, screenEnd, gapSize);
    
    // Draw split line with gap for text
    this.ctx.beginPath();
    this.ctx.moveTo(screenStart.x, screenStart.y);
    this.ctx.lineTo(gapStart.x, gapStart.y);
    this.ctx.stroke();
    
    this.ctx.beginPath();
    this.ctx.moveTo(gapEnd.x, gapEnd.y);
    this.ctx.lineTo(screenEnd.x, screenEnd.y);
    this.ctx.stroke();
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ ΣΤΙΛ ΤΌΞΩΝ - πορτοκαλί χρώμα με διακεκομμένες γραμμές
   */
  protected applyArcStyle(): void {
    this.ctx.strokeStyle = UI_COLORS.DRAWING_TEMP; // Πορτοκαλί χρώμα
    this.ctx.setLineDash([3, 3]); // Διακεκομμένες γραμμές
    this.ctx.lineWidth = 1;
  }

  /**
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΗ ΜΈΘΟΔΟΣ ΣΧΕΔΊΑΣΗΣ ΤΌΞΩΝ
   * - Πάντοτε ΕΣΩΤΕΡΙΚΆ τόξα (μικρότερη γωνία)
   * - Πάντα ορατά στη φάση προεπισκόπησης
   * - Για όλες τις οντότητες (σχεδίασης & μέτρησης)
   */
  protected drawCentralizedArc(
    centerX: number, 
    centerY: number, 
    radius: number, 
    startAngle: number, 
    endAngle: number, 
    clockwise?: boolean
  ): void {
    this.ctx.save();
    this.applyArcStyle();
    
    const screenCenter = this.worldToScreen({ x: centerX, y: centerY });
    
    // 🎯 ΑΥΤΟΜΑΤΟΣ ΥΠΟΛΟΓΙΣΜΟΣ ΕΣΩΤΕΡΙΚΟΥ ΤΟΞΟΥ
    // Normalize angles to [0, 2π] range
    let normalizedStart = startAngle % (2 * Math.PI);
    let normalizedEnd = endAngle % (2 * Math.PI);
    if (normalizedStart < 0) normalizedStart += 2 * Math.PI;
    if (normalizedEnd < 0) normalizedEnd += 2 * Math.PI;
    
    // Calculate angle difference
    let angleDiff = normalizedEnd - normalizedStart;
    
    // Ensure we always draw the SMALLER arc (interior angle)
    let useClockwise = false;
    let finalStart = normalizedStart;
    let finalEnd = normalizedEnd;
    
    if (Math.abs(angleDiff) > Math.PI) {
      // If angle > 180°, draw the smaller arc in opposite direction
      if (angleDiff > 0) {
        // Switch to clockwise for smaller arc
        useClockwise = true;
        finalStart = normalizedEnd;
        finalEnd = normalizedStart;
      } else {
        // Switch to counter-clockwise for smaller arc  
        useClockwise = false;
        finalStart = normalizedEnd;
        finalEnd = normalizedStart;
      }
    } else {
      // Angle <= 180°, use original direction
      useClockwise = angleDiff < 0;
    }
    
    // 🎯 ΠΆΝΤΑ ΟΡΑΤΆ ΣΤΗ ΦΆΣΗ ΠΡΟΕΠΙΣΚΟΠΗΣΗΣ
    // (Το applyArcStyle() ήδη εφαρμόζει το styling)
    
    this.ctx.beginPath();
    const screenRadius = radius * this.transform.scale; // Μετατροπή σε screen pixels
    this.ctx.arc(screenCenter.x, screenCenter.y, screenRadius, finalStart, finalEnd, useClockwise);
    this.ctx.stroke();
    
    this.ctx.restore();
  }

  /**
   * Common distance text rendering setup - eliminates duplication
   */
  private renderDistanceTextCommon(
    worldStart: Point2D, 
    worldEnd: Point2D, 
    screenStart: Point2D, 
    screenEnd: Point2D,
    textPosition: Point2D
  ): void {
    // Calculate world distance
    const worldDistance = Math.sqrt(
      Math.pow(worldEnd.x - worldStart.x, 2) + Math.pow(worldEnd.y - worldStart.y, 2)
    );
    
    // Calculate line angle for text rotation
    const dx = screenEnd.x - screenStart.x;
    const dy = screenEnd.y - screenStart.y;
    const angle = Math.atan2(dy, dx);
    
    // Format distance text
    const text = worldDistance.toFixed(2);
    
    // Save context for rotation
    this.ctx.save();
    
    // Move to text position and rotate
    this.ctx.translate(textPosition.x, textPosition.y);
    
    // Rotate text to be readable (don't flip upside down)
    let textAngle = angle;
    if (Math.abs(textAngle) > Math.PI / 2) {
      textAngle += Math.PI;
    }
    this.ctx.rotate(textAngle);
    
    // Apply distance text styling (green for distance text)
    this.applyDistanceTextStyle();
    this.ctx.fillText(text, 0, 0);
    
    // Restore context
    this.ctx.restore();
  }

  /**
   * Common vertex dots rendering - eliminates duplication across renderers
   */
  protected renderVertexDots(vertices: Point2D[], dotRadius: number = 4): void {
    // 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ ΧΡΏΜΑ - το fillStyle έχει ήδη οριστεί από το renderWithPhases
    vertices.forEach(vertex => {
      const screenVertex = this.worldToScreen(vertex);
      this.ctx.beginPath();
      this.ctx.arc(screenVertex.x, screenVertex.y, dotRadius, 0, Math.PI * 2);
      this.ctx.fill();
    });
  }

  /**
   * Common rendering finalization - grips and cleanup
   */
  protected finalizeRendering(entity: EntityModel, options: RenderOptions): void {
    // Draw grips if needed
    if (options.grips && !options.preview) {
      this.renderGrips(entity);
    }
    
    // Cleanup
    this.cleanupStyle();
  }

}