/**
 * Unified Tool Style Store
 * Single source of truth for drawing styles across DXF and Overlay tools
 */

export interface ToolStyle {
  strokeColor: string;
  fillColor: string;
  lineWidth: number;
  opacity: number;
}

import { useSyncExternalStore } from 'react';

type Listener = () => void;
let current: ToolStyle = {
  strokeColor: '#ff5555',
  fillColor:   '#00000000',
  lineWidth:   1,
  opacity:     1,
};
const listeners = new Set<Listener>();

export const toolStyleStore = {
  get(): ToolStyle {
    return current;
  },
  set(next: Partial<ToolStyle>) {
    current = { ...current, ...next };
    listeners.forEach(l => l());
  },
  subscribe(cb: Listener) {
    listeners.add(cb);
    return () => listeners.delete(cb);
  }
};

export function useToolStyle(): ToolStyle {
  return useSyncExternalStore(toolStyleStore.subscribe, toolStyleStore.get, toolStyleStore.get);
}