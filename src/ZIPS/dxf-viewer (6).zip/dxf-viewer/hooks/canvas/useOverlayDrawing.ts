import { useRef } from 'react';
import type { OverlayRenderer } from '../../canvas/overlay-renderer';
import type { ViewTransform } from '../../canvas/renderer';
import type { Point2D } from '../../types/overlay';

export function useOverlayDrawing() {
  const justFinishedRef = useRef<number>(0);

  const handleDrawingClick = (
    mousePos: { x: number; y: number },
    renderer: OverlayRenderer,
    transform: ViewTransform,
    drawingVertices: Point2D[],
    addDrawingVertex: (point: Point2D) => void,
    finishDrawing: () => void
  ) => {
    const world = renderer.screenToWorld(mousePos, transform);
    
    // Check if clicking near first vertex to close
    if (drawingVertices.length >= 3) {
      const first = renderer.worldToScreen(drawingVertices[0], transform);
      const dx = mousePos.x - first.x;
      const dy = mousePos.y - first.y;
      if (Math.sqrt(dx * dx + dy * dy) <= 12) {
        finishDrawing();
        justFinishedRef.current = Date.now();
        return true; // Handled
      }
    }
    
    addDrawingVertex(world);
    return true; // Handled
  };

  const shouldIgnoreClick = () => {
    return Date.now() - justFinishedRef.current < 120;
  };

  const markFinished = () => {
    justFinishedRef.current = Date.now();
  };

  return {
    handleDrawingClick,
    shouldIgnoreClick,
    markFinished
  };
}
