/**
 * Dynamic Input Type Definitions
 * 
 * Centralized type exports for external consumers
 */

// Re-export core types
export type { Field, Phase, Point } from './hooks/useDynamicInputState';

// Re-export interface types
export type { 
  FieldValueActions,
  FieldStateActions,
  CoordinateActions,
  PhaseActions,
  InputRefActions,
  ValidationActions,
  FeedbackActions,
  ResetActions
} from './hooks/interfaces';

// Component prop types
export interface DynamicInputOverlayProps {
  className?: string;
  isActive?: boolean;
  cursorPosition?: { x: number; y: number } | null;
  viewport?: { width: number; height: number };
  activeTool?: string;
  canvasRect?: DOMRect | null;
  mouseWorldPosition?: { x: number; y: number } | null;
  tempPoints?: { x: number; y: number }[] | null; // For multi-point tools like polyline/polygon
}

export interface DynamicInputFieldProps {
  label: string;
  value: string;
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onFocus?: () => void;
  inputRef?: React.RefObject<HTMLInputElement>;
  disabled?: boolean;
  isActive?: boolean;
  isAnchored?: boolean;
  placeholder?: string;
  onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
  fieldType?: 'coordinate' | 'angle' | 'length';
}