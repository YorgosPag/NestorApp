import { useCallback } from 'react';
import type { ToolbarConfig, ToolbarOperationResult, ToolbarState } from '../config';
import { ToolbarSystemUtils } from '../utils';

interface ToolbarManagementParams {
  state: ToolbarState;
  setState: React.Dispatch<React.SetStateAction<ToolbarState>>;
  onError?: (error: string) => void;
}

export function useToolbarManagement({
  state,
  setState,
  onError
}: ToolbarManagementParams) {

  // ===== TOOLBAR CONFIGURATION MANAGEMENT =====
  const createToolbar = useCallback(async (config: ToolbarConfig): Promise<ToolbarOperationResult> => {
    try {
      const validation = ToolbarSystemUtils.validateToolbarConfig(config);
      if (!validation.valid) {
        return {
          success: false,
          operation: 'create-toolbar',
          toolbarId: config.id,
          error: validation.errors.join(', ')
        };
      }

      setState(prev => ({
        ...prev,
        toolbars: { ...prev.toolbars, [config.id]: config }
      }));

      return {
        success: true,
        operation: 'create-toolbar',
        toolbarId: config.id,
        data: config
      };
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Failed to create toolbar';
      onError?.(errorMsg);
      return {
        success: false,
        operation: 'create-toolbar',
        toolbarId: config.id,
        error: errorMsg
      };
    }
  }, [onError, setState]);

  const deleteToolbar = useCallback(async (toolbarId: string): Promise<ToolbarOperationResult> => {
    try {
      setState(prev => {
        const { [toolbarId]: removedToolbar, ...remainingToolbars } = prev.toolbars;
        return {
          ...prev,
          toolbars: remainingToolbars,
          activeToolbar: prev.activeToolbar === toolbarId ? null : prev.activeToolbar
        };
      });

      return {
        success: true,
        operation: 'delete-toolbar',
        toolbarId
      };
    } catch (error) {
      const errorMsg = error instanceof Error ? error.message : 'Failed to delete toolbar';
      onError?.(errorMsg);
      return {
        success: false,
        operation: 'delete-toolbar',
        toolbarId,
        error: errorMsg
      };
    }
  }, [onError, setState]);

  // Utility functions
  const getToolbar = useCallback((toolbarId: string) => state.toolbars[toolbarId], [state.toolbars]);
  const getToolbars = useCallback(() => state.toolbars, [state.toolbars]);
  const getVisibleToolbars = useCallback(() => 
    Object.values(state.toolbars).filter(toolbar => toolbar.visible),
    [state.toolbars]
  );

  return {
    createToolbar,
    deleteToolbar,
    getToolbar,
    getToolbars,
    getVisibleToolbars
  };
}