'use client';

import React, { createContext, useContext, useState, useCallback, useMemo, useRef } from 'react';
import type { GripSettings } from '../types/gripSettings';
import { validateGripSettings, DEFAULT_GRIP_SETTINGS } from '../types/gripSettings';

// === CONTEXT TYPE ===
interface GripContextType {
  gripSettings: GripSettings;
  updateGripSettings: (updates: Partial<GripSettings>) => void;
  getGripSize: (state: 'cold' | 'warm' | 'hot') => number;
  getGripColor: (state: 'cold' | 'warm' | 'hot') => string;
}

// === CONTEXT CREATION ===
const GripContext = createContext<GripContextType | null>(null);

interface GripProviderProps {
  children: React.ReactNode;
}

// === DEEP EQUALITY CHECK για Object Stability ===
function deepEqual(a: any, b: any): boolean {
  if (a === b) return true;
  if (a == null || b == null) return false;
  if (typeof a !== 'object' || typeof b !== 'object') return false;
  
  const keysA = Object.keys(a);
  const keysB = Object.keys(b);
  
  if (keysA.length !== keysB.length) return false;
  
  for (const key of keysA) {
    if (!keysB.includes(key)) return false;
    if (!deepEqual(a[key], b[key])) return false;
  }
  
  return true;
}

// === STABLE GRIP PROVIDER ===
export function GripProvider({ children }: GripProviderProps) {
  const [gripSettings, setGripSettings] = useState<GripSettings>(DEFAULT_GRIP_SETTINGS);
  
  // Debug (αφαιρείται σε production)
  const DEBUG = process.env.NODE_ENV !== 'production';
  const renderCount = useRef(0);
  renderCount.current++;
  
  if (DEBUG) {
    console.log(`🔧 [GripProvider] Render #${renderCount.current}, settings:`, gripSettings);
  }

  // === STABLE UPDATE FUNCTION με Object Equality Guard ===
  const updateGripSettings = useCallback((updates: Partial<GripSettings>) => {
    if (DEBUG) console.log('🔧 [GripProvider] updateGripSettings called with:', updates);
    
    setGripSettings(prev => {
      // Create new object με τα updates
      const next = validateGripSettings({ ...prev, ...updates });
      
      // === CRITICAL: Object stability check ===
      if (deepEqual(prev, next)) {
        if (DEBUG) console.log('🔧 [GripProvider] Settings unchanged - returning same reference');
        return prev; // Same reference → NO re-render cascade
      }
      
      if (DEBUG) console.log('🔧 [GripProvider] Settings changed - new reference');
      return next;
    });
  }, [DEBUG]);

  // === STABLE HELPER FUNCTIONS ===
  const getGripSize = useCallback((state: 'cold' | 'warm' | 'hot') => {
    const baseSize = gripSettings.gripSize * gripSettings.dpiScale;
    switch (state) {
      case 'warm': return Math.round(baseSize * 1.2);
      case 'hot': return Math.round(baseSize * 1.4);
      case 'cold':
      default: return Math.round(baseSize);
    }
  }, [gripSettings.gripSize, gripSettings.dpiScale]);

  const getGripColor = useCallback((state: 'cold' | 'warm' | 'hot') => {
    return gripSettings.colors[state];
  }, [gripSettings.colors]);

  // === STABLE CONTEXT VALUE με useMemo ===
  const contextValue = useMemo<GripContextType>(() => {
    if (DEBUG) console.log('🔧 [GripProvider] Creating new context value');
    
    return {
      gripSettings,
      updateGripSettings,
      getGripSize,
      getGripColor
    };
  }, [gripSettings, updateGripSettings, getGripSize, getGripColor]);

  // Reduced debug spam
  // if (DEBUG) {
  //   console.log('🔧 [GripProvider] Returning context with stable value');
  // }

  return (
    <GripContext.Provider value={contextValue}>
      {children}
    </GripContext.Provider>
  );
}

// === HOOK για Context Access ===
export function useGripContext(): GripContextType {
  const context = useContext(GripContext);
  
  if (!context) {
    throw new Error('useGripContext must be used within a GripProvider');
  }
  
  // Debug - reduced spam
  const DEBUG = process.env.NODE_ENV !== 'production';
  // if (DEBUG) {
  //   console.log('🔧 [useGripContext] Returning context:', context);
  // }
  
  return context;
}

// === EXPORTS ===
export default GripProvider;
export type { GripContextType };
