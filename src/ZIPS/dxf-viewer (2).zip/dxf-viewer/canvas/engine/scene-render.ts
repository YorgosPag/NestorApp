import type { SceneModel, AnySceneEntity } from '../../types/scene';
import type { Point2D, ViewTransform } from '../../config/unified-grid-configuration';
import type { AnyMeasurement } from '../../types/measurements';
import { MeasurementRenderer } from '../../utils/measurement-tools';
import { EntityRenderer } from '../../utils/entity-renderer';
import type { GripSettings } from '../../types/gripSettings';
import { drawRulers, drawGrid } from './rulers-grid';


export interface RenderOptions {
  measurementRenderer?: MeasurementRenderer;
  measurements?: AnyMeasurement[];
  tempMeasurementPoints?: Point2D[];
  mousePosition?: Point2D;
  drawingState?: { previewEntity?: AnySceneEntity };
  selectedIdsRef: React.MutableRefObject<Set<string>>;
  hoverIdRef: React.MutableRefObject<string | null>;
  previewOverrideRef?: React.MutableRefObject<{ entityId: string; next: any } | null>; // ✅ overlay preview
  marqueeOverlayRef?: React.MutableRefObject<{ start: Point2D; end: Point2D } | null>; // ✅ marquee overlay
}

export function renderScene(args: {
  ctx: CanvasRenderingContext2D;
  canvas: HTMLCanvasElement;
  scene: SceneModel;
  entityRenderer: EntityRenderer;
  transformRef: React.MutableRefObject<ViewTransform>;
  gripSettings: GripSettings;
  alwaysShowCoarseGrid: boolean;
  options?: RenderOptions;
}) {
  const {
    ctx,
    canvas,
    scene,
    entityRenderer,
    transformRef,
    gripSettings,
    alwaysShowCoarseGrid,
    options = {}
  } = args;
  
  console.log(`🚀 [scene-render] START: entities=${scene?.entities?.length || 0}`);

  const rect = canvas.getBoundingClientRect();
  const dpr = Math.max(1, window.devicePixelRatio || 1);
  
  ctx.save();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.restore();
  ctx.setTransform(1, 0, 0, 1, 0, 0);
  ctx.scale(dpr, dpr);
  
  entityRenderer.setTransform(transformRef.current);
  entityRenderer.setGripSettings(gripSettings);
  
  const getLayerColor = (layerName: string) => {
    return scene.layers[layerName]?.color || '#ffffff';
  };
  
  // ✅ Extract preview override για overlay system
  const previewOv = options.previewOverrideRef?.current; // {entityId, next} | null
  
  // ✅ Get selected and hovered IDs from refs FIRST
  const selectedIds = options.selectedIdsRef?.current ?? new Set<string>();
  const hoverId = options.hoverIdRef?.current ?? null;
  
  console.log(`🎯 [scene-render] START: selectedIds size=${selectedIds.size}, hoverId=${hoverId}`);
  
  // ✅ 1) Regular pass (authentic, no grips) - SKIP selected AND hovered entities
  scene.entities.forEach(entity => {
    // ✅ Skip selected entities - they will render with grips in the selected pass
    if (selectedIds.has(entity.id)) {
      if (entity.type === 'rectangle') {
        console.log(`🎯 [scene-render] SKIP regular pass for selected rectangle ${entity.id}`);
      }
      return;
    }
    
    // ✅ Skip hovered entities - they will render in the hover pass
    if (hoverId === entity.id) {
      if (entity.type === 'rectangle') {
        console.log(`🎯 [scene-render] SKIP regular pass for hovered rectangle ${entity.id}`);
      }
      return;
    }
    
    if (scene.layers[entity.layer]?.visible !== false) {
      entity.color = getLayerColor(entity.layer);
      
      // ✅ αν υπάρχει preview για αυτό το entity, το ζωγραφίζουμε με την "next" γεωμετρία
      const drawEntity = (previewOv && previewOv.entityId === entity.id)
        ? { ...entity, ...previewOv.next }
        : entity;
      
      if (entity.type === 'rectangle') {
        console.log(`🎯 [scene-render] Regular pass rendering rectangle ${entity.id}`);
      }
      entityRenderer.renderEntity(drawEntity, null, false); // authentic style, NO grips
    }
  });

  // ΝΕΟΣ ΚΩΔΙΚΑΣ: Render preview entity από drawingState
  if (options.drawingState?.previewEntity) {
    const previewEntity = options.drawingState.previewEntity;
    // Reduced spam: console.log('[scene-render] Rendering preview entity:', previewEntity.type);
    
    // 🎯 Let the 3-phase system handle preview styling (blue dashed with measurements)
    entityRenderer.renderEntity(previewEntity, null, false);
  }


  // ✅ 2) Selected pass (authentic + grips) with preview override support
  scene.entities.forEach(entity => {
    if (selectedIds.has(entity.id) && scene.layers[entity.layer]?.visible !== false) {
      // ✅ χρησιμοποίησε το drawEntity με τον ίδιο τρόπο για να μη «επιστρέφει»
      const drawEntity = (previewOv && previewOv.entityId === entity.id)
        ? { ...entity, ...previewOv.next }
        : entity;
      
      // ✅ Αν το selected entity είναι και hovered, περάσε '#FFFFFF' για hover effect
      const isHovered = hoverId === entity.id;
      const strokeOverride = isHovered ? '#FFFFFF' : null;
      
      if (entity.type === 'rectangle') {
        console.log(`🎯 [scene-render] Selected pass for rectangle ${entity.id}: isHovered=${isHovered}, strokeOverride=${strokeOverride}`);
      }
      
      entityRenderer.renderEntity(drawEntity, strokeOverride, true);  // authentic + grips, με hover αν χρειάζεται
    }
  });

  // ✅ 3) Hover pass (white dashed + grips) — μόνο αν το hovered δεν είναι ήδη selected
  if (hoverId && !selectedIds.has(hoverId)) {
    const hovered = scene.entities.find(e => e.id === hoverId);
    if (hovered && scene.layers[hovered.layer]?.visible !== false) {
      // ✅ χρησιμοποίησε το preview override και για το hover
      const drawEntity = (previewOv && previewOv.entityId === hovered.id)
        ? { ...hovered, ...previewOv.next }
        : hovered;
        
      entityRenderer.renderEntity(drawEntity, '#FFFFFF', true); // ✅ dashed + grips
    }
  }
  
  // ✅ 4) Marquee overlay (AutoCAD-style window/crossing selection)
  const marqueeOverlay = options.marqueeOverlayRef?.current;
  if (marqueeOverlay) {
    const a = marqueeOverlay.start, b = marqueeOverlay.end;
    const x = Math.min(a.x, b.x), y = Math.min(a.y, b.y);
    const w = Math.abs(a.x - b.x), h = Math.abs(a.y - b.y);
    const ltr = b.x >= a.x; // left-to-right → Window (inside only)

    ctx.save();
    ctx.lineWidth = 1;
    if (ltr) {
      // Window: Μπλε συμπαγές περίγραμμα
      ctx.strokeStyle = 'rgba(33,150,243,0.9)';
      ctx.fillStyle = 'rgba(33,150,243,0.15)';
      ctx.setLineDash([]); // solid
    } else {
      // Crossing: Πράσινο διακεκομμένο
      ctx.strokeStyle = 'rgba(76,175,80,0.9)';
      ctx.fillStyle = 'rgba(76,175,80,0.12)';
      ctx.setLineDash([8, 6]);
    }
    ctx.fillRect(x, y, w, h);
    ctx.strokeRect(x, y, w, h);
    ctx.restore();
  }
  
  // Measurements
  if (options.measurementRenderer) {
    options.measurementRenderer.setTransform(transformRef.current);
    
    if (options.measurements?.length > 0) {
      options.measurementRenderer.renderMeasurements(options.measurements, canvas.getBoundingClientRect());
    }

    if (options.tempMeasurementPoints?.length > 0 && options.mousePosition) {
      options.measurementRenderer.renderTemporaryMeasurement(
        options.tempMeasurementPoints, 
        options.mousePosition, 
        canvas.getBoundingClientRect()
      );
    }
  }

  drawRulers(ctx, canvas, transformRef.current);
  
  if (alwaysShowCoarseGrid) {
    drawGrid(ctx, canvas);
  }
  
}