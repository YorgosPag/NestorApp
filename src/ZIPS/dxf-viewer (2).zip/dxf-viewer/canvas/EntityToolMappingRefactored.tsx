'use client';

import React, { useEffect, useCallback } from 'react';
import { useGripContext } from '../contexts/GripContext';
import { drawingSystem } from '../systems/drawing';
import type { Point2D as Pt } from '../types/scene';
import type { MeasurementPoint } from '../systems/measurement';

// Centralized hooks
import {
  useDxfViewerState,
  useDrawingIntegration,
  useZoomIntegration,
  useLevelIntegration,
  useToolActions,
  useCanvasActions,
  useUIActions,
  useFileActions,
  useUnifiedActions
} from './components/dxf-viewer/hooks';

// Presentational components
import {
  DxfViewerToolbar,
  DxfViewerSidebar,
  DxfViewerCanvas
} from './components/dxf-viewer/components';

interface Props {
  className?: string;
  levels: any[];
  currentLevelId: string | null;
  getLevelScene: (levelId: string) => any;
  currentScene: any;
  setLevelScene: (levelId: string, scene: any) => void;
  // Snap functionality
  snapEnabled: boolean;
  enabledModes: Set<string>;
  applySnap: (point: Pt) => Pt;
  findSnapPoint: (x: number, y: number) => any;
}

export function DxfViewerContent({ 
  className, 
  levels, 
  currentLevelId, 
  getLevelScene, 
  currentScene,
  setLevelScene,
  // Snap functionality
  snapEnabled,
  enabledModes,
  applySnap,
  findSnapPoint
}: Props) {
  
  // ============================================================================
  // CENTRALIZED STATE MANAGEMENT
  // ============================================================================
  const {
    // Tool state
    activeTool,
    setActiveTool,
    // Canvas state
    dxfCanvasRef,
    overlayCanvasRef,
    canvasRef,
    currentZoom,
    setCurrentZoom,
    // UI state
    showGrid,
    setShowGrid,
    showLayers,
    setShowLayers,
    showProperties,
    setShowProperties,
    showCalibration,
    setShowCalibration,
    isZoomWindowActive,
    setIsZoomWindowActive,
    // Selection state
    selectedEntityIds,
    setSelectedEntityIds,
    // System state
    measurementRenderer,
    setMeasurementRenderer,
    canUndo,
    setCanUndo,
    canRedo,
    setCanRedo,
    // Helper functions
    resetAllState
  } = useDxfViewerState();

  // ============================================================================
  // SYSTEM INTEGRATION HOOKS
  // ============================================================================
  const isMeasurementTool = false; // No measurement system

  const { isDrawingTool, handleDrawingTool } = useDrawingIntegration({
    activeTool,
    onDrawingCancel: () => drawingSystem.cancelDrawing()
  });

  // 🚫 ΑΦΑΙΡΕΣΗ - useSnapIntegration (χρησιμοποιείται μόνο στο DxfCanvasRefactored)

  const { 
    zoomIn, 
    zoomOut, 
    fitToView, 
    setZoom, 
    activateZoomWindow, 
    deactivateZoomWindow 
  } = useZoomIntegration({
    dxfCanvasRef,
    currentScene,
    currentZoom,
    setCurrentZoom
  });

  const { allLevelsScene, createEnhancedCurrentScene } = useLevelIntegration({
    levels,
    currentLevelId: currentLevelId || '',
    selectedEntityIds,
    getLevelScene
  });

  // ============================================================================
  // ACTION HANDLER HOOKS
  // ============================================================================
  const { handleToolChange, handleZoomWindowModeChange } = useToolActions({
    activeTool,
    setActiveTool,
    setIsZoomWindowActive,
    onMeasurementCancel: () => {}, // No measurement system.cancelMeasurement(),
    onDrawingCancel: () => drawingSystem.cancelDrawing(),
    onZoomWindowActivate: activateZoomWindow,
    onZoomWindowDeactivate: deactivateZoomWindow
  });

  const { handleUndo, handleRedo, updateUndoRedoState } = useCanvasActions({
    dxfCanvasRef,
    canUndo,
    canRedo,
    setCanUndo,
    setCanRedo
  });

  const { toggleGrid, toggleLayers, toggleProperties, toggleCalibration } = useUIActions({
    showGrid,
    showLayers,
    showProperties,
    showCalibration,
    setShowGrid,
    setShowLayers,
    setShowProperties,
    setShowCalibration
  });

  const { handleSceneImported, handleSceneChange } = useFileActions({
    currentLevelId,
    dxfCanvasRef,
    setLevelScene,
    updateUndoRedoState
  });

  const { handleAction } = useUnifiedActions({
    zoomIn,
    zoomOut,
    fitToView,
    setZoom,
    toggleGrid,
    toggleLayers,
    toggleProperties,
    toggleCalibration,
    handleUndo,
    handleRedo,
    handleToolChange
  });

  // ============================================================================
  // DERIVED STATE
  // ============================================================================
  const enhancedCurrentScene = createEnhancedCurrentScene(currentScene);

  // ============================================================================
  // GRIP SETTINGS from Context
  // ============================================================================
  const { gripSettings } = useGripContext();

  // ============================================================================
  // UPDATE UNDO/REDO STATE
  // ============================================================================
  useEffect(() => {
    updateUndoRedoState();
  }, [currentScene, selectedEntityIds, updateUndoRedoState]);

  // ============================================================================
  // MEASUREMENT HANDLERS
  // ============================================================================
  const onMeasurementPoint = useCallback((p: Pt) => {
    console.log('📏 Measurement point requested:', p);
    const snappedPoint = applySnap(p);
    // No measurement system.addPoint({ position: { x: 0, y: 0 }, worldPosition: snappedPoint } as MeasurementPoint);
    
    console.log('[EntityToolMapping] 🎯 DISPATCHING canvas-click event for measurement tool');
    window.dispatchEvent(new CustomEvent('canvas-click'));
  }, [applySnap]);
  
  const onMeasurementHover = useCallback((p: Pt | null) => {
    // Logic for hover is handled internally by the measurement system hook
  }, []);

  const onMeasurementCancel = useCallback(() => {
    // No measurement system.cancelMeasurement();
  }, []);

  // ============================================================================
  // DRAWING HANDLERS
  // ============================================================================
  const onDrawingPoint = useCallback((p: Pt) => {
    console.log('🎨 Drawing point requested:', p);
    const snappedPoint = applySnap(p);
    const transform = dxfCanvasRef.current?.getTransform() || { scale: 1, offsetX: 0, offsetY: 0 };
    drawingSystem.addPoint(snappedPoint, transform);
    console.log('🎨 Drawing point added (snapped):', snappedPoint, 'from:', p);
  }, [applySnap, dxfCanvasRef]);
  
  const onDrawingHover = useCallback((p: Pt | null) => {
    if (p) {
      const transform = dxfCanvasRef.current?.getTransform() || { scale: 1, offsetX: 0, offsetY: 0 };
      drawingSystem.updatePreview(p, transform);
    }
  }, [dxfCanvasRef]);

  const onDrawingCancel = useCallback(() => {
    drawingSystem.cancelDrawing();
    setActiveTool('select');
  }, [setActiveTool]);

  const onDrawingDoubleClick = useCallback(() => {
    if (activeTool === 'polyline' || activeTool === 'measure-angle') {
      drawingSystem.finishPolyline();
      setActiveTool('select');
    }
  }, [activeTool, setActiveTool]);

  // ============================================================================
  // UNIFIED CANVAS DOUBLE CLICK
  // ============================================================================
  const onCanvasDoubleClick = useCallback(() => {
    if (activeTool === 'polyline' || activeTool === 'measure-angle' || activeTool === 'polygon' || activeTool === 'measure-area') {
      onDrawingDoubleClick();
    }
  }, [activeTool, onDrawingDoubleClick]);

  // ============================================================================
  // ADDITIONAL HANDLERS
  // ============================================================================
  const handleTransformChange = useCallback((transform: any) => {
    if (transform?.scale && typeof transform.scale === 'number') {
      setCurrentZoom(transform.scale);
    }
  }, [setCurrentZoom]);

  const handleCalibrationToggle = useCallback((show: boolean) => {
    setShowCalibration(show);
  }, [setShowCalibration]);

  return (
    <div className={`flex flex-col h-full bg-gray-900 ${className || ''}`} onDoubleClick={onCanvasDoubleClick}>
      
      {/* ============================================================================ */}
      {/* TOOLBAR SECTION */}
      {/* ============================================================================ */}
      <DxfViewerToolbar
        activeTool={activeTool}
        onToolChange={handleToolChange}
        onAction={handleAction}
        showGrid={showGrid}
        canUndo={canUndo}
        canRedo={canRedo}
        snapEnabled={snapEnabled}
        showLayers={showLayers}
        showProperties={showProperties}
        showCalibration={showCalibration}
        currentZoom={currentZoom}
        onSceneImported={handleSceneImported}
      />

      {/* ============================================================================ */}
      {/* MAIN CONTENT SECTION */}
      {/* ============================================================================ */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* SIDEBAR */}
        <DxfViewerSidebar
          sceneModel={allLevelsScene}
          selectedEntityIds={selectedEntityIds}
          onEntitySelect={setSelectedEntityIds}
          zoomLevel={currentZoom}
          currentTool={activeTool}
        />

        {/* CANVAS AREA */}
        <DxfViewerCanvas
          dxfCanvasRef={dxfCanvasRef}
          enhancedCurrentScene={enhancedCurrentScene}
          selectedEntityIds={selectedEntityIds}
          onSelectEntity={(entityIds) => {
            console.log('🎯 [EntityToolMapping] onSelectEntity called with:', entityIds, 'activeTool:', activeTool);
            setSelectedEntityIds(Array.isArray(entityIds) ? entityIds : [entityIds]);
          }}
          onTransformChange={handleTransformChange}
          activeTool={activeTool}
          isZoomWindowActive={isZoomWindowActive}
          showCalibration={showCalibration}
          onZoomWindowModeChange={handleZoomWindowModeChange}
          onCalibrationToggle={handleCalibrationToggle}
          onSceneChange={handleSceneChange}
          measurements={[]} // Object.values(// No measurement system.measurements)
          tempMeasurementPoints={[]} // // No measurement system.tempPoints.map(p => p.worldPosition)
          onMeasurementPoint={onMeasurementPoint}
          onMeasurementHover={onMeasurementHover}
          onMeasurementCancel={onMeasurementCancel}
          onDrawingPoint={onDrawingPoint}
          onDrawingHover={onDrawingHover}
          onDrawingCancel={onDrawingCancel}
          onDrawingDoubleClick={onDrawingDoubleClick}
          snapEnabled={snapEnabled}
          enabledSnapModes={Array.from(enabledModes)}
          onSnapPoint={findSnapPoint}
          gripSettings={gripSettings}
        />
      </div>
    </div>
  );
}

export default DxfViewerContent;