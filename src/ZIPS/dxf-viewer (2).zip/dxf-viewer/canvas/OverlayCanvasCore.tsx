'use client';
import React, { useRef, useEffect, useCallback, useState } from 'react';
import { OverlayRenderer } from './overlay-renderer';
import { useGripContext } from '../providers/GripProvider';
import { useGripInteraction } from './interaction/useGripInteraction';
import { coordTransforms } from '../config/unified-grid-configuration';
import { USE_UNIFIED_DRAWING_ENGINE } from '../config/featureFlags';
import type { ViewTransform } from '../config/unified-grid-configuration';
import type { Region, RegionStatus, Point2D } from '../types/overlay';

interface OverlayCanvasCoreProps {
  transform: ViewTransform;
  visibleRegions: Region[];
  selectedRegionIds: string[];
  isDrawing: boolean;
  drawingVertices: Point2D[];
  drawingStatus: RegionStatus;
  showHandles: boolean;
  showLabels: boolean;
  editingRegionId: string | null;
  mousePosition: { x: number; y: number } | null;
  className?: string;
  onRendererReady: (renderer: OverlayRenderer) => void;
  onMouseDown: (e: React.MouseEvent) => void;
  onMouseMove: (e: React.MouseEvent) => void;
  onMouseUp: (e: React.MouseEvent) => void;
  onMouseLeave: () => void;
  onContextMenu: (e: React.MouseEvent) => void;
  onRegionClick?: (regionId: string) => void;
}

export function OverlayCanvasCore({
  transform,
  visibleRegions,
  selectedRegionIds,
  isDrawing,
  drawingVertices,
  drawingStatus,
  showHandles,
  showLabels,
  editingRegionId,
  mousePosition,
  className,
  onRendererReady,
  onMouseDown,
  onMouseMove,
  onMouseUp,
  onMouseLeave,
  onContextMenu,
  onRegionClick
}: OverlayCanvasCoreProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const rendererRef = useRef<OverlayRenderer | null>(null);
  const animationFrameRef = useRef<number>();

  // === GRIP SETTINGS INTEGRATION (καθαρή) ===
  const { gripSettings } = useGripContext();
  
  // === CURSOR STATE FOR GRIP HOVER ===
  const [cursor, setCursor] = useState<string>('crosshair');
  
  // === GRIP INTERACTION STATE ===
  const [gripInteractionState, setGripInteractionState] = useState<{
    hovered?: { entityId: string; gripIndex: number };
    active?: { entityId: string; gripIndex: number };
  }>({});
  
  // === SELECTED REGIONS STATE FOR GRIP INTERACTION ===
  const selectedIdsRef = useRef<Set<string>>(new Set(selectedRegionIds));
  
  // Update selected regions ref when props change
  useEffect(() => {
    selectedIdsRef.current = new Set(selectedRegionIds);
  }, [selectedRegionIds]);
  
  // Debug (μόνο σε development)
  const DEBUG = process.env.NODE_ENV !== 'production';

  // === CREATE MOCK SCENE FOR GRIP INTERACTION ===
  const mockScene = useCallback(() => {
    if (!visibleRegions?.length) return null;
    
    // Convert regions to polygon entities for grip interaction
    const entities = visibleRegions.map(region => {
      if (region.vertices?.length >= 2) {
        return {
          id: region.id,
          type: 'polygon',
          vertices: region.vertices,
        };
      }
      return null;
    }).filter(Boolean);

    return { entities };
  }, [visibleRegions]);

  // === GRIP INTERACTION SETUP ===
  const transformRef = useRef(transform);
  transformRef.current = transform;

  // Mock functions for grip interaction  
  const renderMock = useCallback((scene: any) => {
    // Trigger a re-render of the overlay
    const renderer = rendererRef.current;
    if (!renderer) return;
    
    renderer.renderOverlay(visibleRegions, transform, {
      showHandles,
      showLabels,
      selectedRegionIds,
      isDrawing,
      drawingVertices,
      drawingStatus,
      editingRegionId,
      mousePosition,
      gripSettings,
      gripInteractionState // === ΝΕΟ: ΠΡΟΣΘΕΣΑ GRIP STATE ===
    });
  }, [visibleRegions, transform, showHandles, showLabels, selectedRegionIds, 
      isDrawing, drawingVertices, drawingStatus, editingRegionId, mousePosition, gripSettings, gripInteractionState]);

  const setPreviewOverride = useCallback((preview: any) => {
    // For now, we'll just ignore preview overrides in overlay canvas
    // This could be extended to show grip drag previews
  }, []);

  const onCommitLine = useCallback((entityId: string, next: { start?: Point2D; end?: Point2D; vertices?: Point2D[] }) => {
    console.log('🎯 [OverlayCanvas] Committing grip changes for region:', entityId, next);
    
    // Find the region to update
    const region = visibleRegions.find(r => r.id === entityId);
    if (!region) {
      console.warn('Region not found for grip update:', entityId);
      return;
    }

    // Update region vertices based on grip changes
    if (next.vertices) {
      // For polygon regions - update vertices directly
      console.log('🎯 Updating region vertices from', region.vertices.length, 'to', next.vertices.length);
      // TODO: Call parent callback to update region in store
      // For now, just log the change
      console.log('🎯 New vertices:', next.vertices);
    } else if (next.start && next.end) {
      // For line-based regions - convert back to vertices
      const newVertices = [next.start, next.end];
      console.log('🎯 Updating region from line grips:', newVertices);
    }
  }, [visibleRegions]);

  // === REGION HIT TESTING ===
  const findRegionUnderCursor = useCallback((screenPt: Point2D) => {
    if (!visibleRegions?.length) return null;
    
    // Convert screen point to world coordinates using OVERLAY coordinate system (not UGS)
    // This ensures overlays stay in same position when switching between draw/edit modes
    const worldPt = {
      x: (screenPt.x - transform.offsetX) / transform.scale,
      y: (screenPt.y - transform.offsetY) / transform.scale
    };
    
    // Check each region to see if point is inside
    for (const region of visibleRegions) {
      if (region.vertices?.length >= 3) {
        // Point-in-polygon test
        if (isPointInPolygon(worldPt, region.vertices)) {
          return region;
        }
      }
    }
    return null;
  }, [visibleRegions, transform]);

  // Point in polygon helper function
  const isPointInPolygon = useCallback((point: Point2D, vertices: Point2D[]) => {
    let inside = false;
    for (let i = 0, j = vertices.length - 1; i < vertices.length; j = i++) {
      const xi = vertices[i].x, yi = vertices[i].y;
      const xj = vertices[j].x, yj = vertices[j].y;
      
      if (((yi > point.y) !== (yj > point.y)) &&
          (point.x < (xj - xi) * (point.y - yi) / (yj - yi) + xi)) {
        inside = !inside;
      }
    }
    return inside;
  }, []);

  // === MOCK ENTITY RENDERER FOR GRIP INTERACTION ===
  const mockEntityRenderer = useRef({
    setGripInteractionState: (state: any) => {
      console.log('🎯 [OverlayCanvas] Setting grip interaction state:', state);
      setGripInteractionState(state || {});
    }
  });

  // Initialize grip interaction
  const gripInteraction = useGripInteraction({
    scene: mockScene(),
    selectedIdsRef,
    transformRef,
    canvasRef,
    entityRendererRef: mockEntityRenderer,
    render: renderMock,
    gripSettings,
    setPreviewOverride,
    onCommitLine,
    setCursor,
  });

  // === ENHANCED MOUSE HANDLERS WITH GRIP SUPPORT ===
  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    // 🚫 Prevent legacy overlay loop when unified engine is drawing
    if (USE_UNIFIED_DRAWING_ENGINE() && isDrawing) {
      return;
    }
    
    console.log('🔍 [OverlayCanvasCore] handleMouseMove called - LAYER SYSTEM IS ACTIVE');
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const screenPt = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };

    // Check for grip hover first (higher priority)
    const gripHandled = gripInteraction.onMouseMoveGrip(screenPt);
    
    if (gripInteraction.isDraggingRef.current) {
      gripInteraction.onMouseMoveDrag(screenPt);
    } else if (!gripHandled) {
      // Check for region hover (for white dashed border effect)
      const hoveredRegion = findRegionUnderCursor(screenPt);
      
      if (hoveredRegion) {
        console.log('🎯 [OverlayCanvas] Region hovered:', hoveredRegion.id);
        setGripInteractionState({
          hovered: { entityId: hoveredRegion.id, gripIndex: -1 }
        });
        setCursor('pointer');
      } else {
        setGripInteractionState({});
        setCursor('crosshair');
      }
      
      // Call original mouse move handler
      onMouseMove(e);
    }
  }, [onMouseMove, gripInteraction, findRegionUnderCursor, isDrawing]);

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    // 🚫 Prevent legacy overlay loop when unified engine is drawing
    if (USE_UNIFIED_DRAWING_ENGINE() && isDrawing) {
      return;
    }
    
    const rect = canvasRef.current?.getBoundingClientRect();
    if (!rect) return;

    const screenPt = {
      x: e.clientX - rect.left,
      y: e.clientY - rect.top
    };

    // Check for grip click first (higher priority)
    const gripHandled = gripInteraction.onMouseDownGrip(screenPt);
    
    if (!gripHandled) {
      // Call original mouse down handler
      onMouseDown(e);
    }
  }, [onMouseDown, gripInteraction, isDrawing]);

  const handleMouseUp = useCallback((e: React.MouseEvent) => {
    if (gripInteraction.isDraggingRef.current) {
      gripInteraction.onMouseUpDrag();
    } else {
      // Check for region click if onRegionClick is provided
      if (onRegionClick) {
        const rect = canvasRef.current?.getBoundingClientRect();
        if (rect) {
          const screenPt = {
            x: e.clientX - rect.left,
            y: e.clientY - rect.top
          };
          const hitRegion = findRegionUnderCursor(screenPt);
          if (hitRegion) {
            onRegionClick(hitRegion.id);
            return; // Don't call original handler if region was clicked
          }
        }
      }
      
      // Call original mouse up handler
      onMouseUp(e);
    }
  }, [onMouseUp, gripInteraction, onRegionClick, findRegionUnderCursor]);

  const renderOverlay = useCallback(() => {
    const renderer = rendererRef.current;
    if (!renderer) return;
    
    // === GUARD: Prevent double preview when unified engine is enabled and in draw mode ===
    if (USE_UNIFIED_DRAWING_ENGINE() && isDrawing) {
      // αφήνουμε ΟΛΟ το preview στο DXF tool (rubber-band)
      console.log('🚫 [OverlayCanvasCore] Skipping preview - unified engine handles drawing');
      return;
    }
    
    // Clean debug log (όχι spam)
    if (DEBUG) {
      console.log('🎨 [OverlayCanvasCore] RAF render triggered');
    }
    
    // === PASS GRIP SETTINGS TO RENDERER ===
    renderer.renderOverlay(visibleRegions, transform, {
      showHandles,
      showLabels,
      selectedRegionIds,
      isDrawing,
      drawingVertices,
      drawingStatus,
      editingRegionId,
      mousePosition: isDrawing ? mousePosition || undefined : undefined
    }, gripSettings);
  }, [
    visibleRegions, transform, showHandles, showLabels, selectedRegionIds,
    isDrawing, drawingVertices, drawingStatus, editingRegionId, mousePosition,
    gripSettings, DEBUG
  ]);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    rendererRef.current = new OverlayRenderer(canvas);
    onRendererReady(rendererRef.current);
    
    const resize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      const ctx = canvas.getContext('2d');
      if (ctx) ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
      
      // Trigger render after resize
      requestAnimationFrame(renderOverlay);
    };
    
    resize();
    window.addEventListener('resize', resize);
    return () => window.removeEventListener('resize', resize);
  }, [onRendererReady, renderOverlay]);

  // === OPTIMIZED: RAF render on grip settings change ===
  useEffect(() => {
    // Cancel previous frame
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    
    // Schedule new render
    animationFrameRef.current = requestAnimationFrame(renderOverlay);
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [renderOverlay]);

  return (
    <div className={`relative w-full h-full ${className || ''}`}>
      
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-auto"
        style={{ zIndex: 10, cursor }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={onMouseLeave}
        onContextMenu={onContextMenu}
      />
      
      {/* Debug overlay (μόνο development) */}
      {DEBUG && (
        <div className="absolute top-2 right-2 text-xs text-white bg-black bg-opacity-75 p-2 rounded">
          <div>Regions: {visibleRegions.length}</div>
          <div>GripSize: {gripSettings.gripSize}</div>
          <div>Handles: {showHandles ? 'ON' : 'OFF'}</div>
        </div>
      )}
    </div>
  );
}
