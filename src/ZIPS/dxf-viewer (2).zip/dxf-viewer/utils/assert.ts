// src/subapps/dxf-viewer/utils/assert.ts
export function assert(condition: any, message?: string): asserts condition {
  if (!condition) {
    throw new Error(message || 'Assertion failed');
  }
}