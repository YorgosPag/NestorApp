/**
 * Dot Rendering Utilities
 * Shared utilities for rendering dots/markers on entities
 */

import type { Point2D } from '../../../systems/coordinates/config';

/**
 * Render a single dot at given point
 */
export function renderDotAtPoint(
  ctx: CanvasRenderingContext2D,
  worldToScreen: (point: Point2D) => Point2D,
  point: Point2D,
  radius = 4
): void {
  const screenPoint = worldToScreen(point);
  ctx.beginPath();
  ctx.arc(screenPoint.x, screenPoint.y, radius, 0, Math.PI * 2);
  ctx.fill();
}

/**
 * Render multiple dots at given points
 */
export function renderDotsAtPoints(
  ctx: CanvasRenderingContext2D,
  worldToScreen: (point: Point2D) => Point2D,
  points: Point2D[],
  radius = 4
): void {
  points.forEach(point => {
    renderDotAtPoint(ctx, worldToScreen, point, radius);
  });
}