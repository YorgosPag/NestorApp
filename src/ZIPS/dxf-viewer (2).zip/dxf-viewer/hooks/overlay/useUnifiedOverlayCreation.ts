/**
 * Unified Overlay Creation Hook
 * Χρησιμοποιεί το DXF polyline tool για τη δημιουργία overlay polygon,
 * ώστε η εμπειρία να είναι 1:1 με τα DXF tools (rubber-band, snaps, dynamic input).
 */
import { useCallback } from 'react';
import { USE_UNIFIED_DRAWING_ENGINE } from '../../config/featureFlags';
import { toolStyleStore } from '../../stores/ToolStyleStore';
import { useOverlayStore } from '../../overlays/overlay-store';
import { useUnifiedDrawing } from '../drawing/useUnifiedDrawing';
// DISABLED: Legacy Grips import - using Unified Grips System instead
// import { Grips } from '../../grips/Grips';

type StartOpts = {
  onComplete?: (overlayId: string) => void;
  onCancel?: () => void;
};

export function useUnifiedOverlayCreation() {
  const { add } = useOverlayStore();
  const { startPolyline } = useUnifiedDrawing();

  const startOverlayCreation = useCallback(async (opts: StartOpts) => {
    if (!USE_UNIFIED_DRAWING_ENGINE()) return;

    const stop = startPolyline({
      onComplete: async (points) => {
        const style = toolStyleStore.get();
        // Δημιουργία overlay entity με το ΙΔΙΟ style (όχι legacy palette)
        const overlayId = await add({
          levelId: '', // will be set by overlay store based on currentLevelId
          kind: 'unit', // default, could be made configurable
          polygon: points.map(p => [p.x, p.y] as [number, number]),
          status: 'for-sale', // default, could be made configurable
          style: {
            stroke: style.strokeColor,
            fill: style.fillColor,
            lineWidth: style.lineWidth,
            opacity: style.opacity,
          }
        });
        // Συνδέουμε ΤΟ ΙΔΙΟ grips system μετά το commit
        // DISABLED: Legacy Grips - using Unified Grips System instead
        // Grips.attachTo(overlayId, 'overlay');
        opts.onComplete?.(overlayId);
      },
      onCancel: () => {
        opts.onCancel?.();
      }
    });

    return stop; // αν χρειαστεί cancel από έξω
  }, [add, startPolyline]);

  return { startOverlayCreation, isUsingUnifiedEngine: USE_UNIFIED_DRAWING_ENGINE() };
}