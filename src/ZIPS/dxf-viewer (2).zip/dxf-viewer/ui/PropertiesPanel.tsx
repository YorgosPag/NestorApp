'use client';

import React from 'react';
import { Info, Layers, FileText, Mouse } from 'lucide-react';
import { SceneInfoSection, EntityTypesSection } from './components/SceneInfoSection';
import { LayersSection } from './components/LayersSection';
import type { SceneModel } from '../types/scene';
import type { OverlayRegion } from '../types/overlay';

interface PropertiesPanelProps {
  scene: SceneModel | null;
  selectedEntity: any | null;
  selectedRegions: OverlayRegion[];
  selectedEntityIds?: string[];
  onEntitySelectionChange?: (entityIds: string[]) => void;
  onLayerToggle?: (layerName: string, visible: boolean) => void;
  // Entity operations
  onEntityToggle?: (entityId: string, visible: boolean) => void;
  onEntityDelete?: (entityId: string) => void;
  onEntityColorChange?: (entityId: string, color: string) => void;
  onEntityRename?: (entityId: string, newName: string) => void;
  // Color Group operations
  onColorGroupToggle?: (colorGroupName: string, layersInGroup: string[], visible: boolean) => void;
  onColorGroupDelete?: (colorGroupName: string, layersInGroup: string[]) => void;
  onColorGroupColorChange?: (colorGroupName: string, layersInGroup: string[], color: string) => void;
  onColorGroupRename?: (oldColorGroupName: string, newColorGroupName: string, layersInGroup: string[]) => void;
}

export function PropertiesPanel({ 
  scene, 
  selectedEntity, 
  selectedRegions,
  selectedEntityIds = [],
  onEntitySelectionChange,
  onLayerToggle,
  onEntityToggle,
  onEntityDelete,
  onEntityColorChange,
  onEntityRename,
  onColorGroupToggle,
  onColorGroupDelete,
  onColorGroupColorChange,
  onColorGroupRename
}: PropertiesPanelProps) {
  const renderSelectionDetails = () => {
    if (selectedEntity) {
      return (
        <div className="space-y-2 text-sm bg-gray-700 p-3 rounded">
          <div className="flex justify-between">
            <span className="text-gray-400">Τύπος:</span>
            <span className="text-white font-medium">{selectedEntity.type}</span>
          </div>
          {selectedEntity.layer && (
            <div className="flex justify-between">
              <span className="text-gray-400">Επίπεδο:</span>
              <span className="text-white font-medium">{selectedEntity.layer}</span>
            </div>
          )}
        </div>
      );
    }

    if (selectedEntityIds.length > 0) {
      return (
        <div className="text-center py-4 bg-yellow-900 bg-opacity-20 border border-yellow-700 rounded">
          <Layers className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
          <p className="text-sm text-yellow-300 font-medium">
            {selectedEntityIds.length} στοιχεία επιλεγμένα
          </p>
          <p className="text-xs text-yellow-400 mt-1">
            Επιλογή ανά επίπεδο ενεργή
          </p>
        </div>
      );
    }

    if (!scene) {
      return (
        <div className="text-center py-4">
          <Mouse className="w-8 h-8 text-gray-600 mx-auto mb-2" />
          <p className="text-gray-400 mb-2">Κάντε κλικ για τοποθέτηση πρώτης κορυφής</p>
          <p className="text-xs text-gray-500">Εισάγετε ένα DXF αρχείο για να δείτε πληροφορίες</p>
        </div>
      );
    }

    return (
      <div className="text-center py-4">
        <FileText className="w-8 h-8 text-gray-600 mx-auto mb-2" />
        <p className="text-sm text-gray-400">Δεν επιλέχθηκε στοιχείο</p>
        <p className="text-xs text-gray-500 mt-1">
          Κάντε κλικ σε επίπεδο ή οντότητα για επιλογή
        </p>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col bg-gray-800">
      {/* Header */}
      <div className="flex items-center gap-2 p-4 border-b border-gray-700">
        <Info className="w-5 h-5 text-gray-400" />
        <h2 className="text-lg font-semibold text-white">Πληροφορίες Σκηνής</h2>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 p-4">
        {/* Scene Information */}
        <SceneInfoSection 
          scene={scene} 
          selectedEntityIds={selectedEntityIds} 
        />

        {/* Layers Management */}
        <LayersSection
          scene={scene}
          selectedEntityIds={selectedEntityIds}
          onEntitySelectionChange={onEntitySelectionChange}
          onLayerToggle={onLayerToggle}
          onEntityToggle={onEntityToggle}
          onEntityDelete={onEntityDelete}
          onEntityColorChange={onEntityColorChange}
          onEntityRename={onEntityRename}
          onColorGroupToggle={onColorGroupToggle}
          onColorGroupDelete={onColorGroupDelete}
          onColorGroupColorChange={onColorGroupColorChange}
          onColorGroupRename={onColorGroupRename}
        />

        {/* Entity Types Summary */}
        <EntityTypesSection 
          scene={scene} 
          selectedEntityIds={selectedEntityIds} 
        />

        {/* Selection Details */}
        <div className="space-y-3">
          <h3 className="text-sm font-medium text-orange-400">Λεπτομέρειες Επιλογής</h3>
          {renderSelectionDetails()}
        </div>
      </div>
    </div>
  );
}
