/**
 * CAD UI Configuration
 * Central point for managing AutoCAD-like UI element styles and sizes.
 */
export const CAD_UI = {
  // Grips configuration (for vertices, midpoints, etc.)
  grips: {
    size_px: 6,
    color_unselected: '#0080ff', // Blue for unselected grips
    color_selected: '#ff0000',   // Red for selected grips
    color_hot: '#ff8000',        // Orange for hovered grips (hot)
    outline_color: '#ffffff',
    outline_width: 1,
    // Modern grip colors for consistency with entity state system
    cold: '#0080ff',     // Blue for unselected grips
    warm: '#ff8000',     // Orange for hovered grips
    hot: '#ff0000',      // Red for selected/active grips
  },
  
  // Entity configuration (for lines, circles, etc.)
  entity: {
    default: '#ffffff',    // White for normal entities
    hover: '#ffffff',      // White for hovered entities (with dashed line)
    selected: '#ffffff',   // White for selected entities
    preview: '#00ff00',    // Green for preview/drawing entities
  },
  
  // Pickbox configuration (the square in the middle of the cursor)
  pickbox: {
    size_px: 6,
    color: 'transparent',
    outline_color: '#ffffff',
    outline_width: 1,
  },
  
  // Crosshair configuration (the lines extending from the cursor)
  cursor: {
    // This part is now managed in cursor-configuration.ts
    // Kept here for reference, but values should be synced from the other file.
  }
};
