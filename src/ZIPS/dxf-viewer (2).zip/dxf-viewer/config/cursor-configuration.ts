/**
 * CURSOR CONFIGURATION - LEGACY COMPATIBILITY
 * @deprecated This file provides backward compatibility for existing imports.
 * New code should import from '../systems/cursor/config'
 * This file will be removed in v2.0.0
 */

// Re-export everything from the new cursor system
export * from '../systems/cursor/config';

// Import for direct compatibility
import {
  CursorConfiguration as NewCursorConfiguration,
  cursorConfig as newCursorConfig,
  getCursorSettings as newGetCursorSettings,
  updateCursorSettings as newUpdateCursorSettings,
  subscribeToCursorSettings as newSubscribeToCursorSettings
} from '../systems/cursor/config';

// Export with same names for compatibility
export const CursorConfiguration = NewCursorConfiguration;
export const cursorConfig = newCursorConfig;
export const getCursorSettings = newGetCursorSettings;
export const updateCursorSettings = newUpdateCursorSettings;
export const subscribeToCursorSettings = newSubscribeToCursorSettings;

// Legacy compatibility exports
export { CursorConfiguration as CAD_UI_CURSOR };