'use client';
import React from 'react';
import type { DxfCanvasRef } from '../canvas/DxfCanvas';
import { useDxfViewerState } from '../hooks/useDxfViewerState';
import type { DxfViewerAppProps } from '../types';
import type { SceneModel } from '../types/scene';

// Import Layout Components
import { FloatingPanelContainer, type FloatingPanelHandle } from '../ui/FloatingPanelContainer';
import { EnhancedDXFToolbar } from '../ui/toolbar';
import { OverlayToolbar } from '../ui/OverlayToolbar';
import { DxfCanvas } from '../canvas/DxfCanvas';
import { OverlayCanvasCore } from '../canvas/OverlayCanvasCore';
import { useOverlayStore } from '../overlays/overlay-store';
import { overlaysToRegions } from '../overlays/overlay-adapter';
import { useLevelManager } from '../systems/levels/useLevels';
import { useGripContext } from '../providers/GripProvider';
import { ColorPickerModal } from '../ui/components/layers/components/ColorPickerModal';
import CursorSettingsPanel from '../ui/CursorSettingsPanel';
import { useCursor } from '../systems/cursor';
import type { OverlayEditorMode, OverlayKind, Status } from '../overlays/types';

// Component that uses cursor context and renders toolbar with coordinates
export function ToolbarWithCursorCoordinates(props: any) {
  const { worldPosition, settings } = useCursor();
  
  return (
    <EnhancedDXFToolbar
      {...props}
      mouseCoordinates={worldPosition}
      showCoordinates={settings.behavior.coordinate_display}
    />
  );
}

export function DxfViewerContent(props: DxfViewerAppProps) {
  const dxfCanvasRef = React.useRef<DxfCanvasRef>(null);
  const floatingRef = React.useRef<FloatingPanelHandle>(null);
  const state = useDxfViewerState(dxfCanvasRef);
  
  // Status labels in English for Firestore
  const STATUS_ENGLISH_LABELS: Record<Status, string> = {
    'for-sale': 'For Sale',
    'for-rent': 'For Rent',
    'reserved': 'Reserved',
    'sold': 'Sold',
    'landowner': 'Landowner'
  };

  // Add state for overlay toolbar
  const [overlayMode, setOverlayMode] = React.useState<OverlayEditorMode>('draw');
  
  const [overlayStatus, setOverlayStatus] = React.useState<Status>('for-sale');
  const [overlayKind, setOverlayKind] = React.useState<OverlayKind>('unit');
  
  // Add draft polygon state for overlay drawing
  const [draftPolygon, setDraftPolygon] = React.useState<Array<[number, number]>>([]);
  
  // Add canvas transform state for overlay layer
  const [canvasTransform, setCanvasTransform] = React.useState({ scale: 1, offsetX: 0, offsetY: 0 });
  
  // Drawing constants
  const SNAP_TOLERANCE = 10; // pixels
  const MIN_POLY_POINTS = 3; // Minimum points for polygon
  
  // State για color menu popover
  const [colorMenu, setColorMenu] = React.useState<{open:boolean; x:number; y:number; ids:string[]}>({
    open: false, x: 0, y: 0, ids: []
  });
  const {
    activeTool,
    handleToolChange,
    handleAction,
    showGrid,
    canUndo,
    canRedo,
    snapEnabled,
    showLayers,
    showProperties,
    showCalibration,
    showCursorSettings,
    currentZoom,
    handleFileImport,
    currentScene,
    selectedEntityIds,
    setSelectedEntityIds,
    handleTransformChange,
    handleSceneChange,
    handleCalibrationToggle,
        drawingState,
    onMeasurementPoint,
    onMeasurementHover,
    onMeasurementCancel,
    onDrawingPoint,
    onDrawingHover,
    onDrawingCancel,
    onDrawingDoubleClick,
    onEntityCreated,
    gripSettings
  } = state;

  // Get overlay store and level manager
  const overlayStore = useOverlayStore();
  const levelManager = useLevelManager();
  
  // Get grip context for manual control
  const { updateGripSettings } = useGripContext();

  // Initialize canvasTransform from the canvas when it's ready
  React.useEffect(() => {
    if (dxfCanvasRef.current) {
      const initialTransform = dxfCanvasRef.current.getTransform();
      setCanvasTransform({
        scale: initialTransform.scale || 1,
        offsetX: initialTransform.offsetX || 0,
        offsetY: initialTransform.offsetY || 0,
      });
    }
  }, [dxfCanvasRef.current, currentScene]);

  // Periodically sync transform from canvas (workaround for missing callbacks)
  React.useEffect(() => {
    if (!dxfCanvasRef.current || activeTool !== 'layering') return;
    
    const syncTransform = () => {
      if (dxfCanvasRef.current) {
        const currentTransform = dxfCanvasRef.current.getTransform();
        setCanvasTransform(prev => {
          // Only update if values changed significantly
          if (Math.abs(prev.scale - currentTransform.scale) > 0.001 || 
              Math.abs(prev.offsetX - currentTransform.offsetX) > 1 ||
              Math.abs(prev.offsetY - currentTransform.offsetY) > 1) {
            return {
              scale: currentTransform.scale || 1,
              offsetX: currentTransform.offsetX || 0,
              offsetY: currentTransform.offsetY || 0,
            };
          }
          return prev;
        });
      }
    };
    
    // Sync every 100ms when layering tool is active
    const interval = setInterval(syncTransform, 100);
    return () => clearInterval(interval);
  }, [activeTool]);

  // Wrap handleTransformChange to also update canvasTransform state
  const wrappedHandleTransformChange = React.useCallback((transform: any) => {
    // Update the canvas transform state for OverlayLayer
    setCanvasTransform({
      scale: transform.scale || 1,
      offsetX: transform.offsetX || 0,
      offsetY: transform.offsetY || 0,
    });
    
    // Call the original handler
    handleTransformChange(transform);
  }, [handleTransformChange, setCanvasTransform]);

  // Canvas click handler for overlay drawing (moved after state destructuring)
  const handleOverlayCanvasClick = React.useCallback((point: { x: number; y: number }) => {
    if (overlayMode !== 'draw' || !activeTool || activeTool !== 'layering') return;
    
    
    // Check if point is close to first point (closing polygon)
    if (draftPolygon.length >= MIN_POLY_POINTS) {
      const firstPoint = draftPolygon[0];
      const distance = Math.sqrt(
        Math.pow(point.x - firstPoint[0], 2) + Math.pow(point.y - firstPoint[1], 2)
      );
      
      if (distance < SNAP_TOLERANCE) {
        finishDrawing();
        return;
      }
    }

    // Add new point to draft polygon
    setDraftPolygon(prev => [...prev, [point.x, point.y]]);
  }, [overlayMode, activeTool, draftPolygon]);
  
  // Finish drawing function (moved after state destructuring)
  const finishDrawing = React.useCallback(async () => {
    if (draftPolygon.length < MIN_POLY_POINTS) {
      console.warn('[DxfViewerContent] Cannot finish drawing: insufficient points');
      return;
    }

    if (!levelManager.currentLevelId) {
      console.warn('[DxfViewerContent] No current level selected for overlay');
      return;
    }

    try {
      // Convert nested array to flat format for Firestore
      // From: [[x1,y1], [x2,y2], ...] To: [x1, y1, x2, y2, ...]
      const flatPolygon = draftPolygon.flat();
      
      // Save overlay to Firestore
      const overlayId = await overlayStore.add({
        levelId: levelManager.currentLevelId,
        kind: overlayKind,
        polygon: flatPolygon,
        status: overlayStatus,
        label: `${STATUS_ENGLISH_LABELS[overlayStatus]} ${Date.now()}`,
        linked: null,
      });

      
      // Clear draft and auto-select new overlay
      setDraftPolygon([]);
      overlayStore.setSelectedOverlay(overlayId);
      
      // Keep drawing mode active for continuous drawing
    } catch (error) {
      console.error('Error creating overlay:', error);
    }
  }, [draftPolygon, overlayStore, levelManager.currentLevelId, overlayKind, overlayStatus]);

  // Handle vertex drag for overlay editing
  const handleVertexDrag = React.useCallback((overlayId: string, vertexIndex: number, newPoint: { x: number; y: number }) => {
    const overlay = overlayStore.overlays[overlayId];
    if (!overlay) return;

    // overlay.polygon can be flat [x1,y1,...] or nested [[x,y],...]
    const nested = Array.isArray(overlay.polygon[0])
      ? (overlay.polygon as number[][])
      : Array.from({ length: overlay.polygon.length / 2 }, (_, i) => [overlay.polygon[i*2], overlay.polygon[i*2+1]]);

    const newNested = nested.map((v, i) => i === vertexIndex ? [newPoint.x, newPoint.y] : v);
    const flat = newNested.flat();

    overlayStore.update(overlayId, { polygon: flat }); // Save in flat format as currently done in add
  }, [overlayStore]);


  // Wrapper για το handleFileImport που υποστηρίζει encoding
  const handleFileImportWithEncoding = (file: File, encoding?: string) => {
    // DXF import uses Unified Grips System (UGS)
    handleFileImport(file);
    // Auto-activate UGS overlay system after DXF import
    setTimeout(() => {
      handleToolChange('layering'); // Activates UGS through toolbar
      handleAction('toggle-layers'); // Show layers panel
    }, 500); // Small delay to ensure DXF is loaded
  };

  // Auto-open Properties panel and expand groups when selection changes
  React.useEffect(() => {
    if (!selectedEntityIds?.length) return;
    floatingRef.current?.showTab('properties');                          // άνοιξε την καρτέλα
    floatingRef.current?.expandForSelection(selectedEntityIds, currentScene); // άπλωσε groups + scroll
  }, [selectedEntityIds, currentScene]);


  // Handle overlay region click
  const handleRegionClick = React.useCallback((regionId: string) => {
    // Enable selection in all overlay modes for bidirectional sync
    overlayStore.setSelectedOverlay(regionId);
    
    // Auto-open layers panel when clicking on layer in canvas
    if (!showLayers) {
      handleAction('toggle-layers');
    }
    
    // Auto-expand the project level that contains this overlay
    const selectedOverlay = overlayStore.overlays[regionId];
    if (selectedOverlay && selectedOverlay.levelId && selectedOverlay.levelId !== levelManager.currentLevelId) {
      levelManager.setCurrentLevel(selectedOverlay.levelId);
    }
  }, [overlayStore, showLayers, handleAction, levelManager]);

  // Enable grips for selected entities in select mode, grip-edit mode, and layering modes
  React.useEffect(() => {
    // Νέο: κρατάμε τα grips ενεργά ΚΑΙ στο overlayMode: 'draw' (layering)
    const shouldEnableGrips = 
      activeTool === 'select' || 
      activeTool === 'grip-edit' ||
      (activeTool === 'layering' && (overlayMode === 'edit' || overlayMode === 'draw'));

    updateGripSettings({
      showGrips: shouldEnableGrips,
      multiGripEdit: true,
      snapToGrips: true,
    });
  }, [activeTool, overlayMode, updateGripSettings]);

  // Sync level manager currentLevelId with overlay store
  React.useEffect(() => {
    if (levelManager.currentLevelId !== overlayStore.currentLevelId) {
      overlayStore.setCurrentLevel(levelManager.currentLevelId);
    }
  }, [levelManager.currentLevelId, overlayStore]);

  // Event listener for canvas clicks from overlay drawing
  React.useEffect(() => {
    const onOverlayCanvasClick = (event: CustomEvent) => {
      if (overlayMode !== 'draw' || !activeTool || activeTool !== 'layering') return;
      const { point } = event.detail;
      handleOverlayCanvasClick(point);
    };

    window.addEventListener('overlay:canvas-click', onOverlayCanvasClick as EventListener);
    return () => window.removeEventListener('overlay:canvas-click', onOverlayCanvasClick as EventListener);
  }, [overlayMode, activeTool, handleOverlayCanvasClick]);

  // 🎯 Bridge overlay edit mode to grip editing system (with guard to prevent loops)
  React.useEffect(() => {
    // Guard: αν είμαστε σε layering tool, μην κάνουμε auto-switch σε grip-edit
    // Αυτό σταματάει το loop και το «πέταγμα» της καρτέλας
    if (activeTool === 'layering') {
      return;
    }
    
    if (activeTool === 'grip-edit' && overlayMode !== 'edit') {
      // If we're in grip-edit but overlay mode changed away from edit, go back to layering
      handleToolChange('layering');
    }
  }, [overlayMode, activeTool, handleToolChange]);

  // Listen for tool change requests from LevelPanel
  React.useEffect(() => {
    const handleToolChangeRequest = (event: CustomEvent) => {
      const requestedTool = event.detail;
      handleToolChange(requestedTool);
    };

    window.addEventListener('level-panel:tool-change', handleToolChangeRequest as EventListener);
    return () => window.removeEventListener('level-panel:tool-change', handleToolChangeRequest as EventListener);
  }, [handleToolChange]);


  // Fix 2: Ασφάλεια στο parent - sync από το bus (μόνο για 'select')
  React.useEffect(() => {
    const onSelectFromBus = (ev: Event) => {
      const d = (ev as CustomEvent<any>).detail;
      if (!d || d.mode !== 'select') return;
      const ids: string[] = Array.isArray(d.ids) ? d.ids : [];
      setSelectedEntityIds(prev => {
        if (prev.length === ids.length && prev.every((v, i) => v === ids[i])) return prev; // no-op
        return ids;
      });
    };
    window.addEventListener('dxf.highlightByIds', onSelectFromBus as EventListener);
    return () => window.removeEventListener('dxf.highlightByIds', onSelectFromBus as EventListener);
  }, []);

  // ΒΟΗΘΗΤΙΚΟ: βρίσκει/δημιουργεί layer για το συγκεκριμένο χρώμα
  const ensureLayerForColor = (scene: SceneModel, hex: string): { scene: SceneModel, layerName: string } => {
    // 1) αν ήδη υπάρχει layer με αυτό το χρώμα, χρησιμοποίησέ το
    const existing = Object.entries(scene.layers).find(
      ([name, l]) => (l as any)?.colorHex?.toLowerCase?.() === hex.toLowerCase?.()
                    || (l as any)?.color?.toLowerCase?.() === hex.toLowerCase?.()
    );
    if (existing) return { scene, layerName: existing[0] };

    // 2) αλλιώς, φτιάξε καινούριο
    const newName = `COLOR_${hex.replace('#','').toUpperCase()}`;
    const newLayers = {
      ...scene.layers,
      [newName]: { name: newName, color: hex, colorHex: hex, visible: true }
    };
    return { scene: { ...scene, layers: newLayers }, layerName: newName };
  };

  // ΚΥΡΙΟ: εφάρμοσε χρώμα σε ΟΛΕΣ τις επιλεγμένες οντότητες + ενημέρωσε scene/panels
  const applyColorToEntities = (hex: string, ids: string[]) => {
    if (!currentScene || !ids?.length) return;

    // 1) layer για το χρώμα
    const idSet = new Set(ids);
    // εντοπισμός/δημιουργία layer για το hex
    const { scene: sceneA, layerName } = ensureLayerForColor(currentScene, hex);

    // 2) μεταφορά των οντοτήτων στο νέο layer + ενημέρωση color
    const newEntities = sceneA.entities.map(e =>
      idSet.has(e.id) ? { ...e, layer: layerName, color: hex } : e
    );

    const updated = { ...sceneA, entities: newEntities };

    // 3) ΈΝΑ commit + ΈΝΑ render
    handleSceneChange(updated);                               // state update
    
    // 4) Άνοιγμα/expand στα properties για τη νέα ομάδα (προαιρετικό)
    floatingRef.current?.expandForSelection(ids, updated);
    
    setColorMenu(s => ({...s, open: false}));
  };

  // helper: μετατόπιση όλων των επιλεγμένων κατά (dx, dy) σε world units
  const nudgeSelection = React.useCallback((dx: number, dy: number) => {
    if (!currentScene || !selectedEntityIds?.length) return;
    const idSet = new Set(selectedEntityIds);

    const moved = currentScene.entities.map(e => {
      if (!idSet.has(e.id)) return e;

      if (e.type === 'line' && e.start && e.end) {
        return {
          ...e,
          start: { x: e.start.x + dx, y: e.start.y + dy },
          end:   { x: e.end.x   + dx, y: e.end.y   + dy }
        };
      }
      if ((e.type === 'circle' || e.type === 'arc') && (e as any).center) {
        return { ...e, center: { x: (e as any).center.x + dx, y: (e as any).center.y + dy } };
      }
      if (e.type === 'polyline' && Array.isArray((e as any).points)) {
        const pts = (e as any).points.map((p: any) => ({ x: p.x + dx, y: p.y + dy }));
        return { ...e, points: pts };
      }
      // fallback: αν έχεις bounds-only ή άλλα types, άφησέ τα ως έχουν
      return e;
    });

    const updated = { ...currentScene, entities: moved };
    handleSceneChange(updated);
    dxfCanvasRef.current?.renderScene(updated);
  }, [currentScene, selectedEntityIds, handleSceneChange]);

  // Constants για nudging
  const NUDGE_BASE = 0.1;         // μικρός βασικός βηματισμός (world units)
  const NUDGE_SHIFT_MULT = 3;     // Shift => ×3

  // Constants για zoom
  const ZOOM_FACTOR = 1.2;

  // Mouse tracking για zoom
  const lastMouseRef = React.useRef<{x:number; y:number} | null>(null);

  // Mouse move handler
  const handleCanvasMouseMove = React.useCallback((pt: {x:number; y:number}) => {
    lastMouseRef.current = pt;
  }, []);

  // ESC για κλείσιμο palette + keyboard nudging + zoom
  React.useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => { 
      // ESC κλείνει palette
      if (e.key === 'Escape') {
        setColorMenu(s => ({...s, open:false}));
        return;
      }
      
      // Delete key για διαγραφή overlay σε edit mode
      if (e.key === 'Delete' && activeTool === 'layering' && overlayMode === 'edit' && overlayStore.selectedOverlayId) {
        e.preventDefault();
        overlayStore.remove(overlayStore.selectedOverlayId);
        return;
      }
      
      // Layout-safe ανίχνευση +/−
      const isPlus =
        e.key === '+' ||
        (e.key === '=' && e.shiftKey) ||
        e.code === 'NumpadAdd' ||
        (e.code === 'Equal' && e.shiftKey) ||
        (e.code === 'Semicolon' && e.shiftKey); // σε κάποια GR layouts
      const isMinus =
        e.key === '-' ||
        e.code === 'Minus' ||
        e.code === 'NumpadSubtract';
      
      if (isPlus || isMinus) {
        // ✅ ΕΛΕΓΧΟΣ: Αν το focus είναι σε input field, ΜΗ διαχειριστείς zoom
        const inputFocused = document.activeElement && 
          document.activeElement.tagName === 'INPUT' && 
          document.activeElement.getAttribute('type') === 'text';
        
        if (inputFocused) {
          return; // ΧΩΡΙΣ preventDefault - άφησε το event να φτάσει στο input
        }
        e.preventDefault();

        const factor = isPlus ? 1.2 : 1/1.2;
        const canvas = dxfCanvasRef.current?.getCanvas?.();

        if (!canvas) {
          return isPlus
            ? dxfCanvasRef.current?.zoomIn?.()
            : dxfCanvasRef.current?.zoomOut?.();
        }

        const rect = canvas.getBoundingClientRect();

        // Zoom γύρω από τον τελευταίο δείκτη αν υπάρχει, αλλιώς κέντρο
        const pt = lastMouseRef.current
          ? lastMouseRef.current
          : { x: rect.width/2, y: rect.height/2 };

        dxfCanvasRef.current?.zoomAtScreenPoint?.(factor, pt);
        return;
      }
      
      // Reset zoom με 0 ή Numpad0
      const isReset = e.key === '0' || e.code === 'Numpad0';
      if (isReset) {
        // ✅ ΕΛΕΓΧΟΣ: Αν το focus είναι σε input field, ΜΗ διαχειριστείς reset zoom
        const inputFocused = document.activeElement && 
          document.activeElement.tagName === 'INPUT' && 
          document.activeElement.getAttribute('type') === 'text';
        
        if (inputFocused) {
            return; // ΧΩΡΙΣ preventDefault - άφησε το event να φτάσει στο input
        }
        e.preventDefault();
        dxfCanvasRef.current?.resetToOrigin?.();
        return;
      }
      
      // Arrow keys για nudging
      if (!selectedEntityIds?.length) return;
      if (!['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key)) return;

      e.preventDefault();

      // Μικρό βήμα, Shift = ×3
      const step = NUDGE_BASE * (e.shiftKey ? NUDGE_SHIFT_MULT : 1);

      let dx = 0, dy = 0;
      switch (e.key) {
        case 'ArrowUp':    dy =  step; break;   // +Y προς τα πάνω
        case 'ArrowDown':  dy = -step; break;
        case 'ArrowLeft':  dx = -step; break;
        case 'ArrowRight': dx =  step; break;
      }
      nudgeSelection(dx, dy);
    };
    
    window.addEventListener('keydown', onKeyDown, { capture: true });
    return () => window.removeEventListener('keydown', onKeyDown, { capture: true });
  }, [selectedEntityIds, nudgeSelection, activeTool, overlayMode, overlayStore, levelManager]);

  return (
    <div className="flex h-full p-2 gap-2 bg-gray-800">
      {/* Container 1: FloatingPanelContainer (Left) */}
      <div className="w-80 flex-shrink-0 h-full">
        <div className="h-full bg-gray-900 rounded-lg shadow-lg border border-gray-500 overflow-hidden">
          <FloatingPanelContainer
            ref={floatingRef}
            sceneModel={currentScene}
            selectedEntityIds={selectedEntityIds}
            onEntitySelect={setSelectedEntityIds}
            zoomLevel={currentZoom}
            currentTool={activeTool}
          />
        </div>
      </div>

      {/* Main content area (Right) */}
      <div className="flex-1 flex flex-col gap-2 h-full">
        {/* Container 2: Main Toolbar */}
        <div className="bg-gray-900 rounded-lg shadow-lg border border-gray-500">
          <ToolbarWithCursorCoordinates
            activeTool={activeTool}
            onToolChange={handleToolChange}
            onAction={handleAction}
            showGrid={showGrid}
            autoCrop={false}
            canUndo={canUndo}
            canRedo={canRedo}
            snapEnabled={snapEnabled}
            showLayers={showLayers}
            showProperties={showProperties}
            showCalibration={showCalibration}
            showCursorSettings={showCursorSettings}
            currentZoom={currentZoom}
            commandCount={0}
            onSceneImported={handleFileImportWithEncoding}
          />
        </div>

        {/* Container 3: Overlay Toolbar - Visible when layering tool is active (unified system) */}
        {activeTool && activeTool === 'layering' && (
          <div className="bg-gray-900 rounded-lg shadow-lg border border-gray-500">
            <OverlayToolbar
               mode={overlayMode}
               onModeChange={setOverlayMode}
               currentStatus={overlayStatus}
               onStatusChange={setOverlayStatus}
               currentKind={overlayKind}
               onKindChange={setOverlayKind}
               snapEnabled={snapEnabled}
               onSnapToggle={() => handleAction('toggle-snap')}
               selectedOverlayId={null}
               onDuplicate={() => {}}
               onDelete={() => {}}
               canUndo={canUndo}
               canRedo={canRedo}
               onUndo={() => handleAction('undo')}
               onRedo={() => handleAction('redo')}
            />
          </div>
        )}

        {/* Container 4: Canvas */}
        <div className="flex-1 relative bg-gray-900 rounded-lg shadow-lg border border-gray-500 overflow-hidden">
          <DxfCanvas
            ref={dxfCanvasRef}
            scene={currentScene}
            onTransformChange={wrappedHandleTransformChange}
            selectedEntityIds={selectedEntityIds}
            onSelectEntity={(entityIds) => {
              // Always allow entity selection when clicking on canvas
              setSelectedEntityIds(Array.isArray(entityIds) ? entityIds : [entityIds]);
            }}
            onMouseMove={handleCanvasMouseMove}
            onRequestColorMenu={(at) => {
              if (!selectedEntityIds?.length) return;
              setColorMenu({ open: true, x: at.x, y: at.y, ids: selectedEntityIds.slice() });
            }}
            alwaysShowCoarseGrid={showGrid}
            isZoomWindowActive={activeTool === 'zoom-window'}
            onZoomWindowModeChange={(active) => {
              if (!active) handleToolChange('select');
            }}
            showCalibration={showCalibration}
            onCalibrationToggle={handleCalibrationToggle}
            onSceneChange={handleSceneChange}
            activeTool={activeTool}
            measurements={[]}
            tempMeasurementPoints={[]}
            onMeasurementPoint={onMeasurementPoint}
            onMeasurementHover={onMeasurementHover}
            onMeasurementCancel={onMeasurementCancel}
            drawingState={drawingState}
            onDrawingPoint={onDrawingPoint}
            onDrawingHover={onDrawingHover}
            onDrawingCancel={onDrawingCancel}
            onDrawingDoubleClick={onDrawingDoubleClick}
            gripSettings={gripSettings}
            onEntityCreated={onEntityCreated}
            className="absolute inset-0"
          />

          {/* Unified OverlayCanvasCore system for ALL overlay modes - same behavior as DXF grips */}
          {activeTool === 'layering' && (() => {
            const currentLevelId = levelManager.currentLevelId;
            const overlaysForLevel = Object.values(overlayStore.overlays)
              .filter(ov => !ov.levelId || ov.levelId === currentLevelId);
            const regions = overlaysToRegions(overlaysForLevel);
            
            // Use same transform format as DXF system
            const viewTransform = {
              scale: canvasTransform.scale,
              offsetX: canvasTransform.offsetX,
              offsetY: canvasTransform.offsetY
            };
            
            
            return (
              <div style={{ position: 'absolute', inset: 0, zIndex: 20, pointerEvents: 'auto' }}>
                <OverlayCanvasCore
                  transform={viewTransform}
                  visibleRegions={regions}
                  selectedRegionIds={overlayStore.selectedOverlayId ? [overlayStore.selectedOverlayId] : []}
                  showHandles={overlayMode === 'edit'}
                  showLabels={true}
                  isDrawing={overlayMode === 'draw'}
                  drawingVertices={draftPolygon.map(([x, y]) => ({ x, y }))}
                  drawingStatus={overlayStatus as any}
                  editingRegionId={overlayStore.selectedOverlayId || null}
                  mousePosition={null}
                  onRegionClick={handleRegionClick}
                  onRendererReady={() => {}}
                  onMouseDown={() => {}}
                  onMouseMove={() => {}}
                  onMouseUp={(e) => {
                    if (overlayMode === 'draw') {
                      const canvas = e.currentTarget as HTMLCanvasElement;
                      const r = canvas.getBoundingClientRect();
                      const sp = { x: e.clientX - r.left, y: e.clientY - r.top };
                      const wp = {
                        x: (sp.x - canvasTransform.offsetX) / canvasTransform.scale,
                        y: (sp.y - canvasTransform.offsetY) / canvasTransform.scale
                      };
                      
                      handleOverlayCanvasClick(wp);
                    }
                  }}
                  onMouseLeave={() => {}}
                  onContextMenu={() => {}}
                />
              </div>
            );
          })()}
        </div>
      </div>

      {/* Right-click Color Menu Popover */}
      {colorMenu.open && (
        <div
          style={{
            position: 'fixed',
            left: colorMenu.x,
            top: colorMenu.y,
            zIndex: 9999
          }}
          onMouseDown={(e) => { e.preventDefault(); e.stopPropagation(); }} // μη αφήσεις click να "τρυπήσει" στον καμβά
          onContextMenu={(e) => { e.preventDefault(); e.stopPropagation(); }} // μην «ξαναανοίξει» το browser menu
        >
          <ColorPickerModal
            title="🎨 Επιλογή Χρώματος για Επιλεγμένες Οντότητες"
            onColorSelect={(hex) => applyColorToEntities(hex, colorMenu.ids)}
            onClose={() => setColorMenu(s => ({...s, open:false}))}
          />
        </div>
      )}

      {/* Cursor Settings Panel */}
      {showCursorSettings && (
        <CursorSettingsPanel 
          isVisible={showCursorSettings}
          onClose={() => handleAction('toggle-cursor-settings')}
        />
      )}
    </div>
  );
}