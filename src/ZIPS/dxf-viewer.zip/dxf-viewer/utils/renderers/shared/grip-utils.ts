/**
 * Shared grip utilities for renderers
 */

import type { GripInfo } from '../BaseEntityRenderer';
import type { Point2D } from '../../../systems/coordinates/config';

/**
 * Creates grip info objects from an array of points
 * @param entityId - The entity ID
 * @param points - Array of grip positions
 * @param startIndex - Starting grip index (default: 1)
 * @returns Array of grip info objects
 */
export function createGripsFromPoints(
  entityId: string, 
  points: Point2D[], 
  startIndex: number = 1
): GripInfo[] {
  const grips: GripInfo[] = [];
  
  points.forEach((point, index) => {
    grips.push({
      entityId,
      gripType: 'vertex',
      gripIndex: index + startIndex,
      position: point,
      state: 'cold'
    });
  });
  
  return grips;
}