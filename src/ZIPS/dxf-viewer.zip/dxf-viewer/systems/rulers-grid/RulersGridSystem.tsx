'use client';
import React, { createContext, useState, useCallback, useMemo, useEffect } from 'react';
import type { Point2D, ViewTransform, CanvasRect } from '../coordinates/config';
import {
  RulerSettings,
  GridSettings,
  RulersGridState,
  DEFAULT_RULER_SETTINGS,
  DEFAULT_GRID_SETTINGS,
  RULERS_GRID_CONFIG,
  UnitType,
  GridBounds,
  SnapResult,
  RulerTick,
  GridLine,
  RulersLayoutInfo,
  RulersGridOperationResult,
  RulersGridOperation,
  RulerSettingsUpdate,
  GridSettingsUpdate
} from './config';
import { RulersGridCalculations, RulersGridRendering, RulersGridSnapping } from './utils';
import { setRulersGridContext, type RulersGridHookReturn } from './useRulersGrid';
import { RulersGridSystemProps, DEFAULT_ORIGIN } from './types';
import { useRulerManagement } from './useRulerManagement';
import { useGridManagement } from './useGridManagement';
import { useSnapManagement } from './useSnapManagement';
import { useRenderingCalculations } from './useRenderingCalculations';

function useRulersGridSystemIntegration({
  initialRulerSettings = {},
  initialGridSettings = {},
  initialOrigin = DEFAULT_ORIGIN,
  initialVisibility = true,
  enablePersistence = false,
  persistenceKey = 'dxf-viewer-rulers-grid',
  onSettingsChange,
  onOriginChange,
  onVisibilityChange,
  onSnapResult,
  viewTransform,
  canvasBounds
}: Omit<RulersGridSystemProps, 'children'>): RulersGridHookReturn {

  // Load persisted settings if enabled
  const loadPersistedSettings = useCallback(() => {
    if (!enablePersistence) return null;
    try {
      const stored = localStorage.getItem(persistenceKey);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  }, [enablePersistence, persistenceKey]);

  const persistedData = loadPersistedSettings();

  // State initialization
  const [rulers, setRulers] = useState<RulerSettings>(() => ({
    ...DEFAULT_RULER_SETTINGS,
    ...persistedData?.rulers,
    ...initialRulerSettings
  }));

  const [grid, setGrid] = useState<GridSettings>(() => ({
    ...DEFAULT_GRID_SETTINGS,
    ...persistedData?.grid,
    ...initialGridSettings
  }));

  const [origin, setOriginState] = useState<Point2D>(() => 
    persistedData?.origin || initialOrigin
  );

  const [isVisible, setIsVisible] = useState<boolean>(() => 
    persistedData?.isVisible ?? initialVisibility
  );

  const [rulerSnapPoints, setRulerSnapPoints] = useState<Point2D[]>([]);
  const [gridSnapPoints, setGridSnapPoints] = useState<Point2D[]>([]);
  const [lastCalculatedBounds, setLastCalculatedBounds] = useState<RulersGridState['lastCalculatedBounds']>(null);

  // State object
  const state = useMemo<RulersGridState>(() => ({
    rulers,
    grid,
    origin,
    isVisible,
    rulerSnapPoints,
    gridSnapPoints,
    lastCalculatedBounds
  }), [rulers, grid, origin, isVisible, rulerSnapPoints, gridSnapPoints, lastCalculatedBounds]);

  // Initialize individual management hooks
  const rulerMethods = useRulerManagement(rulers, setRulers);
  const gridMethods = useGridManagement(grid, setGrid);
  const snapMethods = useSnapManagement(rulers, setRulers, grid, setGrid, state, viewTransform, onSnapResult);
  const renderingMethods = useRenderingCalculations(rulers, grid, origin);

  // Persistence effect
  useEffect(() => {
    if (enablePersistence) {
      const dataToStore = {
        rulers,
        grid,
        origin,
        isVisible,
        timestamp: Date.now()
      };
      try {
        localStorage.setItem(persistenceKey, JSON.stringify(dataToStore));
      } catch (error) {
        console.warn('Failed to persist rulers/grid settings:', error);
      }
    }
  }, [rulers, grid, origin, isVisible, enablePersistence, persistenceKey]);

  // Calculations and updates when view changes
  useEffect(() => {
    if (viewTransform && canvasBounds) {
      const bounds = RulersGridCalculations.calculateGridBounds(viewTransform, canvasBounds);
      setLastCalculatedBounds(bounds);

      // Update snap points
      if (rulers.snap.enabled) {
        const rulerSnaps = RulersGridCalculations.calculateRulerSnapPoints(rulers, bounds);
        setRulerSnapPoints(rulerSnaps);
      }

      if (grid.snap.enabled) {
        const gridSnaps = RulersGridCalculations.calculateGridSnapPoints(grid, origin, bounds);
        setGridSnapPoints(gridSnaps);
      }
    }
  }, [rulers, grid, origin, viewTransform, canvasBounds]);

  // Settings change effects
  useEffect(() => {
    onSettingsChange?.(rulers, grid);
  }, [rulers, grid, onSettingsChange]);

  useEffect(() => {
    onVisibilityChange?.(isVisible);
  }, [isVisible, onVisibilityChange]);

  // Origin and coordinate system functions
  const setOrigin = useCallback((point: Point2D) => {
    setOriginState(point);
    onOriginChange?.(point);
  }, [onOriginChange]);

  const resetOrigin = useCallback(() => {
    setOrigin(DEFAULT_ORIGIN);
  }, [setOrigin]);

  const getOrigin = useCallback(() => origin, [origin]);

  // Utility operations
  const performOperation = useCallback(async (operation: RulersGridOperation): Promise<RulersGridOperationResult> => {
    try {
      switch (operation) {
        case 'toggle-rulers':
          rulerMethods.toggleRulers();
          break;
        case 'toggle-grid':
          gridMethods.toggleGrid();
          break;
        case 'toggle-ruler-snap':
          snapMethods.toggleRulerSnap();
          break;
        case 'toggle-grid-snap':
          snapMethods.toggleGridSnap();
          break;
        case 'reset-origin':
          resetOrigin();
          break;
        default:
          throw new Error(`Unknown operation: ${operation}`);
      }
      
      return { success: true, operation };
    } catch (error) {
      return {
        success: false,
        operation,
        error: error instanceof Error ? error.message : 'Operation failed'
      };
    }
  }, [rulerMethods, gridMethods, snapMethods, resetOrigin]);

  const exportSettings = useCallback(() => {
    return {
      rulers,
      grid,
      origin,
      isVisible,
      version: '1.0',
      timestamp: Date.now()
    };
  }, [rulers, grid, origin, isVisible]);

  const importSettings = useCallback((data: any): RulersGridOperationResult => {
    try {
      if (data.rulers) setRulers({ ...DEFAULT_RULER_SETTINGS, ...data.rulers });
      if (data.grid) setGrid({ ...DEFAULT_GRID_SETTINGS, ...data.grid });
      if (data.origin) setOrigin(data.origin);
      if (data.isVisible !== undefined) setIsVisible(data.isVisible);
      
      return { success: true, operation: 'import' };
    } catch (error) {
      return {
        success: false,
        operation: 'import',
        error: error instanceof Error ? error.message : 'Import failed'
      };
    }
  }, [setOrigin]);

  return {
    // State
    state,
    
    // Ruler Management
    ...rulerMethods,
    
    // Grid Management
    ...gridMethods,
    
    // Origin and Coordinate System
    setOrigin,
    resetOrigin,
    getOrigin,
    
    // Snap Functionality
    ...snapMethods,
    
    // Calculations and Rendering
    ...renderingMethods,
    
    // Operations
    performOperation,
    exportSettings,
    importSettings,
    
    // System Control
    setVisibility: setIsVisible,
    getVisibility: () => isVisible,
    resetSettings: () => {
      setRulers(DEFAULT_RULER_SETTINGS);
      setGrid(DEFAULT_GRID_SETTINGS);
      resetOrigin();
      setIsVisible(true);
    }
  };
}

const RulersGridContext = createContext<RulersGridHookReturn | null>(null);

export function useRulersGridContext(): RulersGridHookReturn {
  const context = React.useContext(RulersGridContext);
  if (!context) {
    throw new Error('useRulersGridContext must be used within RulersGridSystem');
  }
  return context;
}

export function RulersGridSystem({ children, ...props }: RulersGridSystemProps) {
  const value = useRulersGridSystemIntegration(props);

  React.useEffect(() => {
    setRulersGridContext(RulersGridContext);
  }, []);

  return (
    <RulersGridContext.Provider value={value}>
      {children}
    </RulersGridContext.Provider>
  );
}