/**
 * RULERS/GRID SYSTEM UTILITIES
 * Utility functions for rulers and grid calculations and operations
 */

import type {
  RulerSettings,
  GridSettings,
  UnitType,
  GridBounds,
  SnapResult,
  RulerTick,
  GridLine,
  RulersLayoutInfo,
  RULERS_GRID_CONFIG
} from './config';
import type { Point2D, ViewTransform, CanvasRect } from '../coordinates/config';

// ===== UNIT CONVERSION UTILITIES =====
export const UnitConversion = {
  /**
   * Converts value from one unit to another
   */
  convert: (value: number, fromUnit: UnitType, toUnit: UnitType): number => {
    if (fromUnit === toUnit) return value;
    
    const fromFactor = RULERS_GRID_CONFIG.UNIT_CONVERSIONS[fromUnit];
    const toFactor = RULERS_GRID_CONFIG.UNIT_CONVERSIONS[toUnit];
    
    return (value * fromFactor) / toFactor;
  },

  /**
   * Formats a value with appropriate precision for the unit
   */
  format: (value: number, units: UnitType, precision?: number): string => {
    const defaultPrecision = units === 'mm' ? 1 : units === 'cm' ? 2 : units === 'm' ? 3 : 2;
    const actualPrecision = precision ?? defaultPrecision;
    
    const formatted = value.toFixed(actualPrecision);
    return `${formatted}${units}`;
  },

  /**
   * Gets appropriate step size for unit
   */
  getStepForUnit: (units: UnitType, baseStep: number = 10): number => {
    switch (units) {
      case 'mm': return baseStep;
      case 'cm': return baseStep / 10;
      case 'm': return baseStep / 1000;
      case 'inches': return baseStep / 25.4;
      case 'feet': return baseStep / 304.8;
      default: return baseStep;
    }
  }
};

// ===== GRID CALCULATION UTILITIES =====
export const GridCalculations = {
  /**
   * Calculates adaptive grid spacing based on zoom level
   */
  calculateAdaptiveSpacing: (
    scale: number,
    baseStep: number,
    settings: GridSettings
  ): number => {
    if (!settings.behavior.adaptiveGrid) {
      return baseStep;
    }
    
    let currentStep = baseStep;
    
    // Increase step size when too dense
    while (currentStep * scale < settings.behavior.minGridSpacing) {
      currentStep *= settings.visual.subDivisions;
    }
    
    // Decrease step size when too sparse
    while (currentStep * scale > settings.behavior.maxGridSpacing) {
      currentStep /= settings.visual.subDivisions;
    }
    
    return currentStep;
  },

  /**
   * Calculates visible grid boundaries in world coordinates
   */
  calculateVisibleBounds: (
    transform: ViewTransform,
    canvasRect: CanvasRect,
    gridStep: number
  ): GridBounds => {
    // Convert screen corners to world coordinates
    const topLeft = {
      x: -transform.offsetX,
      y: (canvasRect.height / transform.scale) - transform.offsetY
    };
    const bottomRight = {
      x: (canvasRect.width / transform.scale) - transform.offsetX,
      y: -transform.offsetY
    };

    const subStep = gridStep / 5; // Default subdivision

    return {
      minX: Math.floor(topLeft.x / gridStep) * gridStep,
      maxX: Math.ceil(bottomRight.x / gridStep) * gridStep,
      minY: Math.floor(bottomRight.y / gridStep) * gridStep,
      maxY: Math.ceil(topLeft.y / gridStep) * gridStep,
      gridStep,
      subStep
    };
  },

  /**
   * Generates grid lines for rendering
   */
  generateGridLines: (
    bounds: GridBounds,
    settings: GridSettings,
    transform: ViewTransform
  ): GridLine[] => {
    const lines: GridLine[] = [];
    const { minX, maxX, minY, maxY, gridStep, subStep } = bounds;

    // Performance check
    const estimatedLines = ((maxX - minX) / gridStep) + ((maxY - minY) / gridStep);
    if (estimatedLines > RULERS_GRID_CONFIG.MAX_GRID_LINES) {
      console.warn('Too many grid lines, skipping render');
      return lines;
    }

    // Vertical lines
    for (let x = minX; x <= maxX; x += gridStep) {
      const isAxis = Math.abs(x) < 0.001;
      const isOrigin = isAxis;
      
      if (isAxis && settings.visual.showAxes) {
        lines.push({
          type: 'axis',
          position: x,
          orientation: 'vertical',
          opacity: settings.visual.opacity,
          weight: settings.visual.axesWeight,
          color: settings.visual.axesColor
        });
      } else {
        lines.push({
          type: 'major',
          position: x,
          orientation: 'vertical',
          opacity: settings.visual.opacity,
          weight: settings.visual.majorGridWeight,
          color: settings.visual.majorGridColor
        });
      }

      // Minor subdivision lines
      if (settings.visual.subDivisions > 1) {
        for (let i = 1; i < settings.visual.subDivisions; i++) {
          const subX = x + (i * subStep);
          if (subX <= maxX) {
            lines.push({
              type: 'minor',
              position: subX,
              orientation: 'vertical',
              opacity: settings.visual.opacity * 0.5,
              weight: settings.visual.minorGridWeight,
              color: settings.visual.minorGridColor
            });
          }
        }
      }
    }

    // Horizontal lines
    for (let y = minY; y <= maxY; y += gridStep) {
      const isAxis = Math.abs(y) < 0.001;
      
      if (isAxis && settings.visual.showAxes) {
        lines.push({
          type: 'axis',
          position: y,
          orientation: 'horizontal',
          opacity: settings.visual.opacity,
          weight: settings.visual.axesWeight,
          color: settings.visual.axesColor
        });
      } else {
        lines.push({
          type: 'major',
          position: y,
          orientation: 'horizontal',
          opacity: settings.visual.opacity,
          weight: settings.visual.majorGridWeight,
          color: settings.visual.majorGridColor
        });
      }

      // Minor subdivision lines
      if (settings.visual.subDivisions > 1) {
        for (let i = 1; i < settings.visual.subDivisions; i++) {
          const subY = y + (i * subStep);
          if (subY <= maxY) {
            lines.push({
              type: 'minor',
              position: subY,
              orientation: 'horizontal',
              opacity: settings.visual.opacity * 0.5,
              weight: settings.visual.minorGridWeight,
              color: settings.visual.minorGridColor
            });
          }
        }
      }
    }

    return lines;
  },

  /**
   * Gets effective opacity based on distance and settings
   */
  getEffectiveOpacity: (
    baseOpacity: number,
    transform: ViewTransform,
    settings: GridSettings
  ): number => {
    if (!settings.behavior.fadeAtDistance) {
      return baseOpacity;
    }

    const scaleFactor = Math.max(0, Math.min(1, transform.scale / 10));
    const fadeMultiplier = Math.max(settings.behavior.fadeThreshold, scaleFactor);
    
    return baseOpacity * fadeMultiplier;
  }
};

// ===== RULER CALCULATION UTILITIES =====
export const RulerCalculations = {
  /**
   * Calculates ruler tick positions and labels
   */
  calculateTicks: (
    type: 'horizontal' | 'vertical',
    bounds: GridBounds,
    settings: RulerSettings,
    transform: ViewTransform,
    canvasRect: CanvasRect
  ): RulerTick[] => {
    const ticks: RulerTick[] = [];
    const isHorizontal = type === 'horizontal';
    
    const start = isHorizontal ? bounds.minX : bounds.minY;
    const end = isHorizontal ? bounds.maxX : bounds.maxY;
    
    // Calculate tick spacing
    const baseSpacing = UnitConversion.getStepForUnit(settings.units, 10);
    const tickSpacing = GridCalculations.calculateAdaptiveSpacing(
      transform.scale,
      baseSpacing,
      { behavior: { adaptiveGrid: true, minGridSpacing: 20, maxGridSpacing: 80 } } as GridSettings
    );

    // Performance check
    const estimatedTicks = Math.abs(end - start) / tickSpacing;
    if (estimatedTicks > RULERS_GRID_CONFIG.MAX_RULER_TICKS) {
      console.warn('Too many ruler ticks, skipping render');
      return ticks;
    }

    // Generate major ticks
    const startTick = Math.floor(start / tickSpacing) * tickSpacing;
    for (let pos = startTick; pos <= end; pos += tickSpacing) {
      const isMajor = Math.abs(pos % (tickSpacing * 5)) < 0.001;
      const isZero = Math.abs(pos) < 0.001;
      
      if (isZero && !settings[type].showZero) continue;

      ticks.push({
        position: pos,
        type: isMajor ? 'major' : 'minor',
        length: isMajor ? settings[type].majorTickLength : settings[type].minorTickLength,
        label: isMajor ? UnitConversion.format(pos, settings.units, settings[type].precision) : undefined,
        value: pos
      });

      // Generate minor ticks if enabled
      if (settings[type].showMinorTicks && isMajor) {
        const minorSpacing = tickSpacing / 5;
        for (let i = 1; i < 5; i++) {
          const minorPos = pos + (i * minorSpacing);
          if (minorPos <= end) {
            ticks.push({
              position: minorPos,
              type: 'minor',
              length: settings[type].minorTickLength,
              value: minorPos
            });
          }
        }
      }
    }

    return ticks.sort((a, b) => a.position - b.position);
  },

  /**
   * Gets layout information for rulers
   */
  calculateLayout: (canvasRect: CanvasRect, settings: RulerSettings): RulersLayoutInfo => {
    const hHeight = settings.horizontal.enabled ? settings.horizontal.height : 0;
    const vWidth = settings.vertical.enabled ? settings.vertical.width : 0;

    return {
      horizontalRulerRect: {
        x: vWidth,
        y: settings.horizontal.position === 'top' ? 0 : canvasRect.height - hHeight,
        width: canvasRect.width - vWidth,
        height: hHeight
      },
      verticalRulerRect: {
        x: settings.vertical.position === 'left' ? 0 : canvasRect.width - vWidth,
        y: hHeight,
        width: vWidth,
        height: canvasRect.height - hHeight
      },
      cornerRect: {
        x: settings.vertical.position === 'left' ? 0 : canvasRect.width - vWidth,
        y: settings.horizontal.position === 'top' ? 0 : canvasRect.height - hHeight,
        width: vWidth,
        height: hHeight
      },
      contentRect: {
        x: settings.vertical.position === 'left' ? vWidth : 0,
        y: settings.horizontal.position === 'top' ? hHeight : 0,
        width: canvasRect.width - vWidth,
        height: canvasRect.height - hHeight
      }
    };
  }
};


// ===== SETTINGS VALIDATION UTILITIES =====
export const SettingsValidation = {
  /**
   * Validates ruler settings
   */
  validateRulerSettings: (settings: RulerSettings): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];

    // Validate dimensions
    if (settings.horizontal.height < RULERS_GRID_CONFIG.MIN_RULER_HEIGHT || 
        settings.horizontal.height > RULERS_GRID_CONFIG.MAX_RULER_HEIGHT) {
      errors.push(`Horizontal ruler height must be between ${RULERS_GRID_CONFIG.MIN_RULER_HEIGHT} and ${RULERS_GRID_CONFIG.MAX_RULER_HEIGHT}`);
    }

    if (settings.vertical.width < RULERS_GRID_CONFIG.MIN_RULER_WIDTH || 
        settings.vertical.width > RULERS_GRID_CONFIG.MAX_RULER_WIDTH) {
      errors.push(`Vertical ruler width must be between ${RULERS_GRID_CONFIG.MIN_RULER_WIDTH} and ${RULERS_GRID_CONFIG.MAX_RULER_WIDTH}`);
    }

    // Validate precision
    if (settings.horizontal.precision < 0 || settings.horizontal.precision > 10) {
      errors.push('Horizontal ruler precision must be between 0 and 10');
    }

    if (settings.vertical.precision < 0 || settings.vertical.precision > 10) {
      errors.push('Vertical ruler precision must be between 0 and 10');
    }

    // Validate snap tolerance
    if (settings.snap.tolerance < RULERS_GRID_CONFIG.MIN_SNAP_TOLERANCE ||
        settings.snap.tolerance > RULERS_GRID_CONFIG.MAX_SNAP_TOLERANCE) {
      errors.push(`Snap tolerance must be between ${RULERS_GRID_CONFIG.MIN_SNAP_TOLERANCE} and ${RULERS_GRID_CONFIG.MAX_SNAP_TOLERANCE}`);
    }

    return { valid: errors.length === 0, errors };
  },

  /**
   * Validates grid settings
   */
  validateGridSettings: (settings: GridSettings): { valid: boolean; errors: string[] } => {
    const errors: string[] = [];

    // Validate step size
    if (settings.visual.step < RULERS_GRID_CONFIG.MIN_GRID_STEP ||
        settings.visual.step > RULERS_GRID_CONFIG.MAX_GRID_STEP) {
      errors.push(`Grid step must be between ${RULERS_GRID_CONFIG.MIN_GRID_STEP} and ${RULERS_GRID_CONFIG.MAX_GRID_STEP}`);
    }

    // Validate opacity
    if (settings.visual.opacity < RULERS_GRID_CONFIG.MIN_OPACITY ||
        settings.visual.opacity > RULERS_GRID_CONFIG.MAX_OPACITY) {
      errors.push(`Grid opacity must be between ${RULERS_GRID_CONFIG.MIN_OPACITY} and ${RULERS_GRID_CONFIG.MAX_OPACITY}`);
    }

    // Validate subdivisions
    if (settings.visual.subDivisions < 1 || settings.visual.subDivisions > 20) {
      errors.push('Grid subdivisions must be between 1 and 20');
    }

    // Validate behavior settings
    if (settings.behavior.minGridSpacing < 1 || settings.behavior.minGridSpacing > 100) {
      errors.push('Min grid spacing must be between 1 and 100 pixels');
    }

    if (settings.behavior.maxGridSpacing < 10 || settings.behavior.maxGridSpacing > 500) {
      errors.push('Max grid spacing must be between 10 and 500 pixels');
    }

    return { valid: errors.length === 0, errors };
  }
};

// ===== PERFORMANCE UTILITIES =====
export const PerformanceUtilities = {
  /**
   * Determines if grid should be rendered based on performance
   */
  shouldRenderGrid: (transform: ViewTransform, settings: GridSettings): boolean => {
    const effectiveStep = GridCalculations.calculateAdaptiveSpacing(
      transform.scale,
      settings.visual.step,
      settings
    );
    
    const estimatedLines = (2000 / effectiveStep) * 2; // Rough estimate
    return estimatedLines <= RULERS_GRID_CONFIG.MAX_GRID_LINES;
  },

  /**
   * Determines if rulers should be rendered
   */
  shouldRenderRulers: (transform: ViewTransform, settings: RulerSettings): boolean => {
    return transform.scale > 0.1; // Don't render when too zoomed out
  },

  /**
   * Gets throttled render function
   */
  createThrottledRender: (renderFn: () => void): (() => void) => {
    let lastRender = 0;
    return () => {
      const now = Date.now();
      if (now - lastRender >= RULERS_GRID_CONFIG.RENDER_THROTTLE_MS) {
        renderFn();
        lastRender = now;
      }
    };
  }
};

// ===== COMBINED UTILITY EXPORT =====
export const RulersGridUtils = {
  ...UnitConversion,
  ...GridCalculations,
  ...RulerCalculations,
  ...SettingsValidation,
  ...PerformanceUtilities
};