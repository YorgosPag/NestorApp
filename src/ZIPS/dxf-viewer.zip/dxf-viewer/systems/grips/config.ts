/**
 * GRIPS SYSTEM CONFIGURATION
 * Re-export and organize grips configuration and types
 */

// Re-export from existing configuration files
export * from '../../config/grips-configuration';
export * from '../../types/gripSettings';

// Default exports for easy access
export { 
  DEFAULT_GRIPS_SETTINGS, 
  gripsConfig,
  getGripsSettings,
  updateGripsSettings,
  subscribeToGripsSettings,
  createGripId,
  isGripInTolerance
} from '../../config/grips-configuration';

export {
  DEFAULT_GRIP_SETTINGS,
  GRIP_LIMITS,
  validateGripSettings
} from '../../types/gripSettings';

// Additional utility types for the system
export interface GripsSystemConfig {
  legacyMode: boolean;
  autoDetection: boolean;
  performance: {
    debounceMs: number;
    maxRenderDistance: number;
  };
}

export const DEFAULT_GRIPS_SYSTEM_CONFIG: GripsSystemConfig = {
  legacyMode: false,
  autoDetection: true,
  performance: {
    debounceMs: 16,
    maxRenderDistance: 1000
  }
};