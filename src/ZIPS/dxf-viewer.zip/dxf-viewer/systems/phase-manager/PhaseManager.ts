/**
 * Phase Manager - Universal Entity Rendering Phase Control
 * Centralized logic for the 3-phase rendering system:
 * Phase 1: Preview (blue dashed, measurements, yellow dots)
 * Phase 2: Normal (white solid, authentic style)
 * Phase 3: Interactive (3a-Hover: white dashed, 3b-Selected: white solid)
 * 
 * Also handles grip interaction states:
 * - Cold (blue): Normal grip state
 * - Warm (orange): Grip hovered
 * - Hot (red): Grip selected/dragging with real-time measurements
 */

import type { Point2D } from '../coordinates/config';
import type { EntityModel, RenderOptions, GripInfo } from '../../utils/renderers/BaseEntityRenderer';
import { CAD_UI } from '../../config/cadUiConfig';

export interface PhaseManagerOptions {
  ctx: CanvasRenderingContext2D;
  transform: { scale: number; offsetX: number; offsetY: number };
  worldToScreen: (point: Point2D) => Point2D;
}

export interface PhaseRenderingState {
  phase: 'preview' | 'normal' | 'interactive';
  subState?: 'hover' | 'selected'; // Only for interactive phase
  gripState?: {
    hovered?: { entityId: string; gripIndex: number };
    active?: { entityId: string; gripIndex: number };
    dragging?: boolean;
  };
}

export class PhaseManager {
  private ctx: CanvasRenderingContext2D;
  private transform: { scale: number; offsetX: number; offsetY: number };
  private worldToScreen: (point: Point2D) => Point2D;
  
  constructor(options: PhaseManagerOptions) {
    this.ctx = options.ctx;
    this.transform = options.transform;
    this.worldToScreen = options.worldToScreen;
  }

  /**
   * Main method to determine and apply rendering phase
   */
  determinePhase(entity: EntityModel, options: RenderOptions = {}): PhaseRenderingState {
    if (options.preview) {
      return { phase: 'preview' };
    }
    
    if (options.hovered || options.selected) {
      // Interactive phase with sub-states
      const subState = options.hovered ? 'hover' : 'selected';
      return { 
        phase: 'interactive', 
        subState,
        gripState: this.getGripState(entity)
      };
    }
    
    return { phase: 'normal' };
  }

  /**
   * Apply phase-specific styling to canvas context
   */
  applyPhaseStyle(entity: EntityModel, state: PhaseRenderingState): void {
    // ALWAYS reset line dash first to prevent "sticking"
    this.ctx.setLineDash([]);
    
    switch (state.phase) {
      case 'preview':
        // Phase 1: Blue dashed with measurements
        this.ctx.lineWidth = 2;
        this.ctx.setLineDash([5, 5]);
        this.ctx.strokeStyle = '#0080ff'; // Blue for preview
        break;
        
      case 'normal':
        // Phase 2: Authentic entity style (white solid)
        this.ctx.lineWidth = 1;
        this.ctx.setLineDash([]);
        this.ctx.strokeStyle = entity.color || CAD_UI.entity.default;
        break;
        
      case 'interactive':
        if (state.subState === 'hover') {
          // Phase 3a: White dashed for hover
          this.ctx.lineWidth = 2;
          this.ctx.setLineDash([5, 5]);
          this.ctx.strokeStyle = '#FFFFFF';
        } else {
          // Phase 3b: White solid for selection (same as Phase 2 but white)
          this.ctx.lineWidth = 1;
          this.ctx.setLineDash([]);
          this.ctx.strokeStyle = '#ffffff';
        }
        break;
    }
  }

  /**
   * Render measurements based on phase requirements
   * 🎯 MEASUREMENT ENTITIES: Always show measurements in all phases
   */
  shouldRenderMeasurements(state: PhaseRenderingState, entity?: EntityModel): boolean {
    // For measurement entities, ALWAYS show measurements
    if (entity && this.isMeasurementEntity(entity)) {
      return true;
    }
    
    // For normal entities, show measurements during preview, hover, or dragging
    return state.phase === 'preview' || 
           (state.phase === 'interactive' && state.subState === 'hover') ||
           (state.gripState?.dragging === true);
  }

  /**
   * Render colored dots for preview phase and measurement entities
   * 🎯 MEASUREMENT ENTITIES: Always show dots in all phases
   */
  shouldRenderYellowDots(state: PhaseRenderingState, entity?: EntityModel): boolean {
    // For measurement entities, ALWAYS show dots
    if (entity && this.isMeasurementEntity(entity)) {
      return true;
    }
    
    // For normal entities, show dots only during preview phase (ORIGINAL BEHAVIOR)
    return state.phase === 'preview';
  }

  /**
   * Get appropriate dot color based on entity type and phase
   * 🎯 ΚΕΝΤΡΙΚΟΠΟΙΗΜΈΝΟ ΧΡΏΜΑ ΒΟΥΛΙΤΣΩΝ - μία αλλαγή εδώ αλλάζει όλα
   */
  getPreviewDotColor(entity?: EntityModel): string {
    // 🎯 Κίτρινο χρώμα για όλες τις οντότητες κατά την προεπισκόπηση - κεντρικοποιημένη λογική
    return '#ffff00'; // Κίτρινο για όλες τις οντότητες στη φάση προεπισκόπησης
  }

  /**
   * Check if entity is a measurement entity
   */
  private isMeasurementEntity(entity: EntityModel): boolean {
    return (entity as any).measurement === true || 
           entity.type === 'angle-measurement' ||
           entity.type === 'measure-distance' ||
           entity.type === 'measure-area';
  }

  /**
   * Render grips with phase-appropriate colors
   */
  renderPhaseGrips(entity: EntityModel, grips: GripInfo[], state: PhaseRenderingState): void {
    if (state.phase === 'preview') return; // No grips during preview
    
    for (let i = 0; i < grips.length; i++) {
      const grip = grips[i];
      const screenPos = this.worldToScreen(grip.position);
      
      // Determine grip color based on interaction state
      const gripColor = this.getGripColor(entity.id, i, state);
      
      this.drawPhaseGrip(screenPos, gripColor, grip.gripType);
    }
  }

  /**
   * Get appropriate grip color based on current phase and interaction state
   */
  private getGripColor(entityId: string, gripIndex: number, state: PhaseRenderingState): 'cold' | 'warm' | 'hot' {
    const gripState = state.gripState;
    
    if (!gripState) return 'cold';
    
    // Hot (red) - Active/dragging grip
    if (gripState.active?.entityId === entityId && 
        gripState.active?.gripIndex === gripIndex) {
      return 'hot';
    }
    
    // Warm (orange) - Hovered grip
    if (gripState.hovered?.entityId === entityId && 
        gripState.hovered?.gripIndex === gripIndex) {
      return 'warm';
    }
    
    // Cold (blue) - Normal grip
    return 'cold';
  }

  /**
   * Draw grip with appropriate color
   */
  private drawPhaseGrip(position: Point2D, colorState: 'cold' | 'warm' | 'hot', gripType?: string): void {
    const baseSize = 10;
    const size = colorState === 'hot' ? Math.round(baseSize * 1.5)
               : colorState === 'warm' ? Math.round(baseSize * 1.25)
                                       : Math.round(baseSize);

    let fillColor: string;
    if (gripType === 'edge') {
      // Edge/midpoint grips use green-based colors
      fillColor = colorState === 'hot' ? '#ff0000'    // Red when active
                : colorState === 'warm' ? '#ff8000'     // Orange when hovered  
                                        : '#00ff80';    // Green when normal
    } else {
      // Vertex grips use blue-based colors
      fillColor = colorState === 'hot' ? '#ff0000'    // Red when active
                : colorState === 'warm' ? '#ff8000'     // Orange when hovered
                                        : '#0080ff';    // Blue when normal
    }

    this.ctx.save();
    this.ctx.fillStyle = fillColor;
    this.ctx.strokeStyle = '#000';
    this.ctx.lineWidth = 1;

    this.ctx.fillRect(position.x - size/2, position.y - size/2, size, size);
    this.ctx.strokeRect(position.x - size/2, position.y - size/2, size, size);
    this.ctx.restore();
  }

  /**
   * Get current grip state (to be extended with actual grip interaction logic)
   */
  private getGripState(entity: EntityModel): PhaseRenderingState['gripState'] {
    // TODO: This will be connected to actual grip interaction system
    // For now, return empty state
    return {};
  }

  /**
   * Render real-time measurements during grip dragging
   */
  renderDragMeasurements(entity: EntityModel, draggedGripIndex: number, currentPosition: Point2D): void {
    // This will render live distance/angle/area measurements while dragging
    // Implementation depends on entity type
    switch (entity.type) {
      case 'line':
        this.renderLineDragMeasurements(entity, draggedGripIndex, currentPosition);
        break;
      case 'circle':
        this.renderCircleDragMeasurements(entity, draggedGripIndex, currentPosition);
        break;
      case 'rectangle':
      case 'rect':
        this.renderRectangleDragMeasurements(entity, draggedGripIndex, currentPosition);
        break;
      case 'arc':
        this.renderArcDragMeasurements(entity, draggedGripIndex, currentPosition);
        break;
      case 'polyline':
        this.renderPolylineDragMeasurements(entity, draggedGripIndex, currentPosition);
        break;
      case 'ellipse':
        this.renderEllipseDragMeasurements(entity, draggedGripIndex, currentPosition);
        break;
    }
  }

  /**
   * Render live measurements for line during grip drag
   */
  private renderLineDragMeasurements(entity: EntityModel, gripIndex: number, currentPos: Point2D): void {
    const start = entity.start as Point2D;
    const end = entity.end as Point2D;
    
    let newStart = start, newEnd = end;
    if (gripIndex === 0) newStart = currentPos;
    if (gripIndex === 1) newEnd = currentPos;
    
    const distance = Math.sqrt(
      Math.pow(newEnd.x - newStart.x, 2) + Math.pow(newEnd.y - newStart.y, 2)
    );
    
    // Render live distance with intelligent positioning
    const screenCurrentPos = this.worldToScreen(currentPos);
    const canvasWidth = this.ctx.canvas.width;
    const canvasHeight = this.ctx.canvas.height;
    
    this.ctx.save();
    this.ctx.fillStyle = '#ff0000'; // Red for live measurements
    this.ctx.font = '12px Arial';
    this.ctx.textBaseline = 'middle';
    
    // Smart positioning for line measurements
    let measurementX = screenCurrentPos.x + 20;
    let measurementY = screenCurrentPos.y - 10;
    let textAlign: CanvasTextAlign = 'left';
    
    // If too close to right edge, show on left side
    if (measurementX + 80 > canvasWidth) {
      measurementX = screenCurrentPos.x - 20;
      textAlign = 'right';
    }
    
    // If too close to top or bottom, adjust
    if (measurementY < 15) {
      measurementY = screenCurrentPos.y + 20;
    } else if (measurementY > canvasHeight - 15) {
      measurementY = screenCurrentPos.y - 30;
    }
    
    this.ctx.textAlign = textAlign;
    this.ctx.fillText(`Α: ${distance.toFixed(2)}`, measurementX, measurementY);
    this.ctx.restore();
  }

  /**
   * Render live measurements for circle during grip drag
   */
  private renderCircleDragMeasurements(entity: EntityModel, gripIndex: number, currentPos: Point2D): void {
    const center = entity.center as Point2D;
    const originalRadius = entity.radius as number;
    
    // Calculate new radius based on dragged position
    const newRadius = Math.sqrt(
      Math.pow(currentPos.x - center.x, 2) + Math.pow(currentPos.y - center.y, 2)
    );
    
    // Render live measurements with intelligent positioning
    const screenCurrentPos = this.worldToScreen(currentPos);
    const canvasWidth = this.ctx.canvas.width;
    const canvasHeight = this.ctx.canvas.height;
    
    // Render live measurements
    this.ctx.save();
    this.ctx.fillStyle = '#ff0000'; // Red for live measurements
    this.ctx.font = '12px Arial';
    this.ctx.textBaseline = 'middle';
    
    // Smart positioning for circle measurements
    let measurementX = screenCurrentPos.x + 20;
    let measurementY = screenCurrentPos.y;
    let textAlign: CanvasTextAlign = 'left';
    
    // If too close to right edge, show on left side
    if (measurementX + 120 > canvasWidth) {
      measurementX = screenCurrentPos.x - 20;
      textAlign = 'right';
    }
    
    // If too close to bottom, move up
    if (measurementY + 60 > canvasHeight) {
      measurementY = screenCurrentPos.y - 20;
    }
    
    // If too close to top, move down  
    if (measurementY - 30 < 0) {
      measurementY = screenCurrentPos.y + 60;
    }
    
    this.ctx.textAlign = textAlign;
    
    // Live measurements with Greek characters
    this.ctx.fillText(`Ρ: ${newRadius.toFixed(2)}`, measurementX, measurementY - 30);
    this.ctx.fillText(`Δ: ${(newRadius * 2).toFixed(2)}`, measurementX, measurementY - 10);
    
    // Live area
    const area = Math.PI * newRadius * newRadius;
    this.ctx.fillText(`Ε: ${area.toFixed(2)}`, measurementX, measurementY + 10);
    
    // Live circumference
    const circumference = 2 * Math.PI * newRadius;
    this.ctx.fillText(`Περ: ${circumference.toFixed(2)}`, measurementX, measurementY + 30);
    
    this.ctx.restore();
  }

  /**
   * Render live measurements for rectangle during grip drag
   */
  private renderRectangleDragMeasurements(entity: EntityModel, gripIndex: number, currentPos: Point2D): void {
    // Get current vertices (either from vertices array or from corners)
    let vertices: Point2D[] = entity.vertices as Point2D[] || [];
    
    if (vertices.length === 0) {
      const corner1 = entity.corner1 || entity.start;
      const corner2 = entity.corner2 || entity.end;
      if (corner1 && corner2) {
        vertices = [
          corner1,
          { x: corner2.x, y: corner1.y },
          corner2,
          { x: corner1.x, y: corner2.y }
        ];
      }
    }
    
    if (vertices.length < 4) return;
    
    // Create new vertices with dragged grip position
    const newVertices = [...vertices];
    
    // Determine which vertex/edge grip is being dragged
    if (gripIndex < 4) {
      // Corner grip - update that specific vertex
      newVertices[gripIndex] = currentPos;
      
      // For rectangle, we need to maintain rectangular shape
      // Update adjacent vertices to keep rectangle properties
      if (gripIndex === 0) { // Top-left
        newVertices[1] = { x: newVertices[2].x, y: currentPos.y };
        newVertices[3] = { x: currentPos.x, y: newVertices[2].y };
      } else if (gripIndex === 1) { // Top-right  
        newVertices[0] = { x: newVertices[3].x, y: currentPos.y };
        newVertices[2] = { x: currentPos.x, y: newVertices[3].y };
      } else if (gripIndex === 2) { // Bottom-right
        newVertices[1] = { x: currentPos.x, y: newVertices[0].y };
        newVertices[3] = { x: newVertices[0].x, y: currentPos.y };
      } else if (gripIndex === 3) { // Bottom-left
        newVertices[0] = { x: currentPos.x, y: newVertices[1].y };
        newVertices[2] = { x: newVertices[1].x, y: currentPos.y };
      }
    } else {
      // Edge grip - move entire edge
      const edgeIndex = gripIndex - 4;
      const nextEdge = (edgeIndex + 1) % 4;
      
      // Calculate which direction to move the edge
      if (edgeIndex === 0) { // Top edge
        newVertices[0].y = newVertices[1].y = currentPos.y;
      } else if (edgeIndex === 1) { // Right edge  
        newVertices[1].x = newVertices[2].x = currentPos.x;
      } else if (edgeIndex === 2) { // Bottom edge
        newVertices[2].y = newVertices[3].y = currentPos.y;
      } else if (edgeIndex === 3) { // Left edge
        newVertices[3].x = newVertices[0].x = currentPos.x;
      }
    }
    
    // Calculate new dimensions
    const width = Math.abs(newVertices[1].x - newVertices[0].x);
    const height = Math.abs(newVertices[2].y - newVertices[1].y);
    const area = width * height;
    const perimeter = 2 * (width + height);
    
    // Calculate intelligent position for measurements near the dragged grip
    const screenGripPos = this.worldToScreen(currentPos);
    const canvasWidth = this.ctx.canvas.width;
    const canvasHeight = this.ctx.canvas.height;
    
    // Render live measurements near the grip being dragged
    this.ctx.save();
    this.ctx.fillStyle = '#ff0000'; // Red for live measurements
    this.ctx.font = '12px Arial';
    
    // Smart positioning - avoid screen edges and grip overlap
    let measurementX = screenGripPos.x + 20; // Start 20px right of grip
    let measurementY = screenGripPos.y;
    let textAlign: CanvasTextAlign = 'left';
    
    // If too close to right edge, show on left side
    if (measurementX + 120 > canvasWidth) {
      measurementX = screenGripPos.x - 20;
      textAlign = 'right';
    }
    
    // If too close to bottom, move up
    if (measurementY + 60 > canvasHeight) {
      measurementY = screenGripPos.y - 20;
    }
    
    // If too close to top, move down  
    if (measurementY - 30 < 0) {
      measurementY = screenGripPos.y + 60;
    }
    
    this.ctx.textAlign = textAlign;
    this.ctx.textBaseline = 'middle';
    
    // Live measurements with Greek characters
    this.ctx.fillText(`Π: ${width.toFixed(2)}`, measurementX, measurementY - 30);
    this.ctx.fillText(`Υ: ${height.toFixed(2)}`, measurementX, measurementY - 10);
    this.ctx.fillText(`Ε: ${area.toFixed(2)}`, measurementX, measurementY + 10);
    this.ctx.fillText(`Περ: ${perimeter.toFixed(2)}`, measurementX, measurementY + 30);
    
    this.ctx.restore();
  }

  /**
   * Render live measurements for arc during grip drag
   */
  private renderArcDragMeasurements(entity: EntityModel, gripIndex: number, currentPos: Point2D): void {
    const center = entity.center as Point2D;
    const radius = entity.radius as number;
    const startAngle = entity.startAngle as number;
    const endAngle = entity.endAngle as number;
    
    if (!center || !radius) return;
    
    // Calculate new values based on grip being dragged
    let newRadius = radius;
    let newStartAngle = startAngle;
    let newEndAngle = endAngle;
    
    if (gripIndex === 0) {
      // Center grip - no change to measurements
      return;
    } else if (gripIndex === 1) {
      // Start point grip
      const dx = currentPos.x - center.x;
      const dy = currentPos.y - center.y;
      newRadius = Math.sqrt(dx * dx + dy * dy);
      newStartAngle = Math.atan2(dy, dx) * 180 / Math.PI;
    } else if (gripIndex === 2) {
      // End point grip
      const dx = currentPos.x - center.x;
      const dy = currentPos.y - center.y;
      newRadius = Math.sqrt(dx * dx + dy * dy);
      newEndAngle = Math.atan2(dy, dx) * 180 / Math.PI;
    } else if (gripIndex === 3) {
      // Radius grip - change radius only
      const dx = currentPos.x - center.x;
      const dy = currentPos.y - center.y;
      newRadius = Math.sqrt(dx * dx + dy * dy);
    }
    
    // Calculate measurements
    const arcAngle = Math.abs(newEndAngle - newStartAngle);
    const arcLength = (arcAngle * Math.PI / 180) * newRadius;
    
    const screenCenter = this.worldToScreen(center);
    
    // Render live measurements
    this.ctx.save();
    this.ctx.fillStyle = '#ff0000'; // Red for live measurements
    this.ctx.font = '12px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    
    this.ctx.fillText(`R: ${newRadius.toFixed(2)}`, screenCenter.x, screenCenter.y - 40);
    this.ctx.fillText(`∠: ${arcAngle.toFixed(1)}°`, screenCenter.x, screenCenter.y - 20);
    this.ctx.fillText(`L: ${arcLength.toFixed(2)}`, screenCenter.x, screenCenter.y);
    
    this.ctx.restore();
  }

  /**
   * Render live measurements for polyline during grip drag
   */
  private renderPolylineDragMeasurements(entity: EntityModel, gripIndex: number, currentPos: Point2D): void {
    const vertices = entity.vertices as Point2D[] || [];
    if (vertices.length < 2 || gripIndex >= vertices.length) return;
    
    const newVertices = [...vertices];
    newVertices[gripIndex] = currentPos;
    
    // Calculate total length
    let totalLength = 0;
    for (let i = 0; i < newVertices.length - 1; i++) {
      const dx = newVertices[i + 1].x - newVertices[i].x;
      const dy = newVertices[i + 1].y - newVertices[i].y;
      totalLength += Math.sqrt(dx * dx + dy * dy);
    }
    
    // Calculate area if closed
    let area = 0;
    if ((entity as any).closed && newVertices.length >= 3) {
      // Shoelace formula
      for (let i = 0; i < newVertices.length; i++) {
        const j = (i + 1) % newVertices.length;
        area += newVertices[i].x * newVertices[j].y;
        area -= newVertices[j].x * newVertices[i].y;
      }
      area = Math.abs(area) / 2;
    }
    
    // Find center for measurements
    const centerX = newVertices.reduce((sum, v) => sum + v.x, 0) / newVertices.length;
    const centerY = newVertices.reduce((sum, v) => sum + v.y, 0) / newVertices.length;
    const screenCenter = this.worldToScreen({ x: centerX, y: centerY });
    
    // Render live measurements
    this.ctx.save();
    this.ctx.fillStyle = '#ff0000'; // Red for live measurements
    this.ctx.font = '12px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    
    this.ctx.fillText(`L: ${totalLength.toFixed(2)}`, screenCenter.x, screenCenter.y - 20);
    if (area > 0) {
      this.ctx.fillText(`A: ${area.toFixed(2)}`, screenCenter.x, screenCenter.y);
    }
    
    this.ctx.restore();
  }

  /**
   * Render live measurements for ellipse during grip drag
   */
  private renderEllipseDragMeasurements(entity: EntityModel, gripIndex: number, currentPos: Point2D): void {
    const center = entity.center as Point2D;
    const majorAxis = entity.majorAxis as number;
    const minorAxis = entity.minorAxis as number;
    
    if (!center || !majorAxis || !minorAxis) return;
    
    // Calculate new axes based on grip being dragged
    let newMajorAxis = majorAxis;
    let newMinorAxis = minorAxis;
    
    if (gripIndex === 1 || gripIndex === 3) {
      // Major axis grips
      const dx = currentPos.x - center.x;
      const dy = currentPos.y - center.y;
      newMajorAxis = Math.sqrt(dx * dx + dy * dy);
    } else if (gripIndex === 2 || gripIndex === 4) {
      // Minor axis grips
      const dx = currentPos.x - center.x;
      const dy = currentPos.y - center.y;
      newMinorAxis = Math.sqrt(dx * dx + dy * dy);
    }
    
    // Calculate measurements
    const area = Math.PI * newMajorAxis * newMinorAxis;
    const perimeter = Math.PI * (3 * (newMajorAxis + newMinorAxis) - 
      Math.sqrt((3 * newMajorAxis + newMinorAxis) * (newMajorAxis + 3 * newMinorAxis)));
    
    const screenCenter = this.worldToScreen(center);
    
    // Render live measurements
    this.ctx.save();
    this.ctx.fillStyle = '#ff0000'; // Red for live measurements
    this.ctx.font = '12px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.textBaseline = 'middle';
    
    this.ctx.fillText(`Ma: ${newMajorAxis.toFixed(2)}`, screenCenter.x, screenCenter.y - 30);
    this.ctx.fillText(`Mi: ${newMinorAxis.toFixed(2)}`, screenCenter.x, screenCenter.y - 10);
    this.ctx.fillText(`A: ${area.toFixed(2)}`, screenCenter.x, screenCenter.y + 10);
    this.ctx.fillText(`P: ${perimeter.toFixed(2)}`, screenCenter.x, screenCenter.y + 30);
    
    this.ctx.restore();
  }

  /**
   * Update transform (called when viewport changes)
   */
  updateTransform(transform: { scale: number; offsetX: number; offsetY: number }): void {
    this.transform = transform;
  }
}