/**
 * COORDINATE SYSTEM UTILITIES
 * Helper functions for coordinate calculations and transformations
 */

import { Point2D, ViewTransform, CanvasRect, BoundingBox, GridSettings } from './config';
import { screenToWorld } from './config';

/**
 * Calculates adaptive grid spacing based on zoom level.
 */
export const calculateGridSpacing = (
  scale: number,
  baseStep: number,
  settings: GridSettings
): number => {
  if (!settings.behavior.adaptiveGrid) {
    return baseStep;
  }
  
  let currentStep = baseStep;
  
  while (currentStep * scale < settings.behavior.minGridSpacing) {
    currentStep *= settings.visual.subDivisions;
  }
  while (currentStep * scale > settings.behavior.maxGridSpacing) {
    currentStep /= settings.visual.subDivisions;
  }
  
  return currentStep;
};

/**
 * Calculates the visible grid boundaries in world coordinates.
 */
export const getVisibleGridBounds = (
  transform: ViewTransform,
  canvasRect: CanvasRect,
  gridStep: number
): BoundingBox => {
  const topLeftWorld = screenToWorld({ x: 0, y: 0 }, transform, canvasRect);
  const bottomRightWorld = screenToWorld({ x: canvasRect.width, y: canvasRect.height }, transform, canvasRect);

  return {
    min: {
      x: Math.floor(topLeftWorld.x / gridStep) * gridStep,
      y: Math.floor(bottomRightWorld.y / gridStep) * gridStep,
    },
    max: {
      x: Math.ceil(bottomRightWorld.x / gridStep) * gridStep,
      y: Math.ceil(topLeftWorld.y / gridStep) * gridStep,
    },
  };
};

/**
 * Checks if a point is within canvas bounds.
 */
export const isPointInBounds = (
  point: Point2D,
  canvasRect: CanvasRect
): boolean => {
  return point.x >= 0 && point.x <= canvasRect.width && 
         point.y >= 0 && point.y <= canvasRect.height;
};

/**
 * Calculates distance between two points.
 */
export const getDistance = (p1: Point2D, p2: Point2D): number => {
  const dx = p2.x - p1.x;
  const dy = p2.y - p1.y;
  return Math.sqrt(dx * dx + dy * dy);
};

/**
 * Normalizes a point to ensure valid coordinates.
 */
export const normalizePoint = (point: Point2D | null | undefined): Point2D => {
  if (!point || typeof point.x !== 'number' || typeof point.y !== 'number') {
    return { x: 0, y: 0 };
  }
  return {
    x: isNaN(point.x) ? 0 : point.x,
    y: isNaN(point.y) ? 0 : point.y
  };
};

/**
 * Rounds coordinates to a specific precision.
 */
export const roundCoordinates = (point: Point2D, precision: number = 2): Point2D => {
  const factor = Math.pow(10, precision);
  return {
    x: Math.round(point.x * factor) / factor,
    y: Math.round(point.y * factor) / factor
  };
};