/// <reference path="./types/dxf-modules.d.ts" />
'use client';
import React from 'react';
import { Toaster } from 'react-hot-toast';
import { CoordProvider } from './systems/coordinates';
import { GripProvider } from './providers/GripProvider';
import { SnapProvider } from './snapping/context/SnapContext';
import { LevelsSystem } from './systems/levels';
import { isFeatureEnabled } from './config/feature-flags';
import { OverlayStoreProvider } from './overlays/overlay-store';
import { SelectionSystem } from './systems/selection';
import { CursorSystem } from './systems/cursor';
import { ToolbarsSystem } from './systems/toolbars';
import { DxfViewerErrorBoundary } from './components/ErrorBoundary';
import { StorageErrorBoundary } from './components/StorageErrorBoundary';
import { ProjectHierarchyProvider } from './contexts/ProjectHierarchyContext';
import { DxfViewerContent } from './app/DxfViewerContent';
import type { DxfViewerAppProps } from './types';

export function DxfViewerApp(props: DxfViewerAppProps) {
  return (
    <StorageErrorBoundary>
      <DxfViewerErrorBoundary>
        <ProjectHierarchyProvider>
          <CoordProvider>
            <GripProvider>
              <SnapProvider>
                <CursorSystem>
                  <SelectionSystem>
                    <ToolbarsSystem>
                        {isFeatureEnabled('ENABLE_LEVELS_SYSTEM') ? (
                          <LevelsSystem enableFirestore={true}>
                            <OverlayStoreProvider>
                              <DxfViewerContent {...props} />
                              <Toaster 
                                position="top-right"
                                toastOptions={{
                                  style: {
                                    background: '#374151',
                                    color: '#fff',
                                    border: '1px solid #6B7280'
                                  }
                                }}
                              />
                            </OverlayStoreProvider>
                          </LevelsSystem>
                        ) : (
                          <OverlayStoreProvider>
                            <DxfViewerContent {...props} />
                            <Toaster 
                              position="top-right"
                              toastOptions={{
                                style: {
                                  background: '#374151',
                                  color: '#fff',
                                  border: '1px solid #6B7280'
                                }
                              }}
                            />
                          </OverlayStoreProvider>
                        )}
                    </ToolbarsSystem>
                  </SelectionSystem>
                </CursorSystem>
              </SnapProvider>
            </GripProvider>
          </CoordProvider>
        </ProjectHierarchyProvider>
      </DxfViewerErrorBoundary>
    </StorageErrorBoundary>
  );
}

export default DxfViewerApp;