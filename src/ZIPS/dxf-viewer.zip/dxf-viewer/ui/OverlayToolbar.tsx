'use client';
import React from 'react';
import { Separator } from '@/components/ui/separator';
import { MousePointer, Pen, X, Copy, Grid3X3, Square, Circle, Triangle, Edit } from 'lucide-react';
import { STATUS_COLORS, STATUS_LABELS, KIND_LABELS, type Status, type OverlayKind, type OverlayEditorMode } from '../overlays/types';
import type { PropertyStatus } from '../../../constants/statuses';
import { useUnifiedOverlayCreation } from '../hooks/overlay/useUnifiedOverlayCreation';
import { USE_UNIFIED_DRAWING_ENGINE } from '../config/featureFlags';
import { toolStyleStore } from '../stores/ToolStyleStore';

// Canvas-compatible status colors for button backgrounds
const BUTTON_STATUS_COLORS: Record<PropertyStatus, string> = {
  'for-sale': '#22c55e',    // Green
  'for-rent': '#3b82f6',    // Blue  
  'reserved': '#f59e0b',    // Orange
  'sold': '#ef4444',        // Red
  'landowner': '#8b5cf6',   // Purple
};

interface OverlayToolbarProps {
  mode: OverlayEditorMode;
  onModeChange: (mode: OverlayEditorMode) => void;
  currentStatus: Status;
  onStatusChange: (status: Status) => void;
  currentKind: OverlayKind;
  onKindChange: (kind: OverlayKind) => void;
  snapEnabled: boolean;
  onSnapToggle: () => void;
  selectedOverlayId: string | null;
  onDuplicate: () => void;
  onDelete: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onUndo: () => void;
  onRedo: () => void;
}

export const OverlayToolbar: React.FC<OverlayToolbarProps> = ({
  mode, onModeChange, currentStatus, onStatusChange, currentKind, onKindChange,
  snapEnabled, onSnapToggle, selectedOverlayId, onDuplicate, onDelete,
  canUndo, canRedo, onUndo, onRedo,
}) => {
  const { startOverlayCreation, isUsingUnifiedEngine } = useUnifiedOverlayCreation();
  
  const modeButtons = [
    { mode: 'select' as OverlayEditorMode, icon: MousePointer, label: 'Επιλογή', key: 'V' },
    { mode: 'draw' as OverlayEditorMode, icon: Pen, label: 'Σχεδίαση', key: 'N' },
    { mode: 'edit' as OverlayEditorMode, icon: Edit, label: 'Επεξεργασία', key: 'E' },
  ];

  const kindIcons = { unit: Square, parking: Circle, storage: Triangle, footprint: Grid3X3 };

  const handleModeChange = (newMode: OverlayEditorMode) => {
    if (newMode !== 'draw' || !USE_UNIFIED_DRAWING_ENGINE()) {
      onModeChange(newMode); // legacy / select / edit
      return;
    }
    // ΠΡΙΝ ξεκινήσει το draw, βεβαιώσου ότι το ενεργό χρώμα από το toolbar
    // έχει περάσει στο ToolStyleStore (αν το toolbar άλλαξε κάτι local).
    // (Αν ήδη ενημερώνεις το store από αλλού, το παρακάτω δεν πειράζει.)
    toolStyleStore.set({ /* noop touch to ensure subscribers */ });

    startOverlayCreation({
      onComplete: (overlayId) => {
        console.log('[Overlay] Created via unified system:', overlayId);
        onModeChange('select'); // επιστροφή σε select
      },
      onCancel: () => {
        console.log('[Overlay] Creation cancelled');
        onModeChange('select');
      }
    });
  };

  return (
    <div className="flex items-center gap-2 p-2 bg-gray-800 border border-gray-500 rounded-lg flex-wrap">
      {/* Drawing Modes */}
      <div className="flex items-center gap-1">
        {modeButtons.map(({ mode: btnMode, icon: Icon, label, key }) => (
          <button
            key={btnMode}
            onClick={() => handleModeChange(btnMode)}
            title={`${label} (${key})`}
            className={`
              h-8 px-2 rounded-md border transition-colors duration-150
              flex items-center justify-center gap-1
              ${mode === btnMode 
                ? 'bg-blue-600 hover:bg-blue-700 text-white border-blue-500' 
                : 'bg-gray-700 hover:bg-gray-600 text-gray-200 border-gray-500'
              }
            `}
          >
            <Icon className="w-4 h-4" />
            <span className="hidden sm:inline text-xs">{label}</span>
          </button>
        ))}
      </div>

      <Separator orientation="vertical" className="h-6 bg-gray-500" />

      {/* Status Palette */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-medium text-gray-400">Status:</span>
        <div className="flex items-center gap-1">
          {(Object.keys(STATUS_COLORS) as Status[]).map(status => (
            <button
              key={status}
              onClick={() => onStatusChange(status)}
              title={STATUS_LABELS[status]}
              className={`w-6 h-6 rounded-md border-2 transition-all duration-150 ${
                currentStatus === status ? 'border-white ring-2 ring-offset-2 ring-offset-gray-800 ring-blue-500' : 'border-transparent hover:border-gray-400'
              }`}
              style={{ backgroundColor: BUTTON_STATUS_COLORS[status as PropertyStatus] }}
            />
          ))}
        </div>
      </div>

      <Separator orientation="vertical" className="h-6 bg-gray-500" />

      {/* Kind Selection */}
      <div className="flex items-center gap-2">
        <span className="text-xs font-medium text-gray-400">Τύπος:</span>
        <div className="flex items-center gap-1">
          {(Object.keys(KIND_LABELS) as OverlayKind[]).map(kind => {
            const Icon = kindIcons[kind];
            return (
              <button
                key={kind}
                onClick={() => onKindChange(kind)}
                title={KIND_LABELS[kind]}
                className={`
                  h-8 w-8 p-0 rounded-md border transition-colors duration-150
                  flex items-center justify-center
                  ${currentKind === kind 
                    ? 'bg-blue-600 hover:bg-blue-700 text-white border-blue-500' 
                    : 'bg-gray-700 hover:bg-gray-600 text-gray-200 border-gray-500'
                  }
                `}
              >
                <Icon className="w-4 h-4" />
              </button>
            );
          })}
        </div>
      </div>

      <Separator orientation="vertical" className="h-6 bg-gray-500" />

      {/* Actions */}
      <div className="flex items-center gap-1">
        <button
          onClick={onDuplicate}
          disabled={!selectedOverlayId}
          title="Αντιγραφή (D)"
          className="
            h-8 w-8 p-0 rounded-md border transition-colors duration-150
            flex items-center justify-center
            bg-gray-700 hover:bg-gray-600 text-gray-200 border-gray-500
            disabled:opacity-50 disabled:cursor-not-allowed
          "
        >
          <Copy className="w-4 h-4" />
        </button>
        
        <button
          onClick={onDelete}
          disabled={!selectedOverlayId}
          title="Διαγραφή (Del)"
          className="
            h-8 w-8 p-0 rounded-md border transition-colors duration-150
            flex items-center justify-center
            bg-gray-700 hover:bg-red-900/50 text-red-400 hover:text-red-300 border-gray-500
            disabled:opacity-50 disabled:cursor-not-allowed
          "
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      <Separator orientation="vertical" className="h-6 bg-gray-500" />

      {/* Undo/Redo */}
      <div className="flex items-center gap-1">
        <button
          onClick={onUndo}
          disabled={!canUndo}
          title="Αναίρεση (Ctrl+Z)"
          className="
            h-8 w-8 p-0 rounded-md border transition-colors duration-150
            flex items-center justify-center
            bg-gray-700 hover:bg-gray-600 text-gray-200 border-gray-500
            disabled:opacity-50 disabled:cursor-not-allowed
          "
        >
          <span style={{ transform: 'scaleX(-1)' }}>↷</span>
        </button>
        <button
          onClick={onRedo}
          disabled={!canRedo}
          title="Επανάληψη (Ctrl+Y)"
          className="
            h-8 w-8 p-0 rounded-md border transition-colors duration-150
            flex items-center justify-center
            bg-gray-700 hover:bg-gray-600 text-gray-200 border-gray-500
            disabled:opacity-50 disabled:cursor-not-allowed
          "
        >
          <span>↷</span>
        </button>
      </div>
    </div>
  );
};
