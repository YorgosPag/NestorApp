/**
 * Feature Flags Configuration
 * Centralized feature flag management for the DXF viewer
 */

export function getFlag(flagName: string): boolean {
  if (typeof window === 'undefined') {
    return process.env[flagName] === 'true';
  }
  // client
  const fromWindow = (window as any).ENV?.[flagName];
  if (typeof fromWindow === 'string') return fromWindow === 'true';
  if (typeof fromWindow === 'boolean') return !!fromWindow;
  return (process.env as any)[flagName] === 'true';
}

export const USE_UNIFIED_DRAWING_ENGINE = () => getFlag('USE_UNIFIED_DRAWING_ENGINE');

// Debug helper to list all flags
export const getAllFlags = () => ({
  USE_UNIFIED_DRAWING_ENGINE: USE_UNIFIED_DRAWING_ENGINE(),
});