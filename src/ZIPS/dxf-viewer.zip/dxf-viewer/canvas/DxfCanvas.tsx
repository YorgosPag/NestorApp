// Re-export the refactored canvas component
export { DxfCanvasRefactored as DxfCanvas, DxfCanvasRefactored as default } from './DxfCanvasRefactored';
export type { DxfCanvasRef } from './DxfCanvasRefactored';